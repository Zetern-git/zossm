#pragma once

#include <array>
#include <atomic>
#include <cfloat>
#include <chrono>
#include <cinttypes>
#include <condition_variable>
#include <cmath>
#include <cstdarg>
#include <cstddef>
#include <exception>
#include <cstdint>
#include <cstdio>
#include <cstdlib>
#include <cstring>
#include <deque>
#include <fstream>
#include <functional>
#include <limits>
#include <list>
#include <map>
#include <memory>
#include <mutex>
#include <optional>
#include <random>
#include <set>
#include <span>
#include <sstream>
#include <string>
#include <string_view>
#include <thread>
#include <unordered_map>
#include <unordered_set>
#include <utility>
#include <variant>
#include <vector>

#include <sodium.h>

#if defined(_WIN32)
#define AIP_PLATFORM_WINDOWS 1
#elif defined(__APPLE__)
#define AIP_PLATFORM_MACOS 1
#elif defined(__linux__)
#define AIP_PLATFORM_LINUX 1
#else
#define AIP_PLATFORM_UNKNOWN 1
#endif

#if defined(AIP_PLATFORM_WINDOWS)
#ifndef WIN32_LEAN_AND_MEAN
#define WIN32_LEAN_AND_MEAN
#endif
#include <windows.h>
#include <io.h>
#include <shellapi.h>
#include <tlhelp32.h>
#else
#include <fcntl.h>
#include <sys/stat.h>
#include <sys/types.h>
#include <unistd.h>
#include <sys/statvfs.h>
#if !defined(AIP_PLATFORM_MACOS)
#include <sys/ptrace.h>
#endif
#if defined(AIP_PLATFORM_MACOS)
#include <dlfcn.h>
#include <sys/sysctl.h>
#include <sys/types.h>
#include <mach-o/dyld.h>
#include <mach/mach.h>
#endif
#if defined(AIP_PLATFORM_LINUX)
#include <sys/prctl.h>
#endif
#include <termios.h>
#endif

namespace aip {

constexpr const char* kProductName = "AIProtect";
constexpr const char* kProductPackage = "com.zetern.aiprotect";
constexpr uint32_t kVersionMajor = 1;
constexpr uint32_t kVersionMinor = 0;
constexpr uint32_t kVersionPatch = 0;
constexpr const char* kVersionSuffix = "";

enum class ExitCode : int {
    kOk = 0,
    kGenericError = 1,
    kUsageError = 2,
    kInputFileError = 3,
    kOutputFileError = 4,
    kFormatError = 5,
    kUnsupportedModel = 6,
    kCryptoError = 7,
    kAuthError = 8,
    kIntegrityViolation = 9,
    kRuntimeError = 10,
    kOutOfMemory = 11,
    kAborted = 12,
    kSelfTestFailed = 13,
};

enum class ErrClass {
    kUsage,
    kIoInput,
    kIoOutput,
    kFormat,
    kUnsupported,
    kCrypto,
    kAuth,
    kIntegrity,
    kRuntime,
    kMemory,
    kAborted,
    kInternal,
};

ExitCode ExitCodeForClass(ErrClass c);

class AiError {
public:
    AiError(ErrClass c, std::string message)
        : cls_(c), message_(std::move(message)) {}

    ErrClass Class() const { return cls_; }
    const std::string& Message() const { return message_; }
    ExitCode Code() const { return ExitCodeForClass(cls_); }

private:
    ErrClass cls_;
    std::string message_;
};

#if defined(__GNUC__) || defined(__clang__)
#define AIP_PRINTF_FMT(fmt_idx, arg_idx) __attribute__((format(printf, fmt_idx, arg_idx)))
#else
#define AIP_PRINTF_FMT(fmt_idx, arg_idx)
#endif

[[noreturn]] void ThrowError(ErrClass c, const std::string& msg);
[[noreturn]] void ThrowErrorF(ErrClass c, const char* fmt, ...) AIP_PRINTF_FMT(2, 3);

std::string FormatErrorVa(const char* fmt, va_list ap);
std::string FormatErrorF(const char* fmt, ...) AIP_PRINTF_FMT(1, 2);
std::string LastOsError();

struct Console {
    static void Out(const std::string& s);
    static void Err(const std::string& s);
    static void OutF(const char* fmt, ...) AIP_PRINTF_FMT(1, 2);
    static void ErrF(const char* fmt, ...) AIP_PRINTF_FMT(1, 2);
    static bool StdoutIsTty();
    static bool StdinIsTty();
};

struct Log {
    static bool quiet;
    static bool verbose;
    static void Info(const char* fmt, ...) AIP_PRINTF_FMT(1, 2);
    static void Warn(const char* fmt, ...) AIP_PRINTF_FMT(1, 2);
    static void Detail(const char* fmt, ...) AIP_PRINTF_FMT(1, 2);
    static void Stage(const std::string& name);
};

class Progress {
public:
    Progress(std::string label, uint64_t total, bool enabled);
    ~Progress();
    void Set(uint64_t done);
    void Bump(uint64_t delta);
    void Finish();

private:
    void Render(bool force);
    std::string label_;
    uint64_t total_;
    uint64_t done_ = 0;
    bool enabled_;
    int last_percent_ = -1;
    std::chrono::steady_clock::time_point start_;
    std::chrono::steady_clock::time_point last_draw_;
};

std::string HumanBytes(uint64_t v);
std::string HumanRate(double bytes_per_sec);
std::string HexEncode(const uint8_t* data, size_t len);
std::string HexEncode(std::span<const uint8_t> d);
bool HexDecode(const std::string& in, std::vector<uint8_t>& out);

namespace checked {
inline bool AddU64(uint64_t a, uint64_t b, uint64_t& out) {
    if (a > UINT64_MAX - b) return false;
    out = a + b;
    return true;
}
inline bool MulU64(uint64_t a, uint64_t b, uint64_t& out) {
    if (a != 0 && b > UINT64_MAX / a) return false;
    out = a * b;
    return true;
}
inline bool MulAddU64(uint64_t a, uint64_t b, uint64_t c, uint64_t& out) {
    uint64_t p = 0;
    if (!MulU64(a, b, p)) return false;
    if (!AddU64(p, c, out)) return false;
    return true;
}
}

class SecureWipe {
public:
    static void Do(void* p, size_t n) {
        if (p && n) sodium_memzero(p, n);
    }
};

template <typename T>
class SecureVector {
public:
    SecureVector() = default;
    explicit SecureVector(size_t n) : data_(n) {}
    SecureVector(size_t n, T v) : data_(n, v) {}
    ~SecureVector() { Clear(); }

    SecureVector(const SecureVector&) = delete;
    SecureVector& operator=(const SecureVector&) = delete;

    SecureVector(SecureVector&& o) noexcept : data_(std::move(o.data_)) {}
    SecureVector& operator=(SecureVector&& o) noexcept {
        if (this != &o) {
            Clear();
            data_ = std::move(o.data_);
        }
        return *this;
    }

    void resize(size_t n) {
        if (n < data_.size()) SecureWipe::Do(data_.data() + n, (data_.size() - n) * sizeof(T));
        data_.resize(n);
    }
    void reserve(size_t n) { data_.reserve(n); }
    void Clear() {
        if (!data_.empty()) SecureWipe::Do(data_.data(), data_.size() * sizeof(T));
        data_.clear();
        data_.shrink_to_fit();
    }
    void Assign(const T* p, size_t n) {
        Clear();
        data_.assign(p, p + n);
    }
    void PushBack(T v) { data_.push_back(v); }

    T* data() { return data_.data(); }
    const T* data() const { return data_.data(); }
    size_t size() const { return data_.size(); }
    bool empty() const { return data_.empty(); }
    T& operator[](size_t i) { return data_[i]; }
    const T& operator[](size_t i) const { return data_[i]; }
    std::span<T> Span() { return std::span<T>(data_.data(), data_.size()); }
    std::span<const T> Span() const { return std::span<const T>(data_.data(), data_.size()); }

private:
    std::vector<T> data_;
};

using SecureBytes = SecureVector<uint8_t>;

void WipeString(std::string& s);

class FileReader {
public:
    FileReader();
    ~FileReader();
    FileReader(const FileReader&) = delete;
    FileReader& operator=(const FileReader&) = delete;

    bool Open(const std::string& path, std::string& err);
    void Close();
    bool IsOpen() const { return fp_ != nullptr; }

    uint64_t Size() const { return size_; }
    uint64_t Tell() const;
    bool Seek(uint64_t pos);
    bool ReadExact(void* dst, size_t n);
    bool ReadAt(uint64_t pos, void* dst, size_t n);
    std::vector<uint8_t> ReadBlockAt(uint64_t pos, size_t n, bool& ok);
    const std::string& Path() const { return path_; }

private:
    std::FILE* fp_ = nullptr;
    uint64_t size_ = 0;
    uint64_t cur_ = 0;
    std::string path_;
};

class AtomicFileWriter {
public:
    AtomicFileWriter();
    ~AtomicFileWriter();
    AtomicFileWriter(const AtomicFileWriter&) = delete;
    AtomicFileWriter& operator=(const AtomicFileWriter&) = delete;

    bool Begin(const std::string& final_path, std::string& err);
    bool Write(const void* src, size_t n);
    bool WriteAt(uint64_t pos, const void* src, size_t n);
    uint64_t Tell() const { return written_; }
    bool Commit(std::string& err);
    void Abort();
    const std::string& TempPath() const { return temp_path_; }
    const std::string& FinalPath() const { return final_path_; }
    static bool RemoveFile(const std::string& p);
    static bool FileExists(const std::string& p);
    static uint64_t AvailableSpace(const std::string& dir, bool& ok);

private:
    std::FILE* fp_ = nullptr;
    std::string temp_path_;
    std::string final_path_;
    uint64_t written_ = 0;
    uint64_t high_ = 0;
    bool committed_ = false;
};

namespace fsx {
bool Exists(const std::string& p);
bool IsRegularFile(const std::string& p);
bool IsDirectory(const std::string& p);
uint64_t FileSize(const std::string& p, bool& ok);
std::string DirName(const std::string& p);
std::string FileName(const std::string& p);
std::string Absolute(const std::string& p, bool& ok);
bool SameFile(const std::string& a, const std::string& b);
uint64_t FreeSpaceFor(const std::string& path, bool& ok);
std::string Utf8FromArgv(const char* s);
}

struct PasswordInput {
    static bool ReadHidden(const std::string& prompt, std::string& out, std::string& err);
    static bool ReadWithConfirm(const std::string& prompt, std::string& out, std::string& err);
    static bool ReadLine(const std::string& prompt, std::string& out, std::string& err);
};

namespace random {
void Bytes(uint8_t* p, size_t n);
uint64_t Uniform64();
uint32_t Below(uint32_t n);
void Shuffle(uint32_t* v, size_t n);
}

enum class GgufValueType : uint32_t {
    kUint8 = 0,
    kInt8 = 1,
    kUint16 = 2,
    kInt16 = 3,
    kUint32 = 4,
    kInt32 = 5,
    kFloat32 = 6,
    kBool = 7,
    kString = 8,
    kArray = 9,
    kUint64 = 10,
    kInt64 = 11,
    kFloat64 = 12,
};

struct GgufValue {
    GgufValueType type = GgufValueType::kUint32;
    uint64_t u = 0;
    int64_t i = 0;
    double f = 0.0;
    bool b = false;
    std::string s;
    std::vector<GgufValue> arr;
    GgufValueType arr_elem = GgufValueType::kUint32;

    bool IsArray() const { return type == GgufValueType::kArray; }
    bool IsString() const { return type == GgufValueType::kString; }
    bool IsNumeric() const;
    double AsDouble() const;
    int64_t AsInt() const;
    uint64_t AsUint() const;
    bool AsBool() const;
    const std::string& AsString() const;
    std::string Describe() const;
};

struct GgufTensorInfo {
    std::string name;
    std::array<uint64_t, 4> dims{};
    uint32_t n_dims = 0;
    uint32_t type_id = 0;
    uint64_t rel_offset = 0;
    uint64_t abs_offset = 0;
    uint64_t n_elems = 0;
    uint64_t n_bytes = 0;
    uint64_t n_rows = 1;
    uint64_t row_elems = 0;
    uint32_t block_size = 0;
    uint32_t type_size = 0;

    std::string ShapeText() const;
};

struct GgufInfo {
    uint32_t version = 0;
    uint64_t n_tensors = 0;
    uint64_t n_kv = 0;
    uint64_t alignment = 32;
    uint64_t meta_end = 0;
    uint64_t data_start = 0;
    uint64_t file_size = 0;
    std::map<std::string, GgufValue> kv;
    std::vector<GgufTensorInfo> tensors;

    const GgufValue* Find(const std::string& k) const;
    bool Has(const std::string& k) const { return Find(k) != nullptr; }
    std::string GetString(const std::string& k, const std::string& def = {}) const;
    double GetFloat(const std::string& k, double def) const;
    int64_t GetInt(const std::string& k, int64_t def) const;
    bool GetBool(const std::string& k, bool def) const;
    const GgufTensorInfo* FindTensor(const std::string& name) const;
    const GgufTensorInfo* FindTensorF(const char* fmt, ...) const;
};

class GgufReader {
public:
    static GgufInfo Parse(const std::string& path, FileReader& fr, bool full_validation);
    static void ValidateLayout(const GgufInfo& g);

private:
    static GgufValue ReadValue(FileReader& fr, GgufValueType t, uint64_t& budget, int depth);
    static std::string ReadString(FileReader& fr, uint64_t& budget);
};

namespace quant {

struct TypeInfo {
    uint32_t id;
    const char* name;
    uint32_t block_size;
    uint32_t type_size;
    bool supported_by_aiprotect;
    bool is_quantized;
};

const TypeInfo* Info(uint32_t type_id);
const TypeInfo* InfoOrNull(uint32_t type_id);
bool IsSupported(uint32_t type_id);
std::string NameOf(uint32_t type_id);
uint32_t BlockSize(uint32_t type_id);
uint32_t TypeSize(uint32_t type_id);
uint64_t RowBytes(uint32_t type_id, uint64_t row_elems);
uint64_t TotalBytes(uint32_t type_id, uint64_t n_elems);
double BitsPerWeight(uint32_t type_id);
std::vector<std::string> SupportedNames();

uint16_t FloatToHalf(float f);
float HalfToFloat(uint16_t h);

void DequantizeRow(uint32_t type_id, const uint8_t* src, float* dst, uint64_t k);
bool DequantizeRowChecked(uint32_t type_id, const uint8_t* src, size_t src_len, float* dst, uint64_t k);

void QuantizeRowQ8_0(const float* src, uint8_t* dst, uint64_t k);

std::vector<uint8_t> EncodeReferenceBlock(uint32_t type_id, uint64_t seed, uint64_t k);

}

enum class ArchId : uint32_t {
    kUnknown = 0,
    kLlama = 1,
    kQwen2 = 2,
    kGemma = 3,
};

enum class FfnKind : uint32_t {
    kNone = 0,
    kSwiGlu = 1,
    kGeGlu = 2,
};

enum class NormKind : uint32_t {
    kNone = 0,
    kRms = 1,
};

std::string ArchName(ArchId a);
ArchId ArchFromName(const std::string& s);
std::vector<std::string> SupportedArchNames();

struct TensorRole {
    enum Kind : uint32_t {
        kNone = 0,
        kTokenEmbd,
        kOutputWeight,
        kOutputNorm,
        kAttnNorm,
        kAttnQ,
        kAttnK,
        kAttnV,
        kAttnQBias,
        kAttnKBias,
        kAttnVBias,
        kAttnOut,
        kFfnNorm,
        kFfnGate,
        kFfnUp,
        kFfnDown,
    };
};

struct WeightRequirement {
    TensorRole::Kind role;
    int layer;
    std::string name;
    std::vector<uint64_t> expect_dims;
    bool required;
};

struct ModelSpec {
    ArchId arch = ArchId::kUnknown;
    std::string arch_name;
    std::string general_name;
    uint32_t n_layer = 0;
    uint32_t n_vocab = 0;
    uint32_t n_embd = 0;
    uint32_t n_ff = 0;
    uint32_t n_head = 0;
    uint32_t n_head_kv = 0;
    uint32_t n_ctx_train = 0;
    uint32_t head_dim = 0;
    uint32_t n_rot = 0;
    uint32_t n_embd_gqa = 0;
    uint32_t n_embd_v_gqa = 0;
    float rope_theta = 10000.0f;
    float rope_scale = 1.0f;
    std::string rope_scaling_type;
    float norm_eps = 1e-5f;
    NormKind norm = NormKind::kRms;
    FfnKind ffn = FfnKind::kSwiGlu;
    bool tied_output = false;
    bool has_qkv_bias = false;
    bool has_output_bias = false;
    float embd_scale = 0.0f;
    float attn_logit_scale = 0.0f;
    float attn_softcap = 0.0f;
    float final_softcap = 0.0f;
    uint64_t alignment = 32;
    std::vector<WeightRequirement> required_tensors;

    static ModelSpec FromGguf(const GgufInfo& g);
    void Validate() const;
    void BuildRequirements();
    std::string Describe() const;
    bool HasSlidingWindow() const { return false; }
};

struct VocabData {
    std::string model;
    std::string pre;
    std::vector<std::string> tokens;
    std::vector<float> scores;
    std::vector<int32_t> types;
    std::vector<std::string> merges;
    int32_t bos = -1;
    int32_t eos = -1;
    int32_t pad = -1;
    int32_t unk = -1;
    bool add_bos = false;
    bool add_eos = false;

    static VocabData FromGguf(const GgufInfo& g);
    bool Valid() const { return !tokens.empty(); }
};

class Tokenizer {
public:
    void Load(const VocabData& v);
    std::vector<int32_t> Encode(const std::string& text, bool add_bos) const;
    std::string Decode(const std::vector<int32_t>& ids) const;
    size_t Size() const { return tokens_.size(); }
    bool Ready() const { return !tokens_.empty(); }
    int32_t Eos() const { return eos_; }
    int32_t Bos() const { return bos_; }

private:
    void BuildMergeRanks(const std::vector<std::string>& merges);
    void BuildPrefixIndex();
    void BuildSpecials(const VocabData& v);
    void EncodeChunk(const std::string& text, std::vector<int32_t>& ids) const;
    std::vector<std::string> Pretokenize(const std::string& text) const;
    std::vector<int32_t> BpeWord(const std::string& word) const;
    std::vector<int32_t> ByteFallback(const std::string& word) const;
    int32_t LookupToken(const std::string& s) const;
    std::string DecodePiece(const std::string& piece) const;

    std::vector<std::string> tokens_;
    std::unordered_map<std::string, int32_t> token_to_id_;
    std::unordered_map<uint64_t, int32_t> merge_rank_;
    std::unordered_map<std::string, int32_t> longest_;
    std::vector<int32_t> byte_fallback_;
    std::vector<std::pair<std::string, int32_t>> specials_;
    std::vector<bool> special_first_;
    size_t special_max_ = 0;
    bool spm_style_ = false;
    bool use_merges_ = false;
    int32_t bos_ = -1;
    int32_t eos_ = -1;
    int32_t pad_ = -1;
    int32_t unk_ = -1;
};

void SodiumStartup();
std::string SodiumVersion();

struct KdfParams {
    uint32_t alg = 1;
    uint64_t opslimit = 3;
    uint64_t memlimit_kib = 262144;
    std::array<uint8_t, 16> salt{};

    static KdfParams Generate(uint64_t opslimit, uint64_t memlimit_kib);
    void ClampToLibraryLimits();
    std::string Describe() const;
};

struct CipherParams {
    uint32_t alg = 1;
    uint32_t chunk_plain = 1u << 20;
};

struct KeyRing {
    SecureBytes master;
    SecureBytes weights;
    SecureBytes manifest;
    SecureBytes bytecode;
    SecureBytes integrity;
    SecureBytes rmp;
    SecureBytes vocab;

    void Clear();
    static KeyRing Derive(const SecureBytes& master, std::span<const uint8_t, 16> container_id);
};

constexpr size_t kMasterKeyBytes = 32;

void PutLe32(uint8_t* p, uint32_t v);
void PutLe64(uint8_t* p, uint64_t v);
uint32_t GetLe32(const uint8_t* p);
uint64_t GetLe64(const uint8_t* p);

struct DerivedKey {
    SecureBytes key;
    void Clear() { key.Clear(); }
};

DerivedKey KdfDerive(const std::string& password, const KdfParams& p);
bool KdfVerify(const std::string& password, const KdfParams& p, std::span<const uint8_t> expected_master);

struct BlockCipher {
    static constexpr size_t kKeyBytes = crypto_aead_xchacha20poly1305_ietf_KEYBYTES;
    static constexpr size_t kNonceBytes = crypto_aead_xchacha20poly1305_ietf_NPUBBYTES;
    static constexpr size_t kTagBytes = crypto_aead_xchacha20poly1305_ietf_ABYTES;

    static void BuildNonce(std::array<uint8_t, kNonceBytes>& nonce,
                           std::span<const uint8_t, 8> section_nonce,
                           uint32_t section_id, uint64_t chunk_index);
    static bool Encrypt(std::span<const uint8_t> key,
                        std::span<const uint8_t, kNonceBytes> nonce,
                        std::span<const uint8_t> aad,
                        std::span<const uint8_t> plain,
                        uint8_t* out, size_t out_cap, size_t& out_len);
    static bool Decrypt(std::span<const uint8_t> key,
                        std::span<const uint8_t, kNonceBytes> nonce,
                        std::span<const uint8_t> aad,
                        std::span<const uint8_t> cipher,
                        uint8_t* out, size_t out_cap, size_t& out_len);
};

void BuildChunkAad(std::span<const uint8_t, 16> container_id, uint32_t section_id, uint32_t purpose,
                   uint64_t chunk_index, uint64_t chunk_plain_size, std::array<uint8_t, 40>& aad);

struct ChunkMac {
    static constexpr size_t kBytes = crypto_auth_hmacsha512256_BYTES;
    static constexpr size_t kKeyBytes = crypto_auth_hmacsha512256_KEYBYTES;
};

class KeyedHash {
public:
    explicit KeyedHash(std::span<const uint8_t> key);
    ~KeyedHash();
    void Update(const void* p, size_t n);
    void Final(uint8_t out[32]);
    static void Once(std::span<const uint8_t> key, std::span<const uint8_t> data, uint8_t out[32]);
    static void Plain(std::span<const uint8_t> data, uint8_t out[32]);

private:
    struct State;
    std::unique_ptr<State> st_;
};

enum class SectionPurpose : uint32_t {
    kNone = 0,
    kManifest = 1,
    kBytecode = 2,
    kWeights = 3,
    kRmp = 4,
    kVocab = 5,
};

const char* SectionPurposeName(SectionPurpose p);

constexpr uint32_t kContainerMagicA = 0x54525049;
constexpr uint32_t kContainerMagicB = 0x0A1A3130;
constexpr uint32_t kContainerVersion = 1;
constexpr uint32_t kMinContainerVersion = 1;
constexpr uint32_t kHeaderSize = 256;
constexpr uint32_t kSectionEntrySize = 128;
constexpr uint32_t kManifestMagic = 0x464E4D41;
constexpr uint32_t kManifestVersion = 1;
constexpr uint32_t kBytecodeMagic = 0x314D5641;
constexpr uint32_t kBytecodeVersion = 1;
constexpr uint32_t kRmpRecordMagic = 0x52504D52;
constexpr uint32_t kRmpRecordVersion = 1;

constexpr uint32_t kSectionIdManifest = 1;
constexpr uint32_t kSectionIdBytecode = 2;
constexpr uint32_t kSectionIdWeights = 3;
constexpr uint32_t kSectionIdRmp = 4;
constexpr uint32_t kSectionIdVocab = 5;


enum ContainerFlags : uint64_t {
    kFlagVirtualized = 1ull << 0,
    kFlagRmpEnabled = 1ull << 1,
    kFlagWeightTransform = 1ull << 2,
    kFlagStreamedWeights = 1ull << 3,
    kFlagManifestVerified = 1ull << 4,
};

#pragma pack(push, 1)

struct ContainerHeader {
    uint32_t magic_a;
    uint32_t magic_b;
    uint32_t format_version;
    uint32_t header_size;
    uint64_t flags;
    uint8_t container_id[16];
    uint32_t kdf_alg;
    uint32_t kdf_reserved;
    uint64_t kdf_opslimit;
    uint64_t kdf_memlimit;
    uint8_t kdf_salt[16];
    uint32_t cipher_alg;
    uint32_t chunk_plain;
    uint64_t section_count;
    uint64_t section_table_offset;
    uint64_t section_table_size;
    uint64_t file_size;
    int64_t created_unix;
    uint32_t product_major;
    uint32_t product_minor;
    uint32_t product_patch;
    uint32_t abi_flags;
    uint8_t reserved[80];
    uint8_t header_mac[32];
};

struct SectionEntry {
    uint32_t section_id;
    uint32_t purpose;
    uint64_t data_offset;
    uint64_t plain_size;
    uint64_t stored_size;
    uint32_t chunk_plain;
    uint32_t chunk_stored;
    uint64_t chunk_count;
    uint8_t nonce_prefix[8];
    uint32_t key_slot;
    uint32_t reserved0;
    uint8_t digest[32];
    uint8_t reserved1[32];
};

#pragma pack(pop)

static_assert(sizeof(ContainerHeader) == kHeaderSize, "container header layout");
static_assert(sizeof(SectionEntry) == kSectionEntrySize, "section entry layout");

class ByteWriter {
public:
    void U8(uint8_t v);
    void U16(uint16_t v);
    void U32(uint32_t v);
    void U64(uint64_t v);
    void I32(int32_t v);
    void I64(int64_t v);
    void F32(float v);
    void Raw(const void* p, size_t n);
    void Raw(std::span<const uint8_t> d);
    void Str(const std::string& s);
    void Pad(size_t n);
    const std::vector<uint8_t>& Bytes() const { return b_; }
    std::vector<uint8_t> Take() { return std::move(b_); }
    size_t Size() const { return b_.size(); }

private:
    std::vector<uint8_t> b_;
};

class ByteReader {
public:
    ByteReader(const uint8_t* p, size_t n) : p_(p), n_(n) {}
    ByteReader(std::span<const uint8_t> d) : p_(d.data()), n_(d.size()) {}

    bool U8(uint8_t& v);
    bool U16(uint16_t& v);
    bool U32(uint32_t& v);
    bool U64(uint64_t& v);
    bool I32(int32_t& v);
    bool I64(int64_t& v);
    bool F32(float& v);
    bool Raw(void* dst, size_t n);
    bool Str(std::string& out, size_t max_len);
    bool Skip(size_t n);
    size_t Remaining() const { return n_ - pos_; }
    size_t Pos() const { return pos_; }
    const uint8_t* Cursor() const { return p_ + pos_; }
    bool Eof() const { return pos_ == n_; }
    bool Ok() const { return !failed_; }

private:
    bool Need(size_t n) const;
    const uint8_t* p_;
    size_t n_;
    size_t pos_ = 0;
    mutable bool failed_ = false;
};

enum class TransformAxis : uint32_t {
    kNone = 0,
    kResidual = 1,
    kFfn = 2,
    kHead = 3,
    kVocab = 4,
};

struct AxisPlan {
    TransformAxis axis = TransformAxis::kNone;
    bool enabled = false;
    uint32_t length = 0;
    uint32_t granularity = 1;
    uint32_t group_count = 0;
    uint32_t kv_groups = 0;
    bool signed_perm = false;
    std::vector<uint32_t> perm;
    std::vector<uint32_t> kv_perm;
    std::vector<int8_t> signs;
    std::string reject_reason;
};

struct TransformPlan {
    bool enabled = false;
    AxisPlan residual;
    AxisPlan ffn;
    AxisPlan head;
    AxisPlan vocab;
    std::vector<std::string> notes;
    uint64_t key_space_bits = 0;

    std::string Describe() const;
};

enum TransformMaskBits : uint32_t {
    kTfResidualCol = 1u << 0,
    kTfResidualRow = 1u << 1,
    kTfFfnCol = 1u << 2,
    kTfFfnRow = 1u << 3,
    kTfHeadRowQ = 1u << 4,
    kTfHeadRowKv = 1u << 5,
    kTfHeadColQ = 1u << 6,
    kTfHeadColKv = 1u << 7,
    kTfVocabRow = 1u << 8,
    kTfResidualColUnsigned = 1u << 9,
};

struct TensorSlot {
    uint32_t slot_id = 0;
    std::string name;
    TensorRole::Kind role = TensorRole::kNone;
    int32_t layer = -1;
    uint32_t type_id = 0;
    std::array<uint64_t, 4> dims{};
    uint32_t n_dims = 0;
    uint64_t n_elems = 0;
    uint64_t n_rows = 1;
    uint64_t row_elems = 0;
    uint32_t block_size = 1;
    uint32_t type_size = 4;
    uint64_t row_bytes = 0;
    uint64_t total_bytes = 0;
    uint64_t src_offset = 0;
    uint64_t dst_offset = 0;
    uint64_t dst_size = 0;
    uint32_t transform_mask = 0;
    uint8_t digest[32]{};
    bool present = false;
};

struct WeightLayout {
    uint32_t storage_type = 0;
    uint64_t total_plain_bytes = 0;
    std::vector<TensorSlot> slots;
    std::unordered_map<std::string, uint32_t> index;

    const TensorSlot* Find(const std::string& name) const;
    const TensorSlot* FindBySlot(uint32_t id) const;
};

WeightLayout BuildLayoutFromGguf(const ModelSpec& spec, const GgufInfo& g,
                                 std::vector<const GgufTensorInfo*>& sources, std::vector<std::string>& warnings);

enum class VmOp : uint16_t {
    kNop = 0,
    kHalt = 1,
    kEmbedRow = 2,
    kScale = 3,
    kRmsNorm = 4,
    kMulMatVec = 5,
    kAddWeightVec = 6,
    kMulWeightVec = 7,
    kRope = 8,
    kKvStore = 9,
    kAttention = 10,
    kAdd = 11,
    kMul = 12,
    kSwiGlu = 13,
    kGeGlu = 14,
    kCopy = 15,
    kLogits = 16,
    kIntegrityProbe = 17,
    kAssertFinite = 18,
    kRmsNormNoGain = 19,
};

const char* VmOpName(VmOp op);
bool VmOpKnown(uint16_t v);

#pragma pack(push, 1)
struct VmInstr {
    uint16_t op;
    uint16_t dst;
    uint16_t src0;
    uint16_t src1;
    uint32_t slot;
    uint32_t imm;
    float fvalue;
    uint16_t aux0;
    uint16_t aux1;
};
struct VmRegDecl {
    uint32_t ne0;
    uint32_t ne1;
    uint32_t kind;
    uint32_t reserved;
};
struct VmSlotRef {
    uint32_t slot_id;
    uint32_t role;
    int32_t layer;
    uint32_t storage_type;
    uint64_t n_rows;
    uint64_t row_elems;
    uint8_t digest[32];
};
struct VmProgramHeader {
    uint32_t magic;
    uint32_t version;
    uint32_t instr_size;
    uint32_t instr_count;
    uint32_t reg_count;
    uint32_t slot_count;
    uint32_t const_count;
    uint32_t max_ctx;
    uint32_t n_layer;
    uint32_t n_embd;
    uint32_t n_head;
    uint32_t n_head_kv;
    uint32_t head_dim;
    uint32_t n_rot;
    uint32_t n_ff;
    uint32_t n_vocab;
    float rope_theta;
    float rope_scale;
    float norm_eps;
    float attn_scale;
    float attn_softcap;
    float final_softcap;
    float embd_scale;
    uint32_t ffn_kind;
    uint32_t tied_output;
    uint32_t rmp_probes;
    uint32_t entry_reg;
    uint64_t arena_floats;
    uint8_t program_digest[32];
    uint8_t reserved[32];
};
#pragma pack(pop)

static_assert(sizeof(VmInstr) == 24, "vm instruction layout");
static_assert(sizeof(VmRegDecl) == 16, "vm reg layout");
static_assert(sizeof(VmSlotRef) == 64, "vm slotref layout");

struct VmProgram {
    VmProgramHeader header{};
    std::vector<VmInstr> code;
    std::vector<VmRegDecl> regs;
    std::vector<VmSlotRef> slots;
    std::vector<float> consts;
    std::vector<uint8_t> blob;

    static VmProgram FromBlob(std::span<const uint8_t> blob);
    std::vector<uint8_t> Serialize() const;
    void ComputeDigest(uint8_t out[32]) const;
    bool Verify(std::string& err) const;
};

enum class GraphOp : uint32_t {
    kInput = 0,
    kEmbed,
    kScale,
    kRmsNorm,
    kMulMatVec,
    kAddWeightVec,
    kRope,
    kKvStore,
    kAttention,
    kAdd,
    kMul,
    kSwiGlu,
    kGeGlu,
    kLogits,
    kOutput,
    kIntegrityProbe,
};

const char* GraphOpName(GraphOp op);

struct GraphNode {
    uint32_t id = 0;
    GraphOp op = GraphOp::kInput;
    std::vector<uint32_t> inputs;
    std::string weight;
    uint32_t layer = 0;
    float fparam = 0.0f;
    uint32_t iparam = 0;
    uint32_t ne0 = 0;
    uint32_t ne1 = 1;
    std::string name;
};

struct ModelGraph {
    std::vector<GraphNode> nodes;
    uint32_t input_node = 0;
    uint32_t logits_node = 0;

    uint32_t Add(GraphNode n);
    static ModelGraph BuildForArch(const ModelSpec& spec, const WeightLayout& layout);
    bool Validate(std::string& err) const;
};

class BytecodeCompiler {
public:
    static VmProgram Compile(const ModelGraph& g, const ModelSpec& spec, const WeightLayout& layout,
                             uint32_t max_ctx, bool rmp_enabled, std::string& err);
};

class BytecodeVerifier {
public:
    static bool Verify(const VmProgram& p, std::string& err);
};

struct TensorView {
    float* data = nullptr;
    uint64_t ne0 = 0;
    uint64_t ne1 = 1;
};

class WeightProvider {
public:
    virtual ~WeightProvider() = default;
    virtual const TensorSlot* Slot(uint32_t id) const = 0;
    virtual size_t SlotCount() const = 0;
    virtual void ReadRow(uint32_t slot_id, uint64_t row, float* out) = 0;
    virtual const float* Vector(uint32_t slot_id) = 0;
    virtual void ReadRaw(uint32_t slot_id, uint64_t byte_off, void* dst, size_t n) = 0;
    virtual void ReadRowRaw(uint32_t slot_id, uint64_t row, uint8_t* dst) = 0;
    virtual void SlotDigest(uint32_t slot_id, uint8_t out[32]) = 0;
    virtual uint64_t BytesDecrypted() const = 0;
    virtual uint64_t RowsServed() const = 0;
    virtual void IntegrityTick() {}
};

struct RmpPolicy {
    bool enabled = true;
    bool anti_debug = true;
    bool periodic_integrity = true;
    bool verify_blocks = true;
    bool env_scan = true;
    uint32_t probe_interval_tokens = 8;
    uint32_t max_violations = 1;
    bool allow_ptrace_self = false;
};

struct RmpRecord {
    RmpPolicy policy;
    uint32_t anti_debug_available = 0;
    std::string platform_name;
    uint8_t header_core_digest[32]{};
    uint8_t manifest_digest[32]{};
    uint32_t bytecode_present = 0;
    uint8_t bytecode_digest[32]{};
    uint8_t weights_digest[32]{};
    uint64_t weights_plain_bytes = 0;
    uint64_t weights_chunk_count = 0;
    std::array<uint8_t, 16> container_id{};

    std::vector<uint8_t> Serialize() const;
    static bool Deserialize(std::span<const uint8_t> data, RmpRecord& out, std::string& err);
};

std::vector<uint8_t> CanonicalHeaderCore(const ContainerHeader& h);
void HashFileDigest(FileReader& fr, uint64_t bytes, uint8_t out[32], bool show_progress);

struct RmpFinding {
    std::string source;
    std::string detail;
    bool fatal;
};

struct RmpReport {
    bool debugger_detected = false;
    bool injection_suspected = false;
    bool integrity_failed = false;
    bool env_anomaly = false;
    std::vector<RmpFinding> findings;
    std::string platform;

    bool AnyViolation() const;
    std::string Summary() const;
};

namespace platform {
const char* Name();
bool AntiDebugAvailable();
void Harden();
bool DetectDebugger(std::string& detail);
bool ScanModules(std::vector<std::string>& detail);
bool ScanEnvironment(std::vector<std::string>& detail);
}

class RmpMonitor {
public:
    explicit RmpMonitor(RmpPolicy policy);

    void Bind(std::span<const uint8_t> container_id, std::span<const uint8_t> integrity_key);
    void RegisterRegion(const std::string& name, std::span<const uint8_t> data);
    void Seal();

    RmpReport ScanEnvironment();
    bool VerifyRegions(std::vector<RmpFinding>& out);
    void OnToken(uint64_t token_index, std::vector<RmpFinding>& out);
    void RecordBlockDigest(const std::string& name, std::span<const uint8_t, 32> digest);
    bool VerifyBlockDigest(const std::string& name, std::span<const uint8_t, 32> digest);

    const RmpPolicy& Policy() const { return policy_; }
    bool Enabled() const { return policy_.enabled; }
    uint64_t ChecksPerformed() const { return checks_; }
    void SecureErase();

    static RmpReport DetectEnvironment(const RmpPolicy& policy);

private:
    void DigestAll();

    RmpPolicy policy_;
    bool sealed_ = false;
    uint64_t checks_ = 0;
    uint64_t violations_ = 0;
    uint64_t last_probe_token_ = 0;
    std::array<uint8_t, 16> container_id_{};
    SecureBytes integrity_key_;
    struct Region {
        std::string name;
        const uint8_t* data;
        size_t size;
        std::array<uint8_t, 32> digest{};
    };
    std::vector<Region> regions_;
    std::unordered_map<std::string, std::array<uint8_t, 32>> block_digests_;
};

struct KvCache {
    uint32_t n_layer = 0;
    uint32_t n_ctx = 0;
    uint32_t n_head_kv = 0;
    uint32_t head_dim = 0;
    std::vector<float> k;
    std::vector<float> v;
    uint32_t size = 0;

    void Allocate(uint32_t layers, uint32_t ctx, uint32_t head_kv, uint32_t hdim);
    void Reset();
    float* KPtr(uint32_t layer, uint32_t pos);
    float* VPtr(uint32_t layer, uint32_t pos);
    uint64_t Bytes() const { return (k.size() + v.size()) * sizeof(float); }
};

class VirtualMachine {
public:
    struct Limits {
        uint64_t max_arena_bytes = 8ull << 30;
        uint32_t max_instructions = 2000000;
        bool allow_softcap = true;
    };

    VirtualMachine(VmProgram program, WeightProvider& weights, Limits limits);
    ~VirtualMachine();

    void Configure(uint32_t n_ctx, uint32_t threads);
    bool Prepare(std::string& err);
    void ResetCache();

    const float* Forward(int32_t token, int32_t position, std::vector<RmpFinding>* findings);
    uint32_t LogitsSize() const { return logits_size_; }
    uint64_t InstructionsExecuted() const { return instr_executed_; }
    const VmProgram& Program() const { return prog_; }
    uint32_t Threads() const { return threads_; }
    void SetRmp(RmpMonitor* m) { rmp_ = m; }
    double LastForwardSeconds() const { return last_seconds_; }

private:
    struct Reg {
        float* ptr = nullptr;
        uint64_t ne0 = 0;
        uint64_t ne1 = 1;
        bool owned = false;
    };

    struct Pool {
        std::vector<std::thread> workers;
        std::mutex mu;
        std::condition_variable cv_start;
        std::condition_variable cv_done;
        std::function<void(uint64_t, uint64_t)> job;
        uint64_t total = 0;
        uint64_t job_id = 0;
        uint64_t finished = 0;
        bool stop = false;
        uint32_t nthreads = 1;
        std::exception_ptr error;
    };

    void PoolStart(uint32_t n);
    void PoolStop();

    float* RegPtr(uint16_t r);
    const Reg& R(uint16_t r) const;
    void EnsureReg(uint16_t r);
    void ExecInstr(const VmInstr& in, int32_t token, int32_t position,
                   std::vector<RmpFinding>* findings);

    void OpEmbed(const VmInstr& in, int32_t token);
    void OpRmsNorm(const VmInstr& in);
    void OpMulMatVec(const VmInstr& in, bool logits_out);
    void OpAddWeightVec(const VmInstr& in);
    void OpMulWeightVec(const VmInstr& in);
    void OpRope(const VmInstr& in, int32_t position);
    void OpKvStore(const VmInstr& in, int32_t position);
    void OpAttention(const VmInstr& in, int32_t position);
    void OpAdd(const VmInstr& in);
    void OpMul(const VmInstr& in);
    void OpGlu(const VmInstr& in, bool swiglu);
    void OpScale(const VmInstr& in);
    void OpCopy(const VmInstr& in);
    void OpAssertFinite(const VmInstr& in);
    void OpIntegrityProbe(const VmInstr& in, std::vector<RmpFinding>* findings);

    void MulMatVecRange(uint32_t slot_id, const float* src, float* dst, uint64_t row_begin, uint64_t row_end);
    void ParallelFor(uint64_t n, const std::function<void(uint64_t, uint64_t)>& fn);

    VmProgram prog_;
    WeightProvider& weights_;
    Limits limits_;
    std::vector<Reg> regs_;
    std::vector<uint64_t> reg_base_;
    std::vector<float> arena_;
    KvCache kv_;
    std::vector<float> scores_;
    std::vector<float> rope_cos_;
    std::vector<float> rope_sin_;
    int64_t rope_pos_cached_ = -1;
    uint16_t token_reg_ = 0;
    uint16_t pos_reg_ = 0;
    Pool pool_;
    uint32_t threads_ = 1;
    uint32_t logits_size_ = 0;
    float* logits_ptr_ = nullptr;
    uint64_t instr_executed_ = 0;
    RmpMonitor* rmp_ = nullptr;
    double last_seconds_ = 0.0;
    bool prepared_ = false;
};

struct SamplerConfig {
    float temperature = 0.0f;
    uint32_t top_k = 1;
    float top_p = 1.0f;
    float min_p = 0.0f;
    float repeat_penalty = 1.0f;
    uint32_t repeat_last_n = 64;
    uint64_t seed = 0;
    bool deterministic = true;
};

class Sampler {
public:
    explicit Sampler(SamplerConfig cfg);
    int32_t Sample(const float* logits, uint32_t n, const std::vector<int32_t>& history);

private:
    int32_t Greedy(const float* logits, uint32_t n) const;
    SamplerConfig cfg_;
    std::mt19937_64 rng_;
};

struct ManifestTensor {
    std::string name;
    uint32_t slot_id = 0;
    uint32_t role = 0;
    int32_t layer = -1;
    uint32_t type_id = 0;
    std::array<uint64_t, 4> dims{};
    uint32_t n_dims = 0;
    uint64_t n_elems = 0;
    uint64_t n_rows = 1;
    uint64_t row_elems = 0;
    uint32_t block_size = 1;
    uint32_t type_size = 4;
    uint64_t row_bytes = 0;
    uint64_t total_bytes = 0;
    uint64_t stream_offset = 0;
    uint32_t transform_mask = 0;
    uint8_t digest[32]{};
};

struct ManifestModel {
    uint32_t arch = 0;
    std::string arch_name;
    std::string general_name;
    uint32_t n_layer = 0, n_vocab = 0, n_embd = 0, n_ff = 0;
    uint32_t n_head = 0, n_head_kv = 0, n_ctx_train = 0;
    uint32_t head_dim = 0, n_rot = 0, n_embd_gqa = 0, n_embd_v_gqa = 0;
    float rope_theta = 0, rope_scale = 0, norm_eps = 0;
    uint32_t norm_kind = 0, ffn_kind = 0;
    uint32_t tied_output = 0, has_qkv_bias = 0, has_output_bias = 0;
    float embd_scale = 0, attn_logit_scale = 0, attn_softcap = 0, final_softcap = 0;
    std::string rope_scaling_type;
};

struct ManifestProvenance {
    std::string source_file_name;
    uint64_t source_file_size = 0;
    uint32_t source_gguf_version = 0;
    uint8_t source_digest[32]{};
    int64_t created_unix = 0;
    std::string created_by;
};

struct TransformRecord {
    uint32_t enabled = 0;
    struct Axis {
        uint32_t kind = 0;
        uint32_t enabled = 0;
        uint32_t length = 0;
        uint32_t granularity = 0;
        uint32_t group_count = 0;
        uint32_t signed_perm = 0;
        std::vector<uint32_t> perm;
        std::vector<uint32_t> kv_perm;
        std::vector<int8_t> signs;
    };
    Axis residual, ffn, head, vocab;
    uint64_t key_space_bits = 0;
    std::vector<std::string> notes;
};

struct RmpManifest {
    RmpPolicy policy;
    uint32_t anti_debug_available = 0;
    std::string platform;
};

struct Manifest {
    ManifestModel model;
    ManifestProvenance prov;
    TransformRecord transform;
    RmpManifest rmp;
    std::vector<ManifestTensor> tensors;
    uint32_t storage_type = 1;
    uint64_t weights_plain_bytes = 0;
    uint32_t bytecode_present = 0;
    uint64_t bytecode_size = 0;
    uint8_t bytecode_digest[32]{};
    VocabData vocab;
    std::vector<std::string> warnings;

    std::vector<uint8_t> Serialize() const;
    static bool Deserialize(std::span<const uint8_t> data, Manifest& out, std::string& err);

    WeightLayout ToLayout() const;
};

namespace vocabcodec {
std::vector<uint8_t> Serialize(const VocabData& v);
bool Deserialize(std::span<const uint8_t> data, VocabData& out, std::string& err);
}

struct ProtectOptions {
    std::string input;
    std::string output;
    bool vm = true;
    bool rmp = true;
    bool transform = true;
    bool force = false;
    bool assume_yes = false;
    uint32_t chunk_kb = 1024;
    uint64_t kdf_opslimit = 3;
    uint64_t kdf_memlimit_kib = 262144;
    uint32_t max_ctx = 0;
    bool keep_vocab = true;
    bool quiet = false;
    bool verify_after_write = true;
    std::string password_from_stdin;
    bool password_stdin = false;
};

struct RunOptions {
    std::string input;
    std::string prompt;
    std::vector<int32_t> tokens;
    uint32_t n_predict = 32;
    uint32_t n_ctx = 0;
    uint32_t threads = 0;
    uint32_t cache_mb = 96;
    SamplerConfig sampler;
    bool interactive = false;
    bool show_logits = false;
    bool audit = false;
    bool print_ids = false;
    bool strict_rmp = false;
    std::string password_from_stdin;
    bool password_stdin = false;
};

struct ProtectReport {
    uint64_t source_bytes = 0;
    uint64_t weights_plain_bytes = 0;
    uint64_t output_bytes = 0;
    uint64_t chunks = 0;
    uint64_t tensors = 0;
    uint32_t instr_count = 0;
    double seconds = 0;
    TransformPlan transform;
    Manifest manifest;
};

class ContainerWriter {
public:
    static ProtectReport Protect(const ProtectOptions& opt, const std::string& password,
                                 std::function<void(const std::string&)> stage_cb);
};

class ContainerReader {
public:
    struct OpenResult {
        ContainerHeader header;
        std::vector<SectionEntry> sections;
        bool header_ok = false;
    };

    static OpenResult OpenHeader(const std::string& path, FileReader& fr, std::string& err);
    static bool ReadSection(FileReader& fr, const ContainerHeader& h, const SectionEntry& se,
                            std::span<const uint8_t> key, std::span<const uint8_t, 16> container_id,
                            SecureBytes& out, std::string& err);
    static const SectionEntry* FindSection(const std::vector<SectionEntry>& s, SectionPurpose p);
    static bool VerifyHeaderMac(const ContainerHeader& h, const std::vector<SectionEntry>& s,
                                std::span<const uint8_t> integrity_key);
};

class StreamingWeightProvider : public WeightProvider {
public:
    StreamingWeightProvider(FileReader& fr, const ContainerHeader& h, const SectionEntry& weights,
                            Manifest man, SecureBytes weight_key, std::array<uint8_t, 16> container_id,
                            uint64_t cache_bytes, RmpMonitor* rmp);
    ~StreamingWeightProvider() override;

    const TensorSlot* Slot(uint32_t id) const override;
    size_t SlotCount() const override;
    void ReadRow(uint32_t slot_id, uint64_t row, float* out) override;
    const float* Vector(uint32_t slot_id) override;
    void ReadRaw(uint32_t slot_id, uint64_t byte_off, void* dst, size_t n) override;
    void ReadRowRaw(uint32_t slot_id, uint64_t row, uint8_t* dst) override;
    void SlotDigest(uint32_t slot_id, uint8_t out[32]) override;
    uint64_t BytesDecrypted() const override { return bytes_decrypted_.load(std::memory_order_relaxed); }
    uint64_t RowsServed() const override { return rows_served_.load(std::memory_order_relaxed); }
    void IntegrityTick() override;

private:
    struct CacheEntry {
        uint64_t index = 0;
        SecureBytes data;
    };

    const TensorSlot* RequireSlot(uint32_t slot_id) const;
    const uint8_t* EnsureRangeLocked(uint64_t plain_off, size_t len);
    void CopyRangeLocked(uint64_t plain_off, void* dst, size_t n);
    void FetchChunkLocked(uint64_t index);
    void EvictToLocked(uint64_t target_bytes);
    bool DecryptChunkLocked(uint64_t index, SecureBytes& out_plain);
    void VerifyOrRecordChunk(uint64_t index, std::span<const uint8_t> plain);
    void VerifySlotDigestLocked(uint64_t rotation);

    FileReader& fr_;
    ContainerHeader header_;
    SectionEntry section_;
    Manifest manifest_;
    WeightLayout layout_;
    SecureBytes key_;
    std::array<uint8_t, 16> cid_;
    uint64_t cache_budget_ = 0;
    uint64_t cache_used_ = 0;
    std::atomic<uint64_t> bytes_decrypted_{0};
    std::atomic<uint64_t> rows_served_{0};
    uint64_t chunk_count_ = 0;
    uint32_t chunk_plain_ = 0;
    uint32_t chunk_stored_ = 0;
    RmpMonitor* rmp_ = nullptr;
    uint64_t tick_counter_ = 0;

    std::mutex cache_mu_;
    std::list<CacheEntry> lru_;
    std::unordered_map<uint64_t, std::list<CacheEntry>::iterator> map_;
    std::vector<uint8_t> cipher_buf_;
    std::vector<uint8_t> row_buf_;
    std::vector<uint8_t> chunk_seen_;
    std::unordered_map<uint32_t, std::vector<float>> vec_cache_;
};

struct ContainerHandle {
    std::string path;
    ContainerHeader header;
    std::vector<SectionEntry> sections;
    Manifest manifest;
    ModelSpec spec;
    KeyRing keys;
    VmProgram program;
    std::unique_ptr<RmpMonitor> rmp;
    std::unique_ptr<FileReader> reader;
    std::unique_ptr<StreamingWeightProvider> weights;
    SecureBytes manifest_blob;
    SecureBytes bytecode_blob;
    TransformPlan transform;
    std::vector<uint32_t> vocab_row_of_token;
    std::vector<uint32_t> token_of_vocab_row;
    bool rmp_enabled = false;
    bool vm_enabled = false;
    uint8_t header_mac_expected[32]{};

    ~ContainerHandle();
};

class ProtectedRuntime {
public:
    static std::unique_ptr<ContainerHandle> Open(const std::string& path, const std::string& password,
                                                 const RunOptions& opt);
    static void PrintInfo(const ContainerHandle& h);
    static void Audit(ContainerHandle& h, RmpReport& report);

    struct GenerationStats {
        uint32_t prompt_tokens = 0;
        uint32_t generated = 0;
        double prompt_seconds = 0;
        double generate_seconds = 0;
        uint64_t instructions = 0;
        uint64_t bytes_decrypted = 0;
        uint64_t rmp_checks = 0;
        std::vector<RmpFinding> findings;
    };

    static void Generate(ContainerHandle& h, const std::vector<int32_t>& prompt_ids, const RunOptions& opt,
                         std::vector<int32_t>& out_ids, GenerationStats& stats);
};

class GgufReaderAccess {
public:
    GgufReaderAccess(FileReader& fr, const GgufInfo& g) : fr_(fr), g_(g) {}
    bool ReadTensorRows(const GgufTensorInfo& t, uint64_t row_begin, uint64_t row_count, uint8_t* dst);
    std::vector<float> DequantTensor(const GgufTensorInfo& t, uint64_t max_elems, bool& ok);
    FileReader& File() { return fr_; }
    const GgufInfo& Info() const { return g_; }

private:
    FileReader& fr_;
    const GgufInfo& g_;
};

struct WeightTransformEngine {
    static TransformPlan Plan(const ModelSpec& spec, const WeightLayout& layout, bool want_transform);
    static uint64_t TransformMaskFor(const TensorSlot& s, const TransformPlan& plan);
    static uint64_t MapRow(const TensorSlot& s, const TransformPlan& plan, uint64_t dst_row);
    static int8_t RowSign(const TensorSlot& s, const TransformPlan& plan, uint64_t dst_row);
    static void TransformRowBytes(const TensorSlot& s, const TransformPlan& plan, uint64_t dst_row,
                                  const uint8_t* src, uint8_t* dst);
    static void ElementMap(const AxisPlan& ax, bool signed_axis, std::vector<uint32_t>& idx,
                           std::vector<int8_t>& sign);
    static bool VerifyEquivalence(const ModelSpec& spec, const WeightLayout& layout,
                                  const TransformPlan& plan, GgufReaderAccess& src, std::string& err);
};

struct CliOptions {
    enum class Command { kNone, kProtect, kRun, kInspect, kSelfTest, kVersion, kHelp };
    Command command = Command::kNone;
    ProtectOptions protect;
    RunOptions run;
    std::string inspect_path;
    bool self_test_verbose = false;
    std::vector<std::string> errors;
    bool show_help = false;
};

class Cli {
public:
    static CliOptions Parse(const std::vector<std::string>& args);
    static CliOptions ParseInner(const std::vector<std::string>& args);
    static std::string HelpText();
    static std::string VersionText();
    static void PrintUsageError(const std::string& msg);
};

struct SelfTestResult {
    std::string name;
    bool passed = false;
    std::string detail;
    double seconds = 0.0;
};

class SelfTest {
public:
    static int Run(bool verbose, const std::string& filter);
    static std::vector<SelfTestResult> All(bool verbose);

private:
    static SelfTestResult CryptoRoundTrip(bool verbose);
    static SelfTestResult KdfAndKeys(bool verbose);
    static SelfTestResult GgufSynthetic(bool verbose);
    static SelfTestResult GgufMalformed(bool verbose);
    static SelfTestResult DequantReference(bool verbose);
    static SelfTestResult ContainerRoundTrip(bool verbose);
    static SelfTestResult TamperDetection(bool verbose);
    static SelfTestResult BytecodeVerifier(bool verbose);
    static SelfTestResult VmMicroProgram(bool verbose);
    static SelfTestResult TransformEquivalence(bool verbose);
    static SelfTestResult RmpBehaviour(bool verbose);
    static SelfTestResult CliParsing(bool verbose);
    static SelfTestResult TokenizerRoundTrip(bool verbose);
};

struct TinyModelFactory {
    static std::vector<uint8_t> BuildGguf(uint32_t n_layer, uint32_t n_embd, uint32_t n_ff,
                                          uint32_t n_head, uint32_t n_head_kv, uint32_t n_vocab,
                                          uint32_t quant_type, uint64_t seed,
                                          const std::string& arch = "llama");
    static ModelSpec SpecFor(uint32_t n_layer, uint32_t n_embd, uint32_t n_ff, uint32_t n_head,
                             uint32_t n_head_kv, uint32_t n_vocab, const std::string& arch);
};

struct GenerationRequest {
    std::vector<int32_t> prompt_ids;
    uint32_t n_predict = 32;
};

int MainProtect(const ProtectOptions& opt, std::function<std::string()> password_provider);
int MainRun(const RunOptions& opt, std::function<std::string()> password_provider);
int MainInspect(const std::string& path, std::function<std::string()> password_provider, bool need_password);
int MainSelfTest(bool verbose, const std::string& filter);
int MainVersion();
int MainHelp();
int RunCli(int argc, char** argv);
int RunCliStrings(const std::vector<std::string>& args);
void WipeString(std::string& s);

std::string ProductBanner();

}
