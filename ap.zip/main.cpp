#include "main.h"

#include <algorithm>
#include <cerrno>
#include <numeric>

#if defined(AIP_PLATFORM_WINDOWS)
#include <direct.h>
#include <sys/utime.h>
#else
#include <dirent.h>
#include <sys/time.h>
#endif

namespace aip {

ExitCode ExitCodeForClass(ErrClass c) {
    switch (c) {
        case ErrClass::kUsage: return ExitCode::kUsageError;
        case ErrClass::kIoInput: return ExitCode::kInputFileError;
        case ErrClass::kIoOutput: return ExitCode::kOutputFileError;
        case ErrClass::kFormat: return ExitCode::kFormatError;
        case ErrClass::kUnsupported: return ExitCode::kUnsupportedModel;
        case ErrClass::kCrypto: return ExitCode::kCryptoError;
        case ErrClass::kAuth: return ExitCode::kAuthError;
        case ErrClass::kIntegrity: return ExitCode::kIntegrityViolation;
        case ErrClass::kRuntime: return ExitCode::kRuntimeError;
        case ErrClass::kMemory: return ExitCode::kOutOfMemory;
        case ErrClass::kAborted: return ExitCode::kAborted;
        case ErrClass::kInternal:
        default: return ExitCode::kGenericError;
    }
}

std::string FormatErrorVa(const char* fmt, va_list ap) {
    char stack_buf[1024];
    va_list copy;
    va_copy(copy, ap);
    int n = vsnprintf(stack_buf, sizeof(stack_buf), fmt, copy);
    va_end(copy);
    if (n < 0) return std::string(fmt);
    if (static_cast<size_t>(n) < sizeof(stack_buf)) return std::string(stack_buf, static_cast<size_t>(n));
    std::vector<char> big(static_cast<size_t>(n) + 1);
    va_list copy2;
    va_copy(copy2, ap);
    vsnprintf(big.data(), big.size(), fmt, copy2);
    va_end(copy2);
    return std::string(big.data(), static_cast<size_t>(n));
}

std::string FormatErrorF(const char* fmt, ...) {
    va_list ap;
    va_start(ap, fmt);
    std::string s = FormatErrorVa(fmt, ap);
    va_end(ap);
    return s;
}

void ThrowError(ErrClass c, const std::string& msg) {
    throw AiError(c, msg);
}

void ThrowErrorF(ErrClass c, const char* fmt, ...) {
    va_list ap;
    va_start(ap, fmt);
    std::string s = FormatErrorVa(fmt, ap);
    va_end(ap);
    throw AiError(c, s);
}

std::string LastOsError() {
    int e = errno;
    if (e == 0) return "no error information";
    char buf[256];
#if defined(AIP_PLATFORM_WINDOWS)
    if (strerror_s(buf, sizeof(buf), e) != 0) snprintf(buf, sizeof(buf), "errno %d", e);
#else
    if (strerror_r(e, buf, sizeof(buf)) != 0) snprintf(buf, sizeof(buf), "errno %d", e);
#endif
    return std::string(buf) + " (errno " + std::to_string(e) + ")";
}

bool Console::StdoutIsTty() {
#if defined(AIP_PLATFORM_WINDOWS)
    return _isatty(_fileno(stdout)) != 0;
#else
    return isatty(fileno(stdout)) != 0;
#endif
}

bool Console::StdinIsTty() {
#if defined(AIP_PLATFORM_WINDOWS)
    return _isatty(_fileno(stdin)) != 0;
#else
    return isatty(fileno(stdin)) != 0;
#endif
}

void Console::Out(const std::string& s) {
    fwrite(s.data(), 1, s.size(), stdout);
    fflush(stdout);
}

void Console::Err(const std::string& s) {
    fwrite(s.data(), 1, s.size(), stderr);
    fflush(stderr);
}

void Console::OutF(const char* fmt, ...) {
    va_list ap;
    va_start(ap, fmt);
    Out(FormatErrorVa(fmt, ap));
    va_end(ap);
}

void Console::ErrF(const char* fmt, ...) {
    va_list ap;
    va_start(ap, fmt);
    Err(FormatErrorVa(fmt, ap));
    va_end(ap);
}

bool Log::quiet = false;
bool Log::verbose = false;

void Log::Info(const char* fmt, ...) {
    if (quiet) return;
    va_list ap;
    va_start(ap, fmt);
    Console::Out(FormatErrorVa(fmt, ap));
    va_end(ap);
}

void Log::Warn(const char* fmt, ...) {
    if (quiet) return;
    va_list ap;
    va_start(ap, fmt);
    Console::Err("warning: " + FormatErrorVa(fmt, ap));
    va_end(ap);
}

void Log::Detail(const char* fmt, ...) {
    if (quiet || !verbose) return;
    va_list ap;
    va_start(ap, fmt);
    Console::Out(FormatErrorVa(fmt, ap));
    va_end(ap);
}

void Log::Stage(const std::string& name) {
    if (quiet) return;
    Console::Out("[*] " + name + "\n");
}

Progress::Progress(std::string label, uint64_t total, bool enabled)
    : label_(std::move(label)), total_(total), enabled_(enabled && !Log::quiet && Console::StdoutIsTty()),
      start_(std::chrono::steady_clock::now()), last_draw_(start_) {}

Progress::~Progress() {
    if (enabled_ && done_ < total_) Console::Out("\n");
}

void Progress::Render(bool force) {
    if (!enabled_) return;
    int percent = total_ ? static_cast<int>((static_cast<unsigned long long>(done_) * 100ull) / total_) : 0;
    if (percent > 100) percent = 100;
    auto now = std::chrono::steady_clock::now();
    double ms = std::chrono::duration<double, std::milli>(now - last_draw_).count();
    if (!force && percent == last_percent_ && ms < 120.0) return;
    last_draw_ = now;
    last_percent_ = percent;
    double elapsed = std::chrono::duration<double>(now - start_).count();
    double rate = elapsed > 1e-6 ? static_cast<double>(done_) / elapsed : 0.0;
    int width = 28;
    int filled = static_cast<int>((static_cast<long long>(percent) * width) / 100);
    std::string bar(static_cast<size_t>(filled), '#');
    bar.append(static_cast<size_t>(width - filled), '.');
    Console::OutF("\r    %s [%s] %3d%%  %s / %s  %s/s   ", label_.c_str(), bar.c_str(), percent,
                  HumanBytes(done_).c_str(), HumanBytes(total_).c_str(), HumanRate(rate).c_str());
}

void Progress::Set(uint64_t done) {
    done_ = done;
    Render(false);
}

void Progress::Bump(uint64_t delta) {
    done_ += delta;
    Render(false);
}

void Progress::Finish() {
    done_ = total_;
    Render(true);
    if (enabled_) Console::Out("\n");
    enabled_ = false;
}

std::string HumanBytes(uint64_t v) {
    static const char* units[] = {"B", "KiB", "MiB", "GiB", "TiB", "PiB"};
    double d = static_cast<double>(v);
    int u = 0;
    while (d >= 1024.0 && u < 5) {
        d /= 1024.0;
        u++;
    }
    char buf[64];
    if (u == 0) snprintf(buf, sizeof(buf), "%llu B", static_cast<unsigned long long>(v));
    else snprintf(buf, sizeof(buf), "%.2f %s", d, units[u]);
    return std::string(buf);
}

std::string HumanRate(double bps) {
    return HumanBytes(static_cast<uint64_t>(bps > 0 ? bps : 0)) ;
}

std::string HexEncode(const uint8_t* data, size_t len) {
    static const char* hex = "0123456789abcdef";
    std::string s;
    s.resize(len * 2);
    for (size_t i = 0; i < len; i++) {
        s[i * 2] = hex[(data[i] >> 4) & 0xF];
        s[i * 2 + 1] = hex[data[i] & 0xF];
    }
    return s;
}

std::string HexEncode(std::span<const uint8_t> d) {
    return HexEncode(d.data(), d.size());
}

bool HexDecode(const std::string& in, std::vector<uint8_t>& out) {
    if (in.size() % 2 != 0) return false;
    out.clear();
    out.reserve(in.size() / 2);
    auto nib = [](char c, int& v) -> bool {
        if (c >= '0' && c <= '9') { v = c - '0'; return true; }
        if (c >= 'a' && c <= 'f') { v = c - 'a' + 10; return true; }
        if (c >= 'A' && c <= 'F') { v = c - 'A' + 10; return true; }
        return false;
    };
    for (size_t i = 0; i < in.size(); i += 2) {
        int hi = 0, lo = 0;
        if (!nib(in[i], hi) || !nib(in[i + 1], lo)) return false;
        out.push_back(static_cast<uint8_t>((hi << 4) | lo));
    }
    return true;
}

void WipeString(std::string& s) {
    if (!s.empty()) sodium_memzero(&s[0], s.size());
    s.clear();
    s.shrink_to_fit();
}

#if defined(AIP_PLATFORM_WINDOWS)
static std::wstring Utf8ToWide(const std::string& s) {
    if (s.empty()) return std::wstring();
    int n = MultiByteToWideChar(CP_UTF8, 0, s.c_str(), static_cast<int>(s.size()), nullptr, 0);
    std::wstring w(static_cast<size_t>(n), L'\0');
    MultiByteToWideChar(CP_UTF8, 0, s.c_str(), static_cast<int>(s.size()), &w[0], n);
    return w;
}
static std::string WideToUtf8(const std::wstring& w) {
    if (w.empty()) return std::string();
    int n = WideCharToMultiByte(CP_UTF8, 0, w.c_str(), static_cast<int>(w.size()), nullptr, 0, nullptr, nullptr);
    std::string s(static_cast<size_t>(n), '\0');
    WideCharToMultiByte(CP_UTF8, 0, w.c_str(), static_cast<int>(w.size()), &s[0], n, nullptr, nullptr);
    return s;
}
#endif

std::string fsx::Utf8FromArgv(const char* s) {
#if defined(AIP_PLATFORM_WINDOWS)
    int wlen = MultiByteToWideChar(CP_ACP, 0, s, -1, nullptr, 0);
    if (wlen <= 0) return std::string(s);
    std::wstring w(static_cast<size_t>(wlen), L'\0');
    MultiByteToWideChar(CP_ACP, 0, s, -1, &w[0], wlen);
    int ulen = WideCharToMultiByte(CP_UTF8, 0, w.c_str(), -1, nullptr, 0, nullptr, nullptr);
    if (ulen <= 0) return std::string(s);
    std::string u(static_cast<size_t>(ulen), '\0');
    WideCharToMultiByte(CP_UTF8, 0, w.c_str(), -1, &u[0], ulen, nullptr, nullptr);
    while (!u.empty() && u.back() == '\0') u.pop_back();
    return u;
#else
    return std::string(s);
#endif
}

static std::FILE* OpenReadBinary(const std::string& path) {
#if defined(AIP_PLATFORM_WINDOWS)
    std::wstring w = Utf8ToWide(path);
    return _wfopen(w.c_str(), L"rb");
#else
    return fopen(path.c_str(), "rb");
#endif
}

static std::FILE* OpenWriteBinary(const std::string& path) {
#if defined(AIP_PLATFORM_WINDOWS)
    std::wstring w = Utf8ToWide(path);
    return _wfopen(w.c_str(), L"wb");
#else
    return fopen(path.c_str(), "wb");
#endif
}

static bool Seek64(std::FILE* fp, uint64_t pos) {
#if defined(AIP_PLATFORM_WINDOWS)
    return _fseeki64(fp, static_cast<__int64>(pos), SEEK_SET) == 0;
#else
    return fseeko(fp, static_cast<off_t>(pos), SEEK_SET) == 0;
#endif
}

static uint64_t Size64(std::FILE* fp) {
#if defined(AIP_PLATFORM_WINDOWS)
    __int64 cur = _ftelli64(fp);
    if (_fseeki64(fp, 0, SEEK_END) != 0) return 0;
    __int64 v = _ftelli64(fp);
    if (cur >= 0) _fseeki64(fp, cur, SEEK_SET);
    return v < 0 ? 0 : static_cast<uint64_t>(v);
#else
    off_t cur = ftello(fp);
    if (fseeko(fp, 0, SEEK_END) != 0) return 0;
    off_t v = ftello(fp);
    if (cur >= 0) fseeko(fp, cur, SEEK_SET);
    return v < 0 ? 0 : static_cast<uint64_t>(v);
#endif
}

bool fsx::Exists(const std::string& p) {
#if defined(AIP_PLATFORM_WINDOWS)
    DWORD a = GetFileAttributesW(Utf8ToWide(p).c_str());
    return a != INVALID_FILE_ATTRIBUTES;
#else
    struct stat st;
    return stat(p.c_str(), &st) == 0;
#endif
}

bool fsx::IsRegularFile(const std::string& p) {
#if defined(AIP_PLATFORM_WINDOWS)
    DWORD a = GetFileAttributesW(Utf8ToWide(p).c_str());
    return a != INVALID_FILE_ATTRIBUTES && !(a & FILE_ATTRIBUTE_DIRECTORY);
#else
    struct stat st;
    if (stat(p.c_str(), &st) != 0) return false;
    return S_ISREG(st.st_mode) != 0;
#endif
}

bool fsx::IsDirectory(const std::string& p) {
#if defined(AIP_PLATFORM_WINDOWS)
    DWORD a = GetFileAttributesW(Utf8ToWide(p).c_str());
    return a != INVALID_FILE_ATTRIBUTES && (a & FILE_ATTRIBUTE_DIRECTORY) != 0;
#else
    struct stat st;
    if (stat(p.c_str(), &st) != 0) return false;
    return S_ISDIR(st.st_mode) != 0;
#endif
}

uint64_t fsx::FileSize(const std::string& p, bool& ok) {
    ok = false;
#if defined(AIP_PLATFORM_WINDOWS)
    WIN32_FILE_ATTRIBUTE_DATA fad;
    if (!GetFileAttributesExW(Utf8ToWide(p).c_str(), GetFileExInfoStandard, &fad)) return 0;
    ULARGE_INTEGER u;
    u.LowPart = fad.nFileSizeLow;
    u.HighPart = fad.nFileSizeHigh;
    ok = true;
    return u.QuadPart;
#else
    struct stat st;
    if (stat(p.c_str(), &st) != 0) return 0;
    ok = true;
    return static_cast<uint64_t>(st.st_size);
#endif
}

std::string fsx::DirName(const std::string& p) {
    size_t pos = p.find_last_of("/\\");
    if (pos == std::string::npos) return std::string(".");
    if (pos == 0) return std::string(p, 0, 1);
    return p.substr(0, pos);
}

std::string fsx::FileName(const std::string& p) {
    size_t pos = p.find_last_of("/\\");
    if (pos == std::string::npos) return p;
    return p.substr(pos + 1);
}

std::string fsx::Absolute(const std::string& p, bool& ok) {
    ok = false;
#if defined(AIP_PLATFORM_WINDOWS)
    std::wstring w = Utf8ToWide(p);
    DWORD need = GetFullPathNameW(w.c_str(), 0, nullptr, nullptr);
    if (need == 0) return p;
    std::wstring buf(static_cast<size_t>(need), L'\0');
    DWORD got = GetFullPathNameW(w.c_str(), need, &buf[0], nullptr);
    if (got == 0 || got >= need) return p;
    buf.resize(got);
    ok = true;
    return WideToUtf8(buf);
#else
    char buf[8192];
    if (realpath(p.c_str(), buf) == nullptr) {
        if (!p.empty() && p[0] == '/') { ok = true; return p; }
        char cwd[4096];
        if (getcwd(cwd, sizeof(cwd)) == nullptr) return p;
        ok = true;
        return std::string(cwd) + "/" + p;
    }
    ok = true;
    return std::string(buf);
#endif
}

bool fsx::SameFile(const std::string& a, const std::string& b) {
#if defined(AIP_PLATFORM_WINDOWS)
    BY_HANDLE_FILE_INFORMATION ia, ib;
    HANDLE ha = CreateFileW(Utf8ToWide(a).c_str(), 0, FILE_SHARE_READ | FILE_SHARE_WRITE, nullptr,
                            OPEN_EXISTING, FILE_ATTRIBUTE_NORMAL, nullptr);
    HANDLE hb = CreateFileW(Utf8ToWide(b).c_str(), 0, FILE_SHARE_READ | FILE_SHARE_WRITE, nullptr,
                            OPEN_EXISTING, FILE_ATTRIBUTE_NORMAL, nullptr);
    bool same = false;
    if (ha != INVALID_HANDLE_VALUE && hb != INVALID_HANDLE_VALUE) {
        if (GetFileInformationByHandle(ha, &ia) && GetFileInformationByHandle(hb, &ib)) {
            same = ia.dwVolumeSerialNumber == ib.dwVolumeSerialNumber &&
                   ia.nFileIndexHigh == ib.nFileIndexHigh && ia.nFileIndexLow == ib.nFileIndexLow;
        }
    }
    if (ha != INVALID_HANDLE_VALUE) CloseHandle(ha);
    if (hb != INVALID_HANDLE_VALUE) CloseHandle(hb);
    return same;
#else
    struct stat sa, sb;
    if (stat(a.c_str(), &sa) != 0) return false;
    if (stat(b.c_str(), &sb) != 0) return false;
    return sa.st_dev == sb.st_dev && sa.st_ino == sb.st_ino;
#endif
}

uint64_t fsx::FreeSpaceFor(const std::string& path, bool& ok) {
    ok = false;
    std::string target = path;
    if (!IsDirectory(target)) {
        target = DirName(target);
        if (target.empty()) target = ".";
    }
#if defined(AIP_PLATFORM_WINDOWS)
    ULARGE_INTEGER free_bytes{};
    if (!GetDiskFreeSpaceExW(Utf8ToWide(target).c_str(), &free_bytes, nullptr, nullptr)) return 0;
    ok = true;
    return free_bytes.QuadPart;
#else
    struct statvfs vfs;
    if (statvfs(target.c_str(), &vfs) != 0) return 0;
    ok = true;
    return static_cast<uint64_t>(vfs.f_bavail) * static_cast<uint64_t>(vfs.f_frsize);
#endif
}

FileReader::FileReader() = default;

FileReader::~FileReader() { Close(); }

bool FileReader::Open(const std::string& path, std::string& err) {
    Close();
    std::FILE* fp = OpenReadBinary(path);
    if (!fp) {
        err = "cannot open '" + path + "' for reading: " + LastOsError();
        return false;
    }
    uint64_t sz = Size64(fp);
    if (!Seek64(fp, 0)) {
        err = "cannot rewind '" + path + "': " + LastOsError();
        fclose(fp);
        return false;
    }
    fp_ = fp;
    size_ = sz;
    cur_ = 0;
    path_ = path;
    return true;
}

void FileReader::Close() {
    if (fp_) {
        fclose(fp_);
        fp_ = nullptr;
    }
    size_ = 0;
    cur_ = 0;
}

uint64_t FileReader::Tell() const { return cur_; }

bool FileReader::Seek(uint64_t pos) {
    if (!fp_) return false;
    if (pos > size_) return false;
    if (pos == cur_) return true;
    if (!Seek64(fp_, pos)) return false;
    cur_ = pos;
    return true;
}

bool FileReader::ReadExact(void* dst, size_t n) {
    if (!fp_) return false;
    if (n == 0) return true;
    if (cur_ + n < cur_) return false;
    if (cur_ + n > size_) return false;
    uint8_t* p = static_cast<uint8_t*>(dst);
    size_t got = 0;
    while (got < n) {
        size_t want = std::min<size_t>(n - got, static_cast<size_t>(1) << 30);
        size_t r = fread(p + got, 1, want, fp_);
        if (r == 0) {
            if (ferror(fp_)) return false;
            return false;
        }
        got += r;
    }
    cur_ += got;
    return true;
}

bool FileReader::ReadAt(uint64_t pos, void* dst, size_t n) {
    if (!Seek(pos)) return false;
    return ReadExact(dst, n);
}

std::vector<uint8_t> FileReader::ReadBlockAt(uint64_t pos, size_t n, bool& ok) {
    std::vector<uint8_t> v;
    ok = false;
    if (n == 0) { ok = true; return v; }
    try {
        v.resize(n);
    } catch (const std::bad_alloc&) {
        return v;
    }
    ok = ReadAt(pos, v.data(), n);
    return v;
}

AtomicFileWriter::AtomicFileWriter() = default;

AtomicFileWriter::~AtomicFileWriter() { Abort(); }

bool AtomicFileWriter::RemoveFile(const std::string& p) {
    if (p.empty()) return false;
#if defined(AIP_PLATFORM_WINDOWS)
    return DeleteFileW(Utf8ToWide(p).c_str()) != 0;
#else
    return unlink(p.c_str()) == 0;
#endif
}

bool AtomicFileWriter::FileExists(const std::string& p) {
    return fsx::Exists(p);
}

uint64_t AtomicFileWriter::AvailableSpace(const std::string& dir, bool& ok) {
    return fsx::FreeSpaceFor(dir, ok);
}

bool AtomicFileWriter::Begin(const std::string& final_path, std::string& err) {
    Abort();
    final_path_ = final_path;
    std::array<uint8_t, 8> rnd{};
    random::Bytes(rnd.data(), rnd.size());
    char suffix[64];
    snprintf(suffix, sizeof(suffix), ".aipart-%08x%08x",
             static_cast<unsigned>(std::hash<std::string>{}(final_path) & 0xFFFFFFFFu),
             static_cast<unsigned>(rnd[0]) | (static_cast<unsigned>(rnd[1]) << 8) |
                 (static_cast<unsigned>(rnd[2]) << 16) | (static_cast<unsigned>(rnd[3]) << 24));
    temp_path_ = final_path + suffix;
    std::FILE* fp = OpenWriteBinary(temp_path_);
    if (!fp) {
        err = "cannot create temporary output file '" + temp_path_ + "': " + LastOsError();
        temp_path_.clear();
        return false;
    }
    fp_ = fp;
    written_ = 0;
    high_ = 0;
    committed_ = false;
    return true;
}

bool AtomicFileWriter::Write(const void* src, size_t n) {
    if (!fp_) return false;
    if (n == 0) return true;
    const uint8_t* p = static_cast<const uint8_t*>(src);
    size_t done = 0;
    while (done < n) {
        size_t want = std::min<size_t>(n - done, static_cast<size_t>(1) << 30);
        size_t w = fwrite(p + done, 1, want, fp_);
        if (w == 0) return false;
        done += w;
    }
    written_ += done;
    if (written_ > high_) high_ = written_;
    return true;
}

bool AtomicFileWriter::WriteAt(uint64_t pos, const void* src, size_t n) {
    if (!fp_) return false;
    if (!Seek64(fp_, pos)) return false;
    size_t done = 0;
    const uint8_t* p = static_cast<const uint8_t*>(src);
    while (done < n) {
        size_t want = std::min<size_t>(n - done, static_cast<size_t>(1) << 30);
        size_t w = fwrite(p + done, 1, want, fp_);
        if (w == 0) return false;
        done += w;
    }
    uint64_t now = pos + done;
    if (now > high_) high_ = now;
    written_ = high_;
    return true;
}

bool AtomicFileWriter::Commit(std::string& err) {
    if (!fp_) {
        err = "output stream is not open";
        return false;
    }
    if (fflush(fp_) != 0) {
        err = "cannot flush output file: " + LastOsError();
        return false;
    }
#if defined(AIP_PLATFORM_WINDOWS)
    if (_commit(_fileno(fp_)) != 0) {
        err = "cannot sync output file: " + LastOsError();
        return false;
    }
#else
    if (fsync(fileno(fp_)) != 0) {
        err = "cannot sync output file: " + LastOsError();
        return false;
    }
#endif
    if (fclose(fp_) != 0) {
        fp_ = nullptr;
        err = "cannot close output file: " + LastOsError();
        RemoveFile(temp_path_);
        temp_path_.clear();
        return false;
    }
    fp_ = nullptr;
#if defined(AIP_PLATFORM_WINDOWS)
    if (!MoveFileExW(Utf8ToWide(temp_path_).c_str(), Utf8ToWide(final_path_).c_str(),
                     MOVEFILE_REPLACE_EXISTING | MOVEFILE_WRITE_THROUGH)) {
        err = "cannot finalize output file '" + final_path_ + "': " + LastOsError();
        RemoveFile(temp_path_);
        temp_path_.clear();
        return false;
    }
#else
    if (rename(temp_path_.c_str(), final_path_.c_str()) != 0) {
        err = "cannot finalize output file '" + final_path_ + "': " + LastOsError();
        RemoveFile(temp_path_);
        temp_path_.clear();
        return false;
    }
    std::string dir = fsx::DirName(final_path_);
    int dfd = open(dir.c_str(), O_RDONLY);
    if (dfd >= 0) {
        fsync(dfd);
        close(dfd);
    }
#endif
    committed_ = true;
    std::string finished = temp_path_;
    temp_path_.clear();
    (void)finished;
    return true;
}

void AtomicFileWriter::Abort() {
    if (fp_) {
        fclose(fp_);
        fp_ = nullptr;
    }
    if (!temp_path_.empty() && !committed_) RemoveFile(temp_path_);
    temp_path_.clear();
}

#if defined(AIP_PLATFORM_WINDOWS)
struct TermRestore {
    HANDLE h = INVALID_HANDLE_VALUE;
    DWORD mode = 0;
    bool valid = false;
    ~TermRestore() {
        if (valid) SetConsoleMode(h, mode);
    }
};
#else
struct TermRestore {
    int fd = -1;
    termios saved{};
    bool valid = false;
    ~TermRestore() {
        if (valid) tcsetattr(fd, TCSAFLUSH, &saved);
    }
};
#endif

static bool ReadHiddenFromFd(int fd, std::string& out) {
#if defined(AIP_PLATFORM_WINDOWS)
    (void)fd;
    return false;
#else
    termios old_t{};
    if (tcgetattr(fd, &old_t) != 0) return false;
    termios new_t = old_t;
    new_t.c_lflag &= ~static_cast<tcflag_t>(ECHO);
    if (tcsetattr(fd, TCSAFLUSH, &new_t) != 0) return false;
    out.clear();
    char c = 0;
    while (true) {
        ssize_t r = read(fd, &c, 1);
        if (r <= 0) break;
        if (c == '\n' || c == '\r') break;
        if (c == 3) {
            tcsetattr(fd, TCSAFLUSH, &old_t);
            return false;
        }
        if (c == 127 || c == 8) {
            if (!out.empty()) out.pop_back();
            continue;
        }
        if (static_cast<unsigned char>(c) >= 32) out.push_back(c);
        if (out.size() > 4096) break;
    }
    tcsetattr(fd, TCSAFLUSH, &old_t);
    return true;
#endif
}

bool PasswordInput::ReadHidden(const std::string& prompt, std::string& out, std::string& err) {
    out.clear();
#if defined(AIP_PLATFORM_WINDOWS)
    Console::Err(prompt);
    HANDLE h = GetStdHandle(STD_INPUT_HANDLE);
    DWORD mode = 0;
    bool console_mode = h != INVALID_HANDLE_VALUE && GetConsoleMode(h, &mode) != 0;
    TermRestore guard;
    if (console_mode) {
        guard.h = h;
        guard.mode = mode;
        guard.valid = true;
        SetConsoleMode(h, mode & ~static_cast<DWORD>(ENABLE_ECHO_INPUT));
    }
    std::string line;
    line.reserve(256);
    char buf[512];
    if (!fgets(buf, sizeof(buf), stdin)) {
        if (console_mode) SetConsoleMode(h, mode);
        err = "failed to read password from standard input";
        WipeString(line);
        return false;
    }
    if (console_mode) SetConsoleMode(h, mode);
    Console::Err("\n");
    line.assign(buf);
    sodium_memzero(buf, sizeof(buf));
    while (!line.empty() && (line.back() == '\n' || line.back() == '\r')) line.pop_back();
    out.swap(line);
    return true;
#else
    Console::Err(prompt);
    fflush(stderr);
    int fd = -1;
    bool own_fd = false;
    if (isatty(STDIN_FILENO)) {
        fd = STDIN_FILENO;
    } else {
        fd = open("/dev/tty", O_RDWR);
        own_fd = fd >= 0;
    }
    if (fd < 0) {
        char buf[512];
        if (!fgets(buf, sizeof(buf), stdin)) {
            err = "failed to read password from standard input";
            return false;
        }
        out.assign(buf);
        sodium_memzero(buf, sizeof(buf));
        while (!out.empty() && (out.back() == '\n' || out.back() == '\r')) out.pop_back();
        return true;
    }
    std::string tmp;
    bool ok = ReadHiddenFromFd(fd, tmp);
    if (own_fd) close(fd);
    if (ok) {
        write(STDERR_FILENO, "\n", 1);
        out.swap(tmp);
        return true;
    }
    WipeString(tmp);
    err = "terminal refused hidden input: " + LastOsError();
    return false;
#endif
}

bool PasswordInput::ReadLine(const std::string& prompt, std::string& out, std::string& err) {
    out.clear();
    if (!prompt.empty()) Console::Err(prompt);
    char buf[8192];
    if (!fgets(buf, sizeof(buf), stdin)) {
        err = "unexpected end of standard input";
        return false;
    }
    out.assign(buf);
    sodium_memzero(buf, sizeof(buf));
    while (!out.empty() && (out.back() == '\n' || out.back() == '\r')) out.pop_back();
    return true;
}

bool PasswordInput::ReadWithConfirm(const std::string& prompt, std::string& out, std::string& err) {
    std::string first, second;
    if (!ReadHidden(prompt, first, err)) {
        WipeString(first);
        return false;
    }
    if (!ReadHidden("repeat password: ", second, err)) {
        WipeString(first);
        WipeString(second);
        return false;
    }
    bool same = first.size() == second.size();
    unsigned char diff = 0;
    for (size_t i = 0; same && i < first.size(); i++) {
        diff |= static_cast<unsigned char>(first[i]) ^ static_cast<unsigned char>(second[i]);
    }
    WipeString(second);
    if (diff != 0) {
        WipeString(first);
        err = "passwords do not match";
        return false;
    }
    out.swap(first);
    WipeString(first);
    return true;
}

void random::Bytes(uint8_t* p, size_t n) {
    randombytes_buf(p, n);
}

uint64_t random::Uniform64() {
    uint64_t v = 0;
    randombytes_buf(&v, sizeof(v));
    return v;
}

uint32_t random::Below(uint32_t n) {
    if (n <= 1) return 0;
    return static_cast<uint32_t>(randombytes_uniform(n));
}

void random::Shuffle(uint32_t* v, size_t n) {
    for (size_t i = n; i > 1; i--) {
        size_t j = static_cast<size_t>(random::Below(static_cast<uint32_t>(i)));
        std::swap(v[i - 1], v[j]);
    }
}

void ByteWriter::U8(uint8_t v) { b_.push_back(v); }
void ByteWriter::U16(uint16_t v) { uint8_t t[2]; memcpy(t, &v, 2); b_.insert(b_.end(), t, t + 2); }
void ByteWriter::U32(uint32_t v) { uint8_t t[4]; memcpy(t, &v, 4); b_.insert(b_.end(), t, t + 4); }
void ByteWriter::U64(uint64_t v) { uint8_t t[8]; memcpy(t, &v, 8); b_.insert(b_.end(), t, t + 8); }
void ByteWriter::I32(int32_t v) { uint32_t u; memcpy(&u, &v, 4); U32(u); }
void ByteWriter::I64(int64_t v) { uint64_t u; memcpy(&u, &v, 8); U64(u); }
void ByteWriter::F32(float v) { uint32_t u; memcpy(&u, &v, 4); U32(u); }
void ByteWriter::Raw(const void* p, size_t n) {
    const uint8_t* q = static_cast<const uint8_t*>(p);
    b_.insert(b_.end(), q, q + n);
}
void ByteWriter::Raw(std::span<const uint8_t> d) { Raw(d.data(), d.size()); }
void ByteWriter::Str(const std::string& s) {
    U32(static_cast<uint32_t>(s.size()));
    Raw(s.data(), s.size());
}
void ByteWriter::Pad(size_t n) { b_.insert(b_.end(), n, 0); }

bool ByteReader::Need(size_t n) const {
    if (failed_) return false;
    if (n > n_ || pos_ > n_ - n) {
        failed_ = true;
        return false;
    }
    return true;
}

bool ByteReader::U8(uint8_t& v) { if (!Need(1)) return false; v = p_[pos_]; pos_ += 1; return true; }
bool ByteReader::U16(uint16_t& v) { if (!Need(2)) return false; memcpy(&v, p_ + pos_, 2); pos_ += 2; return true; }
bool ByteReader::U32(uint32_t& v) { if (!Need(4)) return false; memcpy(&v, p_ + pos_, 4); pos_ += 4; return true; }
bool ByteReader::U64(uint64_t& v) { if (!Need(8)) return false; memcpy(&v, p_ + pos_, 8); pos_ += 8; return true; }
bool ByteReader::I32(int32_t& v) { uint32_t u; if (!U32(u)) return false; memcpy(&v, &u, 4); return true; }
bool ByteReader::I64(int64_t& v) { uint64_t u; if (!U64(u)) return false; memcpy(&v, &u, 8); return true; }
bool ByteReader::F32(float& v) { uint32_t u; if (!U32(u)) return false; memcpy(&v, &u, 4); return true; }
bool ByteReader::Raw(void* dst, size_t n) {
    if (!Need(n)) return false;
    memcpy(dst, p_ + pos_, n);
    pos_ += n;
    return true;
}
bool ByteReader::Skip(size_t n) {
    if (!Need(n)) return false;
    pos_ += n;
    return true;
}
bool ByteReader::Str(std::string& out, size_t max_len) {
    uint32_t len = 0;
    if (!U32(len)) return false;
    if (len > max_len) { failed_ = true; return false; }
    if (!Need(len)) return false;
    out.assign(reinterpret_cast<const char*>(p_ + pos_), len);
    pos_ += len;
    return true;
}

}
namespace aip {
namespace quant {

static inline uint16_t LoadU16(const uint8_t* p) {
    uint16_t v;
    memcpy(&v, p, 2);
    return v;
}

static inline uint32_t LoadU32(const uint8_t* p) {
    uint32_t v;
    memcpy(&v, p, 4);
    return v;
}

static inline int8_t LoadI8(const uint8_t* p) {
    return static_cast<int8_t>(*p);
}

static inline float LoadHalf(const uint8_t* p) {
    return HalfToFloat(LoadU16(p));
}

uint16_t FloatToHalf(float value) {
    uint32_t f;
    memcpy(&f, &value, 4);
    uint32_t sign = (f >> 16) & 0x8000u;
    int32_t exp = static_cast<int32_t>((f >> 23) & 0xFFu) - 127;
    uint32_t mant = f & 0x7FFFFFu;
    if (exp == 128) {
        uint32_t m = mant ? 0x200u : 0u;
        return static_cast<uint16_t>(sign | 0x7C00u | m);
    }
    if (exp > 15) return static_cast<uint16_t>(sign | 0x7C00u);
    if (exp < -25) return static_cast<uint16_t>(sign);
    if (exp < -14) {
        mant |= 0x800000u;
        int shift = -exp - 1;
        uint32_t m = mant >> shift;
        uint32_t rem = mant & ((1u << shift) - 1u);
        uint32_t half = 1u << (shift - 1);
        if (rem > half || (rem == half && (m & 1u))) m++;
        return static_cast<uint16_t>(sign | m);
    }
    uint32_t e = static_cast<uint32_t>(exp + 15) << 10;
    uint32_t m = mant >> 13;
    uint32_t rem = mant & 0x1FFFu;
    if (rem > 0x1000u || (rem == 0x1000u && (m & 1u))) {
        m++;
        if (m == 0x400u) {
            m = 0;
            e += 0x400u;
        }
        if ((e & 0x7C00u) == 0x7C00u) return static_cast<uint16_t>(sign | 0x7C00u);
    }
    return static_cast<uint16_t>(sign | e | m);
}

float HalfToFloat(uint16_t h) {
    uint32_t sign = static_cast<uint32_t>(h & 0x8000u) << 16;
    uint32_t exp = (h >> 10) & 0x1Fu;
    uint32_t mant = h & 0x3FFu;
    uint32_t f;
    if (exp == 0) {
        if (mant == 0) {
            f = sign;
        } else {
            exp = 1;
            while ((mant & 0x400u) == 0) {
                mant <<= 1;
                exp--;
            }
            mant &= 0x3FFu;
            f = sign | ((exp + 112u) << 23) | (mant << 13);
        }
    } else if (exp == 31) {
        f = sign | 0x7F800000u | (mant << 13);
    } else {
        f = sign | ((exp + 112u) << 23) | (mant << 13);
    }
    float out;
    memcpy(&out, &f, 4);
    return out;
}

static const TypeInfo kTypes[] = {
    {0, "F32", 1, 4, true, false},
    {1, "F16", 1, 2, true, false},
    {2, "Q4_0", 32, 18, true, true},
    {3, "Q4_1", 32, 20, true, true},
    {4, "Q4_2(removed)", 0, 0, false, true},
    {5, "Q4_3(removed)", 0, 0, false, true},
    {6, "Q5_0", 32, 22, true, true},
    {7, "Q5_1", 32, 24, true, true},
    {8, "Q8_0", 32, 34, true, true},
    {9, "Q8_1", 32, 36, false, true},
    {10, "Q2_K", 256, 84, true, true},
    {11, "Q3_K", 256, 110, true, true},
    {12, "Q4_K", 256, 144, true, true},
    {13, "Q5_K", 256, 176, true, true},
    {14, "Q6_K", 256, 210, true, true},
    {15, "Q8_K", 256, 292, true, true},
    {16, "IQ2_XXS", 256, 66, false, true},
    {17, "IQ2_XS", 256, 68, false, true},
    {18, "IQ3_XXS", 256, 98, false, true},
    {19, "IQ1_S", 256, 50, false, true},
    {20, "IQ4_NL", 32, 18, true, true},
    {21, "IQ3_S", 256, 110, false, true},
    {22, "IQ2_S", 256, 82, false, true},
    {23, "IQ4_XS", 256, 136, true, true},
    {24, "I8", 1, 1, false, false},
    {25, "I16", 1, 2, false, false},
    {26, "I32", 1, 4, false, false},
    {27, "I64", 1, 8, false, false},
    {28, "F64", 1, 8, false, false},
    {29, "IQ1_M", 256, 56, false, true},
    {30, "BF16", 1, 2, true, false},
    {34, "TQ1_0", 256, 54, false, true},
    {35, "TQ2_0", 256, 66, false, true},
};

const TypeInfo* InfoOrNull(uint32_t type_id) {
    for (const auto& t : kTypes) {
        if (t.id == type_id) return &t;
    }
    return nullptr;
}

const TypeInfo* Info(uint32_t type_id) {
    const TypeInfo* t = InfoOrNull(type_id);
    if (!t) ThrowErrorF(ErrClass::kFormat, "unknown GGUF tensor type id %u", type_id);
    return t;
}

bool IsSupported(uint32_t type_id) {
    const TypeInfo* t = InfoOrNull(type_id);
    return t && t->supported_by_aiprotect && t->block_size > 0 && t->type_size > 0;
}

std::string NameOf(uint32_t type_id) {
    const TypeInfo* t = InfoOrNull(type_id);
    return t ? std::string(t->name) : ("unknown(" + std::to_string(type_id) + ")");
}

uint32_t BlockSize(uint32_t type_id) {
    const TypeInfo* t = InfoOrNull(type_id);
    return (t && t->block_size) ? t->block_size : 0;
}

uint32_t TypeSize(uint32_t type_id) {
    const TypeInfo* t = InfoOrNull(type_id);
    return (t && t->type_size) ? t->type_size : 0;
}

double BitsPerWeight(uint32_t type_id) {
    const TypeInfo* t = InfoOrNull(type_id);
    if (!t || !t->block_size) return 0.0;
    return 8.0 * static_cast<double>(t->type_size) / static_cast<double>(t->block_size);
}

uint64_t RowBytes(uint32_t type_id, uint64_t row_elems) {
    const TypeInfo* t = Info(type_id);
    if (t->block_size == 0) ThrowError(ErrClass::kFormat, "tensor type has no block layout");
    if (row_elems % t->block_size != 0) {
        ThrowErrorF(ErrClass::kFormat, "row length %llu is not a multiple of block size %u for type %s",
                    static_cast<unsigned long long>(row_elems), t->block_size, t->name);
    }
    uint64_t blocks = row_elems / t->block_size;
    uint64_t out = 0;
    if (!checked::MulU64(blocks, t->type_size, out)) {
        ThrowError(ErrClass::kFormat, "integer overflow computing row byte size");
    }
    return out;
}

uint64_t TotalBytes(uint32_t type_id, uint64_t n_elems) {
    const TypeInfo* t = Info(type_id);
    if (t->block_size == 0) ThrowError(ErrClass::kFormat, "tensor type has no block layout");
    if (n_elems % t->block_size != 0) {
        ThrowErrorF(ErrClass::kFormat, "element count %llu is not a multiple of block size %u for type %s",
                    static_cast<unsigned long long>(n_elems), t->block_size, t->name);
    }
    uint64_t blocks = n_elems / t->block_size;
    uint64_t out = 0;
    if (!checked::MulU64(blocks, t->type_size, out)) {
        ThrowError(ErrClass::kFormat, "integer overflow computing tensor byte size");
    }
    return out;
}

std::vector<std::string> SupportedNames() {
    std::vector<std::string> v;
    for (const auto& t : kTypes) {
        if (t.supported_by_aiprotect && t.block_size) v.emplace_back(t.name);
    }
    return v;
}

static const int8_t kIq4NlValues[16] = {
    -127, -104, -83, -65, -49, -35, -22, -10, 1, 13, 25, 38, 53, 69, 89, 113,
};

static void DeqF32(const uint8_t* s, float* d, uint64_t nb) {
    for (uint64_t i = 0; i < nb; i++) {
        uint32_t u = LoadU32(s + i * 4);
        float f;
        memcpy(&f, &u, 4);
        d[i] = f;
    }
}

static void DeqF16(const uint8_t* s, float* d, uint64_t nb) {
    for (uint64_t i = 0; i < nb; i++) d[i] = HalfToFloat(LoadU16(s + i * 2));
}

static void DeqBF16(const uint8_t* s, float* d, uint64_t nb) {
    for (uint64_t i = 0; i < nb; i++) {
        uint32_t u = static_cast<uint32_t>(LoadU16(s + i * 2)) << 16;
        float f;
        memcpy(&f, &u, 4);
        d[i] = f;
    }
}

static void DeqQ4_0(const uint8_t* s, float* d, uint64_t nb) {
    for (uint64_t i = 0; i < nb; i++) {
        const uint8_t* b = s + i * 18;
        const float sc = LoadHalf(b);
        const uint8_t* qs = b + 2;
        for (int j = 0; j < 16; j++) {
            const int x0 = (qs[j] & 0x0F) - 8;
            const int x1 = (qs[j] >> 4) - 8;
            d[i * 32 + j] = x0 * sc;
            d[i * 32 + j + 16] = x1 * sc;
        }
    }
}

static void DeqQ4_1(const uint8_t* s, float* d, uint64_t nb) {
    for (uint64_t i = 0; i < nb; i++) {
        const uint8_t* b = s + i * 20;
        const float sc = LoadHalf(b);
        const float mn = LoadHalf(b + 2);
        const uint8_t* qs = b + 4;
        for (int j = 0; j < 16; j++) {
            const int x0 = (qs[j] & 0x0F);
            const int x1 = (qs[j] >> 4);
            d[i * 32 + j] = x0 * sc + mn;
            d[i * 32 + j + 16] = x1 * sc + mn;
        }
    }
}

static void DeqQ5_0(const uint8_t* s, float* d, uint64_t nb) {
    for (uint64_t i = 0; i < nb; i++) {
        const uint8_t* b = s + i * 22;
        const float sc = LoadHalf(b);
        const uint32_t qh = LoadU32(b + 2);
        const uint8_t* qs = b + 6;
        for (int j = 0; j < 16; j++) {
            const uint8_t xh0 = static_cast<uint8_t>(((qh >> (j + 0)) << 4) & 0x10u);
            const uint8_t xh1 = static_cast<uint8_t>((qh >> (j + 12)) & 0x10u);
            const int32_t x0 = ((qs[j] & 0x0F) | xh0) - 16;
            const int32_t x1 = ((qs[j] >> 4) | xh1) - 16;
            d[i * 32 + j] = x0 * sc;
            d[i * 32 + j + 16] = x1 * sc;
        }
    }
}

static void DeqQ5_1(const uint8_t* s, float* d, uint64_t nb) {
    for (uint64_t i = 0; i < nb; i++) {
        const uint8_t* b = s + i * 24;
        const float sc = LoadHalf(b);
        const float mn = LoadHalf(b + 2);
        const uint32_t qh = LoadU32(b + 4);
        const uint8_t* qs = b + 8;
        for (int j = 0; j < 16; j++) {
            const uint8_t xh0 = static_cast<uint8_t>(((qh >> (j + 0)) << 4) & 0x10u);
            const uint8_t xh1 = static_cast<uint8_t>((qh >> (j + 12)) & 0x10u);
            const int x0 = (qs[j] & 0x0F) | xh0;
            const int x1 = (qs[j] >> 4) | xh1;
            d[i * 32 + j] = x0 * sc + mn;
            d[i * 32 + j + 16] = x1 * sc + mn;
        }
    }
}

static void DeqQ8_0(const uint8_t* s, float* d, uint64_t nb) {
    for (uint64_t i = 0; i < nb; i++) {
        const uint8_t* b = s + i * 34;
        const float sc = LoadHalf(b);
        const int8_t* qs = reinterpret_cast<const int8_t*>(b + 2);
        for (int j = 0; j < 32; j++) d[i * 32 + j] = qs[j] * sc;
    }
}

static void GetScaleMinK4(int j, const uint8_t* q, uint8_t* dsc, uint8_t* msc) {
    if (j < 4) {
        *dsc = q[j] & 63;
        *msc = q[j + 4] & 63;
    } else {
        *dsc = static_cast<uint8_t>((q[j + 4] & 0xF) | ((q[j - 4] >> 6) << 4));
        *msc = static_cast<uint8_t>((q[j + 4] >> 4) | ((q[j - 0] >> 6) << 4));
    }
}

static void DeqQ2_K(const uint8_t* s, float* d, uint64_t nb) {
    for (uint64_t i = 0; i < nb; i++) {
        const uint8_t* b = s + i * 84;
        const float sc = LoadHalf(b + 80);
        const float mn = LoadHalf(b + 82);
        const uint8_t* scales = b;
        const uint8_t* q = b + 16;
        float* y = d + i * 256;
        int is = 0;
        for (int n = 0; n < 256; n += 128) {
            int shift = 0;
            for (int j = 0; j < 4; j++) {
                uint8_t c = scales[is++];
                float dl = sc * (c & 0xF);
                float ml = mn * (c >> 4);
                for (int l = 0; l < 16; l++) *y++ = dl * static_cast<int8_t>((q[l] >> shift) & 3) - ml;
                c = scales[is++];
                dl = sc * (c & 0xF);
                ml = mn * (c >> 4);
                for (int l = 0; l < 16; l++) *y++ = dl * static_cast<int8_t>((q[l + 16] >> shift) & 3) - ml;
                shift += 2;
            }
            q += 32;
        }
    }
}

static void DeqQ3_K(const uint8_t* s, float* d, uint64_t nb) {
    const uint32_t kmask1 = 0x03030303u;
    const uint32_t kmask2 = 0x0F0F0F0Fu;
    for (uint64_t i = 0; i < nb; i++) {
        const uint8_t* b = s + i * 110;
        const float d_all = LoadHalf(b + 108);
        const uint8_t* q = b + 32;
        const uint8_t* hm = b;
        uint32_t aux[4];
        int8_t* scales = reinterpret_cast<int8_t*>(aux);
        memcpy(aux, b + 96, 12);
        uint32_t tmp = aux[2];
        aux[2] = ((aux[0] >> 4) & kmask2) | (((tmp >> 4) & kmask1) << 4);
        aux[3] = ((aux[1] >> 4) & kmask2) | (((tmp >> 6) & kmask1) << 4);
        aux[0] = (aux[0] & kmask2) | (((tmp >> 0) & kmask1) << 4);
        aux[1] = (aux[1] & kmask2) | (((tmp >> 2) & kmask1) << 4);
        float* y = d + i * 256;
        int is = 0;
        uint8_t m = 1;
        for (int n = 0; n < 256; n += 128) {
            int shift = 0;
            for (int j = 0; j < 4; j++) {
                float dl = d_all * (scales[is++] - 32);
                for (int l = 0; l < 16; l++) {
                    *y++ = dl * (static_cast<int8_t>((q[l + 0] >> shift) & 3) - ((hm[l + 0] & m) ? 0 : 4));
                }
                dl = d_all * (scales[is++] - 32);
                for (int l = 0; l < 16; l++) {
                    *y++ = dl * (static_cast<int8_t>((q[l + 16] >> shift) & 3) - ((hm[l + 16] & m) ? 0 : 4));
                }
                shift += 2;
                m = static_cast<uint8_t>(m << 1);
            }
            q += 32;
        }
    }
}

static void DeqQ4_K(const uint8_t* s, float* d, uint64_t nb) {
    for (uint64_t i = 0; i < nb; i++) {
        const uint8_t* b = s + i * 144;
        const float sc = LoadHalf(b);
        const float mn = LoadHalf(b + 2);
        const uint8_t* scales = b + 4;
        const uint8_t* q = b + 16;
        float* y = d + i * 256;
        int is = 0;
        for (int j = 0; j < 256; j += 64) {
            uint8_t c1, m1, c2, m2;
            GetScaleMinK4(is + 0, scales, &c1, &m1);
            const float d1 = sc * c1;
            const float v1 = mn * m1;
            GetScaleMinK4(is + 1, scales, &c2, &m2);
            const float d2 = sc * c2;
            const float v2 = mn * m2;
            for (int l = 0; l < 32; l++) *y++ = d1 * (q[l] & 0xF) - v1;
            for (int l = 0; l < 32; l++) *y++ = d2 * (q[l] >> 4) - v2;
            q += 32;
            is += 2;
        }
    }
}

static void DeqQ5_K(const uint8_t* s, float* d, uint64_t nb) {
    for (uint64_t i = 0; i < nb; i++) {
        const uint8_t* b = s + i * 176;
        const float sc = LoadHalf(b);
        const float mn = LoadHalf(b + 2);
        const uint8_t* scales = b + 4;
        const uint8_t* qh = b + 16;
        const uint8_t* ql = b + 48;
        float* y = d + i * 256;
        int is = 0;
        uint8_t u1 = 1, u2 = 2;
        for (int j = 0; j < 256; j += 64) {
            uint8_t c1, m1, c2, m2;
            GetScaleMinK4(is + 0, scales, &c1, &m1);
            const float d1 = sc * c1;
            const float v1 = mn * m1;
            GetScaleMinK4(is + 1, scales, &c2, &m2);
            const float d2 = sc * c2;
            const float v2 = mn * m2;
            for (int l = 0; l < 32; l++) *y++ = d1 * ((ql[l] & 0xF) + ((qh[l] & u1) ? 16 : 0)) - v1;
            for (int l = 0; l < 32; l++) *y++ = d2 * ((ql[l] >> 4) + ((qh[l] & u2) ? 16 : 0)) - v2;
            ql += 32;
            is += 2;
            u1 = static_cast<uint8_t>(u1 << 2);
            u2 = static_cast<uint8_t>(u2 << 2);
        }
    }
}

static void DeqQ6_K(const uint8_t* s, float* d, uint64_t nb) {
    for (uint64_t i = 0; i < nb; i++) {
        const uint8_t* b = s + i * 210;
        const float sc = LoadHalf(b + 208);
        const uint8_t* ql = b;
        const uint8_t* qh = b + 128;
        const int8_t* qs = reinterpret_cast<const int8_t*>(b + 192);
        float* y = d + i * 256;
        for (int n = 0; n < 256; n += 128) {
            for (int l = 0; l < 32; l++) {
                const int is = l / 16;
                const int8_t q1 = static_cast<int8_t>((ql[l + 0] & 0xF) | (((qh[l] >> 0) & 3) << 4)) - 32;
                const int8_t q2 = static_cast<int8_t>((ql[l + 32] & 0xF) | (((qh[l] >> 2) & 3) << 4)) - 32;
                const int8_t q3 = static_cast<int8_t>((ql[l + 0] >> 4) | (((qh[l] >> 4) & 3) << 4)) - 32;
                const int8_t q4 = static_cast<int8_t>((ql[l + 32] >> 4) | (((qh[l] >> 6) & 3) << 4)) - 32;
                y[l + 0] = sc * qs[is + 0] * q1;
                y[l + 32] = sc * qs[is + 2] * q2;
                y[l + 64] = sc * qs[is + 4] * q3;
                y[l + 96] = sc * qs[is + 6] * q4;
            }
            y += 128;
            ql += 64;
            qh += 32;
            qs += 8;
        }
    }
}

static void DeqQ8_K(const uint8_t* s, float* d, uint64_t nb) {
    for (uint64_t i = 0; i < nb; i++) {
        const uint8_t* b = s + i * 292;
        uint32_t du = LoadU32(b);
        float sc;
        memcpy(&sc, &du, 4);
        const int8_t* qs = reinterpret_cast<const int8_t*>(b + 4);
        for (int j = 0; j < 256; j++) d[i * 256 + j] = sc * qs[j];
    }
}

static void DeqIq4Nl(const uint8_t* s, float* d, uint64_t nb) {
    for (uint64_t i = 0; i < nb; i++) {
        const uint8_t* b = s + i * 18;
        const float sc = LoadHalf(b);
        const uint8_t* qs = b + 2;
        for (int j = 0; j < 16; j++) {
            d[i * 32 + j] = sc * kIq4NlValues[qs[j] & 0xF];
            d[i * 32 + j + 16] = sc * kIq4NlValues[qs[j] >> 4];
        }
    }
}

static void DeqIq4Xs(const uint8_t* s, float* d, uint64_t nb) {
    for (uint64_t i = 0; i < nb; i++) {
        const uint8_t* b = s + i * 136;
        const float sc = LoadHalf(b);
        const uint16_t scales_h = LoadU16(b + 2);
        const uint8_t* scales_l = b + 4;
        const uint8_t* qs = b + 8;
        float* y = d + i * 256;
        for (int ib = 0; ib < 8; ib++) {
            const int ls = ((scales_l[ib / 2] >> (4 * (ib % 2))) & 0xF) | (((scales_h >> (2 * ib)) & 3) << 4);
            const float dl = sc * (ls - 32);
            for (int j = 0; j < 16; j++) {
                y[j + 0] = dl * kIq4NlValues[qs[j] & 0xF];
                y[j + 16] = dl * kIq4NlValues[qs[j] >> 4];
            }
            y += 32;
            qs += 16;
        }
    }
}

void DequantizeRow(uint32_t type_id, const uint8_t* src, float* dst, uint64_t k) {
    switch (type_id) {
        case 0: DeqF32(src, dst, k); return;
        case 1: DeqF16(src, dst, k); return;
        case 30: DeqBF16(src, dst, k); return;
        case 2: DeqQ4_0(src, dst, k / 32); return;
        case 3: DeqQ4_1(src, dst, k / 32); return;
        case 6: DeqQ5_0(src, dst, k / 32); return;
        case 7: DeqQ5_1(src, dst, k / 32); return;
        case 8: DeqQ8_0(src, dst, k / 32); return;
        case 20: DeqIq4Nl(src, dst, k / 32); return;
        case 10: DeqQ2_K(src, dst, k / 256); return;
        case 11: DeqQ3_K(src, dst, k / 256); return;
        case 12: DeqQ4_K(src, dst, k / 256); return;
        case 13: DeqQ5_K(src, dst, k / 256); return;
        case 14: DeqQ6_K(src, dst, k / 256); return;
        case 15: DeqQ8_K(src, dst, k / 256); return;
        case 23: DeqIq4Xs(src, dst, k / 256); return;
        default:
            ThrowErrorF(ErrClass::kUnsupported, "dequantization is not implemented for tensor type %s (id %u)",
                        NameOf(type_id).c_str(), type_id);
    }
}

bool DequantizeRowChecked(uint32_t type_id, const uint8_t* src, size_t src_len, float* dst, uint64_t k) {
    const TypeInfo* t = InfoOrNull(type_id);
    if (!t || !t->supported_by_aiprotect || t->block_size == 0) return false;
    if (k == 0 || k % t->block_size != 0) return false;
    uint64_t need = 0;
    if (!checked::MulU64(k / t->block_size, t->type_size, need)) return false;
    if (need > src_len) return false;
    DequantizeRow(type_id, src, dst, k);
    return true;
}

void QuantizeRowQ8_0(const float* src, uint8_t* dst, uint64_t k) {
    for (uint64_t b = 0; b < k / 32; b++) {
        const float* x = src + b * 32;
        uint8_t* o = dst + b * 34;
        float amax = 0.0f;
        for (int j = 0; j < 32; j++) amax = std::max(amax, fabsf(x[j]));
        const float d = amax / 127.0f;
        const float inv = (d != 0.0f) ? (1.0f / d) : 0.0f;
        uint16_t dh = FloatToHalf(d);
        memcpy(o, &dh, 2);
        int8_t* qs = reinterpret_cast<int8_t*>(o + 2);
        for (int j = 0; j < 32; j++) {
            float q = x[j] * inv;
            int v = static_cast<int>(floorf(q + 0.5f));
            if (v > 127) v = 127;
            if (v < -127) v = -127;
            qs[j] = static_cast<int8_t>(v);
        }
    }
}

static uint64_t RefSeedStep(uint64_t& st) {
    st ^= st << 13;
    st ^= st >> 7;
    st ^= st << 17;
    return st;
}

static void StoreFiniteHalf(uint8_t* p, uint64_t& st, float scale) {
    double u = static_cast<double>(RefSeedStep(st) % 2000u) / 1000.0 - 1.0;
    float v = static_cast<float>(u) * scale;
    uint16_t h = FloatToHalf(v);
    if ((h & 0x7C00u) == 0x7C00u) h = static_cast<uint16_t>(h & 0x8000u);
    memcpy(p, &h, 2);
}

std::vector<uint8_t> EncodeReferenceBlock(uint32_t type_id, uint64_t seed, uint64_t k) {
    const TypeInfo* t = Info(type_id);
    if (t->block_size == 0 || k % t->block_size != 0) {
        ThrowError(ErrClass::kFormat, "EncodeReferenceBlock: invalid element count for type");
    }
    uint64_t blocks = k / t->block_size;
    uint64_t total = blocks * t->type_size;
    std::vector<uint8_t> buf(total);
    uint64_t st = seed ? seed : 0x9E3779B97F4A7C15ull;
    for (uint64_t i = 0; i < total; i++) buf[i] = static_cast<uint8_t>(RefSeedStep(st) & 0xFF);
    switch (type_id) {
        case 0:
            for (uint64_t i = 0; i < blocks; i++) {
                float v = static_cast<float>(RefSeedStep(st) % 2000u) / 1000.0f - 1.0f;
                memcpy(buf.data() + i * 4, &v, 4);
            }
            break;
        case 1:
            for (uint64_t i = 0; i < blocks; i++) StoreFiniteHalf(buf.data() + i * 2, st, 1.0f);
            break;
        case 2: case 20:
            for (uint64_t i = 0; i < blocks; i++) StoreFiniteHalf(buf.data() + i * 18, st, 0.05f);
            break;
        case 3:
            for (uint64_t i = 0; i < blocks; i++) {
                StoreFiniteHalf(buf.data() + i * 20, st, 0.05f);
                StoreFiniteHalf(buf.data() + i * 20 + 2, st, 0.01f);
            }
            break;
        case 6:
            for (uint64_t i = 0; i < blocks; i++) StoreFiniteHalf(buf.data() + i * 22, st, 0.05f);
            break;
        case 7:
            for (uint64_t i = 0; i < blocks; i++) {
                StoreFiniteHalf(buf.data() + i * 24, st, 0.05f);
                StoreFiniteHalf(buf.data() + i * 24 + 2, st, 0.01f);
            }
            break;
        case 8:
            for (uint64_t i = 0; i < blocks; i++) StoreFiniteHalf(buf.data() + i * 34, st, 0.05f);
            break;
        case 10:
            for (uint64_t i = 0; i < blocks; i++) {
                StoreFiniteHalf(buf.data() + i * 84 + 80, st, 0.05f);
                StoreFiniteHalf(buf.data() + i * 84 + 82, st, 0.01f);
            }
            break;
        case 11:
            for (uint64_t i = 0; i < blocks; i++) StoreFiniteHalf(buf.data() + i * 110 + 108, st, 0.02f);
            break;
        case 12:
            for (uint64_t i = 0; i < blocks; i++) {
                StoreFiniteHalf(buf.data() + i * 144, st, 0.05f);
                StoreFiniteHalf(buf.data() + i * 144 + 2, st, 0.01f);
                for (int j = 0; j < 12; j++) buf[i * 144 + 4 + j] &= 0x3F;
            }
            break;
        case 13:
            for (uint64_t i = 0; i < blocks; i++) {
                StoreFiniteHalf(buf.data() + i * 176, st, 0.05f);
                StoreFiniteHalf(buf.data() + i * 176 + 2, st, 0.01f);
                for (int j = 0; j < 12; j++) buf[i * 176 + 4 + j] &= 0x3F;
            }
            break;
        case 14:
            for (uint64_t i = 0; i < blocks; i++) StoreFiniteHalf(buf.data() + i * 210 + 208, st, 0.01f);
            break;
        case 15:
            for (uint64_t i = 0; i < blocks; i++) {
                float v = static_cast<float>(RefSeedStep(st) % 1000u) / 20000.0f;
                memcpy(buf.data() + i * 292, &v, 4);
            }
            break;
        case 23:
            for (uint64_t i = 0; i < blocks; i++) StoreFiniteHalf(buf.data() + i * 136, st, 0.02f);
            break;
        default:
            break;
    }
    return buf;
}

}
}
namespace aip {

bool GgufValue::IsNumeric() const {
    switch (type) {
        case GgufValueType::kUint8:
        case GgufValueType::kInt8:
        case GgufValueType::kUint16:
        case GgufValueType::kInt16:
        case GgufValueType::kUint32:
        case GgufValueType::kInt32:
        case GgufValueType::kUint64:
        case GgufValueType::kInt64:
        case GgufValueType::kFloat32:
        case GgufValueType::kFloat64:
            return true;
        default:
            return false;
    }
}

double GgufValue::AsDouble() const {
    switch (type) {
        case GgufValueType::kFloat32:
        case GgufValueType::kFloat64: return f;
        case GgufValueType::kBool: return b ? 1.0 : 0.0;
        default: return static_cast<double>(i);
    }
}

int64_t GgufValue::AsInt() const {
    if (type == GgufValueType::kBool) return b ? 1 : 0;
    if (type == GgufValueType::kFloat32 || type == GgufValueType::kFloat64) {
        return static_cast<int64_t>(f);
    }
    return i;
}

uint64_t GgufValue::AsUint() const {
    if (type == GgufValueType::kBool) return b ? 1 : 0;
    return u;
}

bool GgufValue::AsBool() const {
    if (type == GgufValueType::kBool) return b;
    if (IsNumeric()) return i != 0;
    return false;
}

const std::string& GgufValue::AsString() const {
    static const std::string empty;
    if (type == GgufValueType::kString) return s;
    return empty;
}

std::string GgufValue::Describe() const {
    switch (type) {
        case GgufValueType::kUint8: return "u8(" + std::to_string(u) + ")";
        case GgufValueType::kInt8: return "i8(" + std::to_string(i) + ")";
        case GgufValueType::kUint16: return "u16(" + std::to_string(u) + ")";
        case GgufValueType::kInt16: return "i16(" + std::to_string(i) + ")";
        case GgufValueType::kUint32: return "u32(" + std::to_string(u) + ")";
        case GgufValueType::kInt32: return "i32(" + std::to_string(i) + ")";
        case GgufValueType::kUint64: return "u64(" + std::to_string(u) + ")";
        case GgufValueType::kInt64: return "i64(" + std::to_string(i) + ")";
        case GgufValueType::kFloat32: {
            char buf[64];
            snprintf(buf, sizeof(buf), "f32(%.9g)", static_cast<float>(f));
            return buf;
        }
        case GgufValueType::kFloat64: {
            char buf[64];
            snprintf(buf, sizeof(buf), "f64(%.17g)", f);
            return buf;
        }
        case GgufValueType::kBool: return b ? "bool(true)" : "bool(false)";
        case GgufValueType::kString: {
            std::string v = s;
            if (v.size() > 96) v = v.substr(0, 96) + "...";
            return "str(\"" + v + "\")";
        }
        case GgufValueType::kArray:
            return "array(len=" + std::to_string(arr.size()) + ")";
        default:
            return "unknown";
    }
}

std::string GgufTensorInfo::ShapeText() const {
    std::string s = "[";
    for (uint32_t i = 0; i < n_dims; i++) {
        if (i) s += ", ";
        s += std::to_string(dims[i]);
    }
    s += "]";
    return s;
}

const GgufValue* GgufInfo::Find(const std::string& k) const {
    auto it = kv.find(k);
    return it == kv.end() ? nullptr : &it->second;
}

std::string GgufInfo::GetString(const std::string& k, const std::string& def) const {
    const GgufValue* v = Find(k);
    if (!v) return def;
    if (v->type == GgufValueType::kString) return v->s;
    if (v->IsNumeric()) return std::to_string(v->AsInt());
    if (v->type == GgufValueType::kBool) return v->b ? "true" : "false";
    return def;
}

double GgufInfo::GetFloat(const std::string& k, double def) const {
    const GgufValue* v = Find(k);
    if (!v) return def;
    if (v->type == GgufValueType::kFloat32) return static_cast<double>(static_cast<float>(v->f));
    if (v->type == GgufValueType::kFloat64) return v->f;
    if (v->IsNumeric()) return v->AsDouble();
    if (v->type == GgufValueType::kString) {
        try {
            return std::stod(v->s);
        } catch (...) {
            return def;
        }
    }
    return def;
}

int64_t GgufInfo::GetInt(const std::string& k, int64_t def) const {
    const GgufValue* v = Find(k);
    if (!v) return def;
    if (v->IsNumeric()) return v->AsInt();
    if (v->type == GgufValueType::kBool) return v->b ? 1 : 0;
    return def;
}

bool GgufInfo::GetBool(const std::string& k, bool def) const {
    const GgufValue* v = Find(k);
    if (!v) return def;
    if (v->type == GgufValueType::kBool) return v->b;
    if (v->IsNumeric()) return v->AsInt() != 0;
    if (v->type == GgufValueType::kString) return v->s == "true" || v->s == "1";
    return def;
}

const GgufTensorInfo* GgufInfo::FindTensor(const std::string& name) const {
    for (const auto& t : tensors) {
        if (t.name == name) return &t;
    }
    return nullptr;
}

const GgufTensorInfo* GgufInfo::FindTensorF(const char* fmt, ...) const {
    char buf[256];
    va_list ap;
    va_start(ap, fmt);
    vsnprintf(buf, sizeof(buf), fmt, ap);
    va_end(ap);
    return FindTensor(std::string(buf));
}

constexpr uint64_t kMaxMetaBudgetFactor = 4;
constexpr uint32_t kMaxStringLength = 1u << 20;
constexpr uint32_t kMaxArrayLength = 1u << 24;
constexpr uint32_t kMaxTensorCount = 4u << 20;
constexpr uint32_t kMaxKvCount = 1u << 20;
constexpr uint32_t kMaxArrayDepth = 8;

std::string GgufReader::ReadString(FileReader& fr, uint64_t& budget) {
    uint64_t len = 0;
    if (!fr.ReadExact(&len, 8)) ThrowError(ErrClass::kIoInput, "truncated GGUF file while reading string length");
    if (budget < 8) ThrowError(ErrClass::kFormat, "GGUF metadata overruns the file");
    budget -= 8;
    if (len > kMaxStringLength) {
        ThrowErrorF(ErrClass::kFormat, "GGUF string length %llu exceeds the supported limit %u",
                    static_cast<unsigned long long>(len), kMaxStringLength);
    }
    if (len > budget) ThrowError(ErrClass::kFormat, "GGUF string extends past the end of the file");
    std::string s;
    if (len > 0) {
        s.resize(static_cast<size_t>(len));
        if (!fr.ReadExact(&s[0], static_cast<size_t>(len))) {
            ThrowError(ErrClass::kIoInput, "truncated GGUF file while reading string payload");
        }
        budget -= len;
    }
    if (s.find('\0') != std::string::npos) {
        ThrowError(ErrClass::kFormat, "GGUF string contains an embedded NUL byte");
    }
    return s;
}

GgufValue GgufReader::ReadValue(FileReader& fr, GgufValueType t, uint64_t& budget, int depth) {
    GgufValue v;
    v.type = t;
    auto need = [&](size_t n) {
        if (budget < n) ThrowError(ErrClass::kFormat, "GGUF metadata overruns the file");
        budget -= n;
    };
    switch (t) {
        case GgufValueType::kUint8: {
            uint8_t x = 0;
            need(1);
            if (!fr.ReadExact(&x, 1)) ThrowError(ErrClass::kIoInput, "truncated GGUF metadata");
            v.u = x;
            v.i = x;
            v.f = x;
            break;
        }
        case GgufValueType::kInt8: {
            int8_t x = 0;
            need(1);
            if (!fr.ReadExact(&x, 1)) ThrowError(ErrClass::kIoInput, "truncated GGUF metadata");
            v.i = x;
            v.u = static_cast<uint64_t>(x);
            v.f = x;
            break;
        }
        case GgufValueType::kUint16: {
            uint16_t x = 0;
            need(2);
            if (!fr.ReadExact(&x, 2)) ThrowError(ErrClass::kIoInput, "truncated GGUF metadata");
            v.u = x;
            v.i = x;
            v.f = x;
            break;
        }
        case GgufValueType::kInt16: {
            int16_t x = 0;
            need(2);
            if (!fr.ReadExact(&x, 2)) ThrowError(ErrClass::kIoInput, "truncated GGUF metadata");
            v.i = x;
            v.u = static_cast<uint64_t>(x);
            v.f = x;
            break;
        }
        case GgufValueType::kUint32: {
            uint32_t x = 0;
            need(4);
            if (!fr.ReadExact(&x, 4)) ThrowError(ErrClass::kIoInput, "truncated GGUF metadata");
            v.u = x;
            v.i = x;
            v.f = x;
            break;
        }
        case GgufValueType::kInt32: {
            int32_t x = 0;
            need(4);
            if (!fr.ReadExact(&x, 4)) ThrowError(ErrClass::kIoInput, "truncated GGUF metadata");
            v.i = x;
            v.u = static_cast<uint64_t>(x);
            v.f = x;
            break;
        }
        case GgufValueType::kFloat32: {
            float x = 0;
            need(4);
            if (!fr.ReadExact(&x, 4)) ThrowError(ErrClass::kIoInput, "truncated GGUF metadata");
            v.f = x;
            v.i = static_cast<int64_t>(x);
            v.u = static_cast<uint64_t>(v.i);
            break;
        }
        case GgufValueType::kBool: {
            uint8_t x = 0;
            need(1);
            if (!fr.ReadExact(&x, 1)) ThrowError(ErrClass::kIoInput, "truncated GGUF metadata");
            if (x > 1) ThrowErrorF(ErrClass::kFormat, "invalid GGUF boolean value %u", x);
            v.b = x != 0;
            v.i = x;
            v.u = x;
            v.f = x;
            break;
        }
        case GgufValueType::kString: {
            v.s = ReadString(fr, budget);
            break;
        }
        case GgufValueType::kUint64: {
            uint64_t x = 0;
            need(8);
            if (!fr.ReadExact(&x, 8)) ThrowError(ErrClass::kIoInput, "truncated GGUF metadata");
            v.u = x;
            v.i = static_cast<int64_t>(x);
            v.f = static_cast<double>(x);
            break;
        }
        case GgufValueType::kInt64: {
            int64_t x = 0;
            need(8);
            if (!fr.ReadExact(&x, 8)) ThrowError(ErrClass::kIoInput, "truncated GGUF metadata");
            v.i = x;
            v.u = static_cast<uint64_t>(x);
            v.f = static_cast<double>(x);
            break;
        }
        case GgufValueType::kFloat64: {
            double x = 0;
            need(8);
            if (!fr.ReadExact(&x, 8)) ThrowError(ErrClass::kIoInput, "truncated GGUF metadata");
            v.f = x;
            v.i = static_cast<int64_t>(x);
            v.u = static_cast<uint64_t>(v.i);
            break;
        }
        case GgufValueType::kArray: {
            if (depth >= static_cast<int>(kMaxArrayDepth)) {
                ThrowError(ErrClass::kFormat, "GGUF array nesting is too deep");
            }
            uint32_t et = 0;
            uint64_t len = 0;
            need(12);
            if (!fr.ReadExact(&et, 4)) ThrowError(ErrClass::kIoInput, "truncated GGUF array header");
            if (!fr.ReadExact(&len, 8)) ThrowError(ErrClass::kIoInput, "truncated GGUF array header");
            if (et > 12) ThrowErrorF(ErrClass::kFormat, "invalid GGUF array element type %u", et);
            if (len > kMaxArrayLength) {
                ThrowErrorF(ErrClass::kFormat, "GGUF array length %llu exceeds the supported limit",
                            static_cast<unsigned long long>(len));
            }
            v.arr_elem = static_cast<GgufValueType>(et);
            v.arr.reserve(static_cast<size_t>(std::min<uint64_t>(len, 1u << 20)));
            for (uint64_t i = 0; i < len; i++) {
                v.arr.push_back(ReadValue(fr, static_cast<GgufValueType>(et), budget, depth + 1));
            }
            break;
        }
        default:
            ThrowErrorF(ErrClass::kFormat, "unsupported GGUF metadata value type %u", static_cast<unsigned>(t));
    }
    return v;
}

GgufInfo GgufReader::Parse(const std::string& path, FileReader& fr, bool full_validation) {
    GgufInfo g;
    g.file_size = fr.Size();
    if (g.file_size < 24) {
        ThrowErrorF(ErrClass::kFormat, "'%s' is too small to be a GGUF file (%llu bytes)", path.c_str(),
                    static_cast<unsigned long long>(g.file_size));
    }
    if (!fr.Seek(0)) {
        ThrowErrorF(ErrClass::kIoInput, "cannot rewind '%s' before parsing its header", path.c_str());
    }
    uint8_t magic[4] = {0, 0, 0, 0};
    if (!fr.ReadExact(magic, 4)) ThrowError(ErrClass::kIoInput, "failed to read the GGUF magic");
    if (!(magic[0] == 'G' && magic[1] == 'G' && magic[2] == 'U' && magic[3] == 'F')) {
        uint32_t first_u32 = 0;
        memcpy(&first_u32, magic, 4);
        if (first_u32 == kContainerMagicA) {
            ThrowError(ErrClass::kFormat,
                       "this file is already an AIProtect container (.aip); pass the original GGUF model instead");
        }
        ThrowErrorF(ErrClass::kFormat, "'%s' is not a GGUF file (magic %02x %02x %02x %02x, expected 'GGUF')",
                    path.c_str(), magic[0], magic[1], magic[2], magic[3]);
    }
    if (!fr.ReadExact(&g.version, 4)) ThrowError(ErrClass::kIoInput, "failed to read the GGUF version");
    if (g.version == 1) {
        ThrowError(ErrClass::kFormat,
                   "GGUF version 1 is not supported (32-bit offsets cannot address models larger than 4 GiB); "
                   "re-save the model as GGUF v2 or v3");
    }
    if (g.version != 2 && g.version != 3) {
        ThrowErrorF(ErrClass::kFormat, "unsupported GGUF version %u (expected 2 or 3)", g.version);
    }
    if (!fr.ReadExact(&g.n_tensors, 8)) ThrowError(ErrClass::kIoInput, "failed to read the tensor count");
    if (!fr.ReadExact(&g.n_kv, 8)) ThrowError(ErrClass::kIoInput, "failed to read the key/value count");
    if (g.n_tensors > kMaxTensorCount) {
        ThrowErrorF(ErrClass::kFormat, "GGUF declares %llu tensors which exceeds the supported limit %u",
                    static_cast<unsigned long long>(g.n_tensors), kMaxTensorCount);
    }
    if (g.n_kv > kMaxKvCount) {
        ThrowErrorF(ErrClass::kFormat, "GGUF declares %llu metadata entries which exceeds the supported limit %u",
                    static_cast<unsigned long long>(g.n_kv), kMaxKvCount);
    }
    uint64_t budget = g.file_size > 32 ? g.file_size - 32 : 0;

    for (uint64_t i = 0; i < g.n_kv; i++) {
        std::string key = ReadString(fr, budget);
        uint32_t vt = 0;
        if (budget < 4) ThrowError(ErrClass::kFormat, "GGUF metadata overruns the file");
        budget -= 4;
        if (!fr.ReadExact(&vt, 4)) ThrowError(ErrClass::kIoInput, "truncated GGUF metadata type tag");
        if (vt > 12) ThrowErrorF(ErrClass::kFormat, "invalid GGUF value type %u for key '%s'", vt, key.c_str());
        GgufValue val = ReadValue(fr, static_cast<GgufValueType>(vt), budget, 0);
        if (g.kv.count(key)) {
            ThrowErrorF(ErrClass::kFormat, "duplicate GGUF metadata key '%s'", key.c_str());
        }
        g.kv.emplace(std::move(key), std::move(val));
    }

    g.alignment = static_cast<uint64_t>(g.GetInt("general.alignment", 32));
    if (g.alignment == 0 || (g.alignment & (g.alignment - 1)) != 0) {
        ThrowErrorF(ErrClass::kFormat, "invalid general.alignment value %llu (must be a power of two)",
                    static_cast<unsigned long long>(g.alignment));
    }
    if (g.alignment > (1u << 20)) {
        ThrowErrorF(ErrClass::kFormat, "general.alignment %llu is unreasonably large",
                    static_cast<unsigned long long>(g.alignment));
    }

    try {
        g.tensors.reserve(static_cast<size_t>(g.n_tensors));
    } catch (const std::bad_alloc&) {
        ThrowError(ErrClass::kMemory, "not enough memory to hold the GGUF tensor table");
    }

    for (uint64_t i = 0; i < g.n_tensors; i++) {
        GgufTensorInfo t;
        t.name = ReadString(fr, budget);
        uint32_t nd = 0;
        if (budget < 4) ThrowError(ErrClass::kFormat, "GGUF tensor table overruns the file");
        budget -= 4;
        if (!fr.ReadExact(&nd, 4)) ThrowError(ErrClass::kIoInput, "truncated GGUF tensor header");
        if (nd == 0 || nd > 4) {
            ThrowErrorF(ErrClass::kFormat, "tensor '%s' declares %u dimensions (GGUF allows 1..4)", t.name.c_str(), nd);
        }
        t.n_dims = nd;
        uint64_t dim_bytes = static_cast<uint64_t>(nd) * 8;
        if (budget < dim_bytes) ThrowError(ErrClass::kFormat, "GGUF tensor table overruns the file");
        budget -= dim_bytes;
        for (uint32_t d = 0; d < nd; d++) {
            uint64_t dv = 0;
            if (!fr.ReadExact(&dv, 8)) ThrowError(ErrClass::kIoInput, "truncated GGUF tensor dimensions");
            if (dv == 0) {
                ThrowErrorF(ErrClass::kFormat, "tensor '%s' has a zero-sized dimension %u", t.name.c_str(), d);
            }
            if (dv > (1ull << 40)) {
                ThrowErrorF(ErrClass::kFormat, "tensor '%s' dimension %u = %llu is unreasonably large",
                            t.name.c_str(), d, static_cast<unsigned long long>(dv));
            }
            t.dims[d] = dv;
        }
        if (budget < 12) ThrowError(ErrClass::kFormat, "GGUF tensor table overruns the file");
        budget -= 12;
        if (!fr.ReadExact(&t.type_id, 4)) ThrowError(ErrClass::kIoInput, "truncated GGUF tensor type");
        if (!fr.ReadExact(&t.rel_offset, 8)) ThrowError(ErrClass::kIoInput, "truncated GGUF tensor offset");

        uint64_t n_elems = 1;
        for (uint32_t d = 0; d < nd; d++) {
            if (!checked::MulU64(n_elems, t.dims[d], n_elems)) {
                ThrowErrorF(ErrClass::kFormat, "tensor '%s' element count overflows 64 bits", t.name.c_str());
            }
        }
        t.n_elems = n_elems;
        const quant::TypeInfo* ti = quant::InfoOrNull(t.type_id);
        if (!ti) {
            ThrowErrorF(ErrClass::kFormat, "tensor '%s' uses unknown GGUF type id %u", t.name.c_str(), t.type_id);
        }
        if (ti->block_size == 0 || ti->type_size == 0) {
            ThrowErrorF(ErrClass::kFormat, "tensor '%s' uses reserved type id %u (%s) which has no defined layout",
                        t.name.c_str(), t.type_id, ti->name);
        }
        t.block_size = ti->block_size;
        t.type_size = ti->type_size;

        uint64_t row_elems = t.dims[0];
        for (uint32_t d = 2; d < nd; d++) {
            if (!checked::MulU64(row_elems, t.dims[d], row_elems)) {
                ThrowErrorF(ErrClass::kFormat, "tensor '%s' row size overflows", t.name.c_str());
            }
        }
        t.row_elems = row_elems;
        t.n_rows = (nd >= 2) ? (n_elems / row_elems) : 1;
        if (t.n_rows == 0) t.n_rows = 1;

        if (row_elems % t.block_size != 0) {
            ThrowErrorF(ErrClass::kFormat,
                        "tensor '%s' has an inner dimension of %llu elements which is not a multiple of the "
                        "block size %u required by type %s",
                        t.name.c_str(), static_cast<unsigned long long>(row_elems), t.block_size, ti->name);
        }
        if (n_elems % t.block_size != 0) {
            ThrowErrorF(ErrClass::kFormat, "tensor '%s' element count %llu is not block aligned for type %s",
                        t.name.c_str(), static_cast<unsigned long long>(n_elems), ti->name);
        }
        uint64_t nb = 0;
        if (!checked::MulU64(n_elems / t.block_size, t.type_size, nb)) {
            ThrowErrorF(ErrClass::kFormat, "tensor '%s' byte size overflows", t.name.c_str());
        }
        t.n_bytes = nb;
        g.tensors.push_back(std::move(t));
    }

    g.meta_end = fr.Tell();
    uint64_t aligned = ((g.meta_end + g.alignment - 1) / g.alignment) * g.alignment;
    if (aligned < g.meta_end) ThrowError(ErrClass::kFormat, "GGUF data start offset overflows");
    g.data_start = aligned;
    if (g.data_start > g.file_size) {
        ThrowErrorF(ErrClass::kFormat, "GGUF metadata ends at %llu which is beyond the file size %llu",
                    static_cast<unsigned long long>(g.meta_end), static_cast<unsigned long long>(g.file_size));
    }
    for (auto& t : g.tensors) {
        uint64_t abs_off = 0;
        if (!checked::AddU64(g.data_start, t.rel_offset, abs_off)) {
            ThrowErrorF(ErrClass::kFormat, "tensor '%s' absolute offset overflows", t.name.c_str());
        }
        uint64_t end = 0;
        if (!checked::AddU64(abs_off, t.n_bytes, end)) {
            ThrowErrorF(ErrClass::kFormat, "tensor '%s' byte range overflows", t.name.c_str());
        }
        t.abs_offset = abs_off;
        if (end > g.file_size) {
            ThrowErrorF(ErrClass::kFormat,
                        "tensor '%s' claims %llu bytes at file offset %llu but the file is only %llu bytes long",
                        t.name.c_str(), static_cast<unsigned long long>(t.n_bytes),
                        static_cast<unsigned long long>(abs_off), static_cast<unsigned long long>(g.file_size));
        }
    }
    if (full_validation) ValidateLayout(g);
    return g;
}

void GgufReader::ValidateLayout(const GgufInfo& g) {
    std::unordered_set<std::string> seen;
    seen.reserve(g.tensors.size() * 2 + 1);
    for (const auto& t : g.tensors) {
        if (!seen.insert(t.name).second) {
            ThrowErrorF(ErrClass::kFormat, "duplicate tensor name '%s' in the GGUF tensor table", t.name.c_str());
        }
    }
    struct Range {
        uint64_t begin, end;
        std::string name;
    };
    std::vector<Range> ranges;
    ranges.reserve(g.tensors.size());
    for (const auto& t : g.tensors) {
        ranges.push_back(Range{t.abs_offset, t.abs_offset + t.n_bytes, t.name});
    }
    std::sort(ranges.begin(), ranges.end(), [](const Range& a, const Range& b) { return a.begin < b.begin; });
    for (size_t i = 1; i < ranges.size(); i++) {
        if (ranges[i].begin < ranges[i - 1].end) {
            ThrowErrorF(ErrClass::kFormat,
                        "tensor data regions overlap: '%s' and '%s' share bytes starting at offset %llu",
                        ranges[i - 1].name.c_str(), ranges[i].name.c_str(),
                        static_cast<unsigned long long>(ranges[i].begin));
        }
    }
}

bool GgufReaderAccess::ReadTensorRows(const GgufTensorInfo& t, uint64_t row_begin, uint64_t row_count,
                                     uint8_t* dst) {
    if (row_begin + row_count < row_begin) return false;
    if (row_begin + row_count > t.n_rows) return false;
    uint64_t row_bytes = 0;
    if (!checked::MulU64(t.n_bytes / (t.n_rows ? t.n_rows : 1), 1, row_bytes)) return false;
    row_bytes = t.n_bytes / t.n_rows;
    uint64_t off = 0;
    if (!checked::MulAddU64(row_begin, row_bytes, t.abs_offset, off)) return false;
    uint64_t total = 0;
    if (!checked::MulU64(row_count, row_bytes, total)) return false;
    if (total == 0) return true;
    if (off + total < off || off + total > t.abs_offset + t.n_bytes) return false;
    uint64_t done = 0;
    while (done < total) {
        size_t chunk = static_cast<size_t>(std::min<uint64_t>(total - done, static_cast<uint64_t>(1) << 28));
        if (!fr_.ReadAt(off + done, dst + done, chunk)) return false;
        done += chunk;
    }
    return true;
}

std::vector<float> GgufReaderAccess::DequantTensor(const GgufTensorInfo& t, uint64_t max_elems, bool& ok) {
    ok = false;
    std::vector<float> out;
    uint64_t n = std::min<uint64_t>(t.n_elems, max_elems);
    n = (n / t.block_size) * t.block_size;
    if (n == 0) return out;
    uint64_t bytes = (n / t.block_size) * t.type_size;
    std::vector<uint8_t> raw(static_cast<size_t>(bytes));
    if (!fr_.ReadAt(t.abs_offset, raw.data(), static_cast<size_t>(bytes))) return out;
    out.resize(static_cast<size_t>(n));
    quant::DequantizeRow(t.type_id, raw.data(), out.data(), n);
    ok = true;
    return out;
}

}
namespace aip {

std::string ArchName(ArchId a) {
    switch (a) {
        case ArchId::kLlama: return "llama";
        case ArchId::kQwen2: return "qwen2";
        case ArchId::kGemma: return "gemma";
        default: return "unknown";
    }
}

ArchId ArchFromName(const std::string& s) {
    if (s == "llama") return ArchId::kLlama;
    if (s == "qwen2") return ArchId::kQwen2;
    if (s == "gemma") return ArchId::kGemma;
    return ArchId::kUnknown;
}

std::vector<std::string> SupportedArchNames() {
    return {"llama", "qwen2", "gemma"};
}

static const char* kKnownButUnsupported[] = {
    "gemma2", "gemma3", "gemma3n", "gemma4", "qwen3", "qwen3moe", "qwen2moe", "qwen2vl", "llama4",
    "mixtral", "grok", "dbrx", "command-r", "cohere2", "deepseek", "deepseek2", "falcon", "falcon3",
    "falcon_h1", "gpt2", "gptj", "gptneox", "phi2", "phi3", "plamo", "plamo2", "baichuan", "starcoder",
    "starcoder2", "bert", "nomic-bert", "bloom", "stablelm", "mpt", "refact", "internlm2", "minicpm",
    "minicpm3", "olmo", "olmo2", "orion", "chatglm", "bitnet", "mamba", "mamba2", "jamba", "rwkv6",
    "rwkv6qwen2", "t5", "clip", "whisper", "nemotron", "exaone", "granite", "granitemoe", "chameleon",
    "jina-bert-v2", "glm4", "glm-edge", "codeshell", "xverse", "openelm", "arwkv7", "lfm2", "smolvlm",
};

static bool IsKnownUnsupported(const std::string& s) {
    for (const char* k : kKnownButUnsupported) {
        if (s == k) return true;
    }
    return false;
}

ModelSpec ModelSpec::FromGguf(const GgufInfo& g) {
    ModelSpec spec;
    const GgufValue* gen_type = g.Find("general.type");
    if (gen_type && gen_type->IsString() && gen_type->s != "model" && gen_type->s != "adapter") {
        ThrowErrorF(ErrClass::kUnsupported,
                    "general.type is '%s'; AIProtect 1.0 protects 'model' files only", gen_type->s.c_str());
    }
    const GgufValue* arch = g.Find("general.architecture");
    if (!arch) {
        ThrowError(ErrClass::kFormat, "the GGUF file has no 'general.architecture' metadata key");
    }
    if (!arch->IsString()) {
        ThrowError(ErrClass::kFormat, "'general.architecture' must be a string");
    }
    spec.arch_name = arch->s;
    spec.general_name = g.GetString("general.name");
    spec.arch = ArchFromName(spec.arch_name);
    if (spec.arch == ArchId::kUnknown) {
        std::string supported;
        for (const auto& n : SupportedArchNames()) {
            if (!supported.empty()) supported += ", ";
            supported += n;
        }
        if (IsKnownUnsupported(spec.arch_name)) {
            ThrowErrorF(ErrClass::kUnsupported,
                        "model architecture '%s' is recognised but is not supported by AIProtect %u.%u: "
                        "its decoder block cannot be expressed with the AIProtect VM instruction set. "
                        "Fully supported architectures: %s. Pass --no-vm to protect this model without graph "
                        "virtualization (encryption and RMP still apply).",
                        spec.arch_name.c_str(), kVersionMajor, kVersionMinor, supported.c_str());
        }
        ThrowErrorF(ErrClass::kUnsupported,
                    "model architecture '%s' is not supported by AIProtect %u.%u. Fully supported "
                    "architectures: %s. Pass --no-vm to protect this model without graph virtualization.",
                    spec.arch_name.c_str(), kVersionMajor, kVersionMinor, supported.c_str());
    }
    const std::string p = spec.arch_name;

    if (!g.Has(p + ".block_count")) {
        ThrowErrorF(ErrClass::kFormat, "missing required metadata key '%s.block_count'", p.c_str());
    }
    spec.n_layer = static_cast<uint32_t>(g.GetInt(p + ".block_count", 0));
    spec.n_embd = static_cast<uint32_t>(g.GetInt(p + ".embedding_length", 0));
    spec.n_head = static_cast<uint32_t>(g.GetInt(p + ".attention.head_count", 0));
    spec.n_head_kv = static_cast<uint32_t>(g.GetInt(p + ".attention.head_count_kv", spec.n_head));
    spec.n_ff = static_cast<uint32_t>(g.GetInt(p + ".feed_forward_length", 0));
    spec.n_ctx_train = static_cast<uint32_t>(g.GetInt(p + ".context_length", 2048));

    const GgufValue* toks = g.Find(p + ".vocab_size");
    if (toks && toks->IsNumeric()) {
        spec.n_vocab = static_cast<uint32_t>(toks->AsUint());
    } else {
        const GgufValue* tv = g.Find("tokenizer.ggml.tokens");
        if (tv && tv->IsArray()) spec.n_vocab = static_cast<uint32_t>(tv->arr.size());
    }

    uint32_t n_embd_head_k = spec.n_head ? (spec.n_embd / spec.n_head) : 0;
    spec.head_dim = static_cast<uint32_t>(g.GetInt(p + ".attention.key_length", n_embd_head_k));
    uint32_t v_dim = static_cast<uint32_t>(g.GetInt(p + ".attention.value_length", spec.head_dim));
    if (v_dim != spec.head_dim) {
        ThrowErrorF(ErrClass::kUnsupported,
                    "the model uses a value head dimension (%u) different from the key head dimension (%u); "
                    "AIProtect 1.0 requires them to be equal",
                    v_dim, spec.head_dim);
    }
    spec.n_rot = static_cast<uint32_t>(g.GetInt(p + ".rope.dimension_count", spec.head_dim));
    spec.n_embd_gqa = spec.head_dim * spec.n_head;
    spec.n_embd_v_gqa = spec.head_dim * spec.n_head_kv;

    spec.rope_theta = static_cast<float>(g.GetFloat(p + ".rope.freq_base", 10000.0));
    spec.rope_scaling_type = g.GetString(p + ".rope.scaling.type");
    double factor = g.GetFloat(p + ".rope.scaling.factor", 1.0);
    if (factor <= 0.0) factor = 1.0;
    if (spec.rope_scaling_type.empty() || spec.rope_scaling_type == "none") {
        spec.rope_scale = 1.0f;
    } else if (spec.rope_scaling_type == "linear") {
        spec.rope_scale = static_cast<float>(1.0 / factor);
    } else if (spec.rope_scaling_type == "yarn" || spec.rope_scaling_type == "longrope") {
        ThrowErrorF(ErrClass::kUnsupported,
                    "RoPE scaling type '%s' is not supported by AIProtect %u.%u; the interpolation ramp and "
                    "attention factor corrections are model specific and cannot be reproduced safely. "
                    "Re-export the model with rope.scaling.type=none or linear.",
                    spec.rope_scaling_type.c_str(), kVersionMajor, kVersionMinor);
    } else {
        ThrowErrorF(ErrClass::kUnsupported, "unknown RoPE scaling type '%s'", spec.rope_scaling_type.c_str());
    }

    spec.norm_eps = static_cast<float>(g.GetFloat(p + ".attention.layer_norm_rms_epsilon", 1e-5));
    if (!std::isfinite(spec.norm_eps) || spec.norm_eps < 0.0f) {
        ThrowErrorF(ErrClass::kFormat, "invalid %s.attention.layer_norm_rms_epsilon value", p.c_str());
    }
    spec.norm = NormKind::kRms;
    switch (spec.arch) {
        case ArchId::kGemma: spec.ffn = FfnKind::kGeGlu; break;
        default: spec.ffn = FfnKind::kSwiGlu; break;
    }
    const GgufValue* hidden_act = g.Find(p + ".hidden_activation");
    if (hidden_act && hidden_act->IsString()) {
        bool ok_act = false;
        if (spec.ffn == FfnKind::kSwiGlu) ok_act = (hidden_act->s == "silu");
        else ok_act = (hidden_act->s == "gelu");
        if (!ok_act) {
            ThrowErrorF(ErrClass::kUnsupported,
                        "metadata declares hidden_activation='%s' but architecture '%s' is compiled by "
                        "AIProtect with %s; refusing to build a graph that would not be numerically equivalent",
                        hidden_act->s.c_str(), spec.arch_name.c_str(),
                        spec.ffn == FfnKind::kSwiGlu ? "SiLU/SwiGLU" : "GELU/GeGLU");
        }
    }

    spec.tied_output = (g.FindTensor("output.weight") == nullptr);
    if (spec.arch == ArchId::kGemma && !spec.tied_output) {
        ThrowError(ErrClass::kFormat,
                   "gemma models must share token_embd.weight and output.weight; an explicit output.weight "
                   "tensor was found");
    }
    spec.has_qkv_bias = (g.FindTensor("blk.0.attn_q.bias") != nullptr);
    spec.has_output_bias = (g.FindTensor("output.bias") != nullptr);
    if (spec.arch != ArchId::kQwen2 && spec.has_qkv_bias) {
        ThrowErrorF(ErrClass::kUnsupported,
                    "architecture '%s' carries attention bias tensors which AIProtect %u.%u does not model",
                    spec.arch_name.c_str(), kVersionMajor, kVersionMinor);
    }
    if (spec.has_output_bias) {
        ThrowError(ErrClass::kUnsupported, "an output.bias tensor is present and is not modelled by AIProtect 1.0");
    }
    spec.embd_scale = (spec.arch == ArchId::kGemma) ? std::sqrt(static_cast<float>(spec.n_embd)) : 0.0f;
    spec.attn_logit_scale = 0.0f;
    spec.attn_softcap = 0.0f;
    spec.final_softcap = 0.0f;
    spec.alignment = g.alignment;

    const GgufValue* swa = g.Find(p + ".attention.sliding_window");
    if (swa && swa->IsNumeric() && swa->AsInt() > 0) {
        ThrowErrorF(ErrClass::kUnsupported,
                    "the model requests sliding window attention (%s.attention.sliding_window=%lld) which "
                    "AIProtect 1.0 does not implement",
                    p.c_str(), static_cast<long long>(swa->AsInt()));
    }
    const GgufValue* expert = g.Find(p + ".expert_count");
    if (expert && expert->IsNumeric() && expert->AsInt() > 0) {
        ThrowErrorF(ErrClass::kUnsupported,
                    "the model is a mixture-of-experts network (%s.expert_count=%lld); AIProtect 1.0 "
                    "virtualizes dense decoder blocks only",
                    p.c_str(), static_cast<long long>(expert->AsInt()));
    }
    const GgufValue* rope_factors = g.FindTensor("rope_freqs") ? g.Find("general.architecture") : nullptr;
    (void)rope_factors;
    if (g.FindTensor("rope_freqs") != nullptr) {
        ThrowError(ErrClass::kUnsupported,
                   "the model carries a rope_freqs tensor (per-dimension frequency factors) which AIProtect "
                   "1.0 does not apply");
    }
    spec.Validate();
    spec.BuildRequirements();
    return spec;
}

void ModelSpec::Validate() const {
    if (n_layer == 0 || n_layer > 2048) ThrowErrorF(ErrClass::kFormat, "invalid block count %u", n_layer);
    if (n_embd == 0 || n_embd > (1u << 20)) ThrowErrorF(ErrClass::kFormat, "invalid embedding length %u", n_embd);
    if (n_head == 0 || n_head > (1u << 18)) ThrowErrorF(ErrClass::kFormat, "invalid attention head count %u", n_head);
    if (n_head_kv == 0 || n_head_kv > n_head) ThrowErrorF(ErrClass::kFormat, "invalid attention head_count_kv %u", n_head_kv);
    if (n_head % n_head_kv != 0) {
        ThrowErrorF(ErrClass::kFormat, "head count %u is not divisible by head_count_kv %u", n_head, n_head_kv);
    }
    if (head_dim == 0 || head_dim > (1u << 16)) ThrowErrorF(ErrClass::kFormat, "invalid attention head dimension %u", head_dim);
    if (head_dim % 2 != 0) ThrowErrorF(ErrClass::kFormat, "attention head dimension %u must be even for RoPE", head_dim);
    if (n_rot == 0 || n_rot > head_dim) ThrowErrorF(ErrClass::kFormat, "invalid rope dimension count %u", n_rot);
    if (n_rot % 2 != 0) ThrowErrorF(ErrClass::kFormat, "rope dimension count %u must be even", n_rot);
    if (n_ff == 0 || n_ff > (1u << 22)) ThrowErrorF(ErrClass::kFormat, "invalid feed forward length %u", n_ff);
    if (n_vocab == 0 || n_vocab > (1u << 22)) ThrowErrorF(ErrClass::kFormat, "invalid vocabulary size %u", n_vocab);
    if (n_ctx_train == 0) ThrowErrorF(ErrClass::kFormat, "invalid trained context length %u", n_ctx_train);
    if (!(rope_theta > 0.0f) || !std::isfinite(rope_theta)) {
        ThrowError(ErrClass::kFormat, "invalid rope frequency base");
    }
    if (!(rope_scale > 0.0f) || !std::isfinite(rope_scale)) {
        ThrowError(ErrClass::kFormat, "invalid rope frequency scale");
    }
    if (static_cast<uint64_t>(n_head) * head_dim > (1u << 22)) {
        ThrowError(ErrClass::kFormat, "attention query width overflows the supported range");
    }
}

void ModelSpec::BuildRequirements() {
    required_tensors.clear();
    auto add = [&](TensorRole::Kind role, int layer, std::string name, std::vector<uint64_t> dims, bool req) {
        WeightRequirement w;
        w.role = role;
        w.layer = layer;
        w.name = std::move(name);
        w.expect_dims = std::move(dims);
        w.required = req;
        required_tensors.push_back(std::move(w));
    };
    add(TensorRole::kTokenEmbd, -1, "token_embd.weight", {n_embd, n_vocab}, true);
    add(TensorRole::kOutputNorm, -1, "output_norm.weight", {n_embd}, true);
    if (!tied_output) {
        add(TensorRole::kOutputWeight, -1, "output.weight", {n_embd, n_vocab}, true);
    }
    const uint32_t qd = n_head * head_dim;
    const uint32_t kd = n_head_kv * head_dim;
    for (uint32_t i = 0; i < n_layer; i++) {
        int li = static_cast<int>(i);
        add(TensorRole::kAttnNorm, li, "blk." + std::to_string(i) + ".attn_norm.weight", {n_embd}, true);
        add(TensorRole::kAttnQ, li, "blk." + std::to_string(i) + ".attn_q.weight", {n_embd, qd}, true);
        add(TensorRole::kAttnK, li, "blk." + std::to_string(i) + ".attn_k.weight", {n_embd, kd}, true);
        add(TensorRole::kAttnV, li, "blk." + std::to_string(i) + ".attn_v.weight", {n_embd, kd}, true);
        add(TensorRole::kAttnOut, li, "blk." + std::to_string(i) + ".attn_output.weight", {n_embd, qd}, true);
        if (has_qkv_bias) {
            add(TensorRole::kAttnQBias, li, "blk." + std::to_string(i) + ".attn_q.bias", {qd}, true);
            add(TensorRole::kAttnKBias, li, "blk." + std::to_string(i) + ".attn_k.bias", {kd}, true);
            add(TensorRole::kAttnVBias, li, "blk." + std::to_string(i) + ".attn_v.bias", {kd}, true);
        }
        add(TensorRole::kFfnNorm, li, "blk." + std::to_string(i) + ".ffn_norm.weight", {n_embd}, true);
        add(TensorRole::kFfnGate, li, "blk." + std::to_string(i) + ".ffn_gate.weight", {n_embd, n_ff}, true);
        add(TensorRole::kFfnUp, li, "blk." + std::to_string(i) + ".ffn_up.weight", {n_embd, n_ff}, true);
        add(TensorRole::kFfnDown, li, "blk." + std::to_string(i) + ".ffn_down.weight", {n_ff, n_embd}, true);
    }
}

std::string ModelSpec::Describe() const {
    std::ostringstream os;
    os << "architecture      : " << arch_name << "\n"
       << "layers            : " << n_layer << "\n"
       << "embedding         : " << n_embd << "\n"
       << "feed forward      : " << n_ff << "\n"
       << "heads (q / kv)    : " << n_head << " / " << n_head_kv << "\n"
       << "head dim          : " << head_dim << " (rope " << n_rot << ")\n"
       << "vocab             : " << n_vocab << "\n"
       << "train ctx         : " << n_ctx_train << "\n"
       << "norm              : RMSNorm, eps=" << norm_eps << "\n"
       << "ffn activation    : " << (ffn == FfnKind::kGeGlu ? "GeGLU (gelu tanh approximation)" : "SwiGLU (silu)")
       << "\n"
       << "rope              : theta=" << rope_theta << ", scale=" << rope_scale
       << (rope_scaling_type.empty() ? "" : (" (" + rope_scaling_type + ")")) << "\n"
       << "attention scale   : 1/sqrt(" << head_dim << ")\n"
       << "tied lm head      : " << (tied_output ? "yes" : "no") << "\n"
       << "attention bias    : " << (has_qkv_bias ? "yes" : "no") << "\n";
    if (embd_scale > 0.0f) os << "embedding scale   : sqrt(" << n_embd << ") = " << embd_scale << "\n";
    return os.str();
}

VocabData VocabData::FromGguf(const GgufInfo& g) {
    VocabData v;
    v.model = g.GetString("tokenizer.ggml.model");
    v.pre = g.GetString("tokenizer.ggml.pre");
    const GgufValue* toks = g.Find("tokenizer.ggml.tokens");
    if (toks && toks->IsArray()) {
        v.tokens.reserve(toks->arr.size());
        for (const auto& t : toks->arr) v.tokens.push_back(t.IsString() ? t.s : std::string());
    }
    const GgufValue* sc = g.Find("tokenizer.ggml.scores");
    if (sc && sc->IsArray()) {
        v.scores.reserve(sc->arr.size());
        for (const auto& t : sc->arr) v.scores.push_back(static_cast<float>(t.AsDouble()));
    }
    const GgufValue* tt = g.Find("tokenizer.ggml.token_type");
    if (tt && tt->IsArray()) {
        v.types.reserve(tt->arr.size());
        for (const auto& t : tt->arr) v.types.push_back(static_cast<int32_t>(t.AsInt()));
    }
    const GgufValue* mg = g.Find("tokenizer.ggml.merges");
    if (mg && mg->IsArray()) {
        v.merges.reserve(mg->arr.size());
        for (const auto& t : mg->arr) {
            if (t.IsString()) v.merges.push_back(t.s);
            else if (t.IsArray() && t.arr.size() == 2) {
                v.merges.push_back(t.arr[0].AsString() + " " + t.arr[1].AsString());
            }
        }
    }
    v.bos = static_cast<int32_t>(g.GetInt("tokenizer.ggml.bos_token_id", -1));
    v.eos = static_cast<int32_t>(g.GetInt("tokenizer.ggml.eos_token_id", -1));
    v.pad = static_cast<int32_t>(g.GetInt("tokenizer.ggml.padding_token_id", v.bos));
    v.unk = static_cast<int32_t>(g.GetInt("tokenizer.ggml.unknown_token_id", -1));
    v.add_bos = g.GetBool("tokenizer.ggml.add_bos_token", false);
    v.add_eos = g.GetBool("tokenizer.ggml.add_eos_token", false);
    return v;
}

static std::vector<uint32_t> BuildByteEncoder() {
    std::vector<uint32_t> table(256, 0);
    std::vector<int> bs;
    for (int c = '!'; c <= '~'; c++) bs.push_back(c);
    for (int c = 0xA1; c <= 0xAC; c++) bs.push_back(c);
    for (int c = 0xAE; c <= 0xFF; c++) bs.push_back(c);
    std::vector<uint32_t> cs;
    for (int b : bs) cs.push_back(static_cast<uint32_t>(b));
    int n = 0;
    for (int b = 0; b < 256; b++) {
        bool found = false;
        for (int x : bs) {
            if (x == b) { found = true; break; }
        }
        if (!found) {
            bs.push_back(b);
            cs.push_back(static_cast<uint32_t>(256 + n));
            n++;
        }
    }
    for (size_t i = 0; i < bs.size(); i++) table[static_cast<size_t>(bs[i])] = cs[i];
    return table;
}

static const std::vector<uint32_t>& ByteEncoderTable() {
    static const std::vector<uint32_t> t = BuildByteEncoder();
    return t;
}

static void AppendUtf8(std::string& out, uint32_t cp) {
    if (cp < 0x80) {
        out.push_back(static_cast<char>(cp));
    } else if (cp < 0x800) {
        out.push_back(static_cast<char>(0xC0 | (cp >> 6)));
        out.push_back(static_cast<char>(0x80 | (cp & 0x3F)));
    } else if (cp < 0x10000) {
        out.push_back(static_cast<char>(0xE0 | (cp >> 12)));
        out.push_back(static_cast<char>(0x80 | ((cp >> 6) & 0x3F)));
        out.push_back(static_cast<char>(0x80 | (cp & 0x3F)));
    } else {
        out.push_back(static_cast<char>(0xF0 | (cp >> 18)));
        out.push_back(static_cast<char>(0x80 | ((cp >> 12) & 0x3F)));
        out.push_back(static_cast<char>(0x80 | ((cp >> 6) & 0x3F)));
        out.push_back(static_cast<char>(0x80 | (cp & 0x3F)));
    }
}

static std::string EncodeBytesAsText(const std::string& utf8) {
    const auto& tbl = ByteEncoderTable();
    std::string out;
    out.reserve(utf8.size() * 3);
    for (unsigned char c : utf8) AppendUtf8(out, tbl[c]);
    return out;
}

static std::string DecodeTextAsBytes(const std::string& s) {
    std::unordered_map<uint32_t, uint8_t> rev;
    const auto& tbl = ByteEncoderTable();
    for (int i = 0; i < 256; i++) rev[tbl[i]] = static_cast<uint8_t>(i);
    std::string out;
    size_t i = 0;
    while (i < s.size()) {
        uint32_t cp = 0;
        unsigned char c = static_cast<unsigned char>(s[i]);
        size_t extra = 0;
        if (c < 0x80) { cp = c; extra = 0; }
        else if ((c >> 5) == 0x6) { cp = c & 0x1F; extra = 1; }
        else if ((c >> 4) == 0xE) { cp = c & 0x0F; extra = 2; }
        else if ((c >> 3) == 0x1E) { cp = c & 0x07; extra = 3; }
        else { i++; continue; }
        if (i + extra >= s.size() + 0 && extra > 0 && i + extra >= s.size()) { i++; continue; }
        for (size_t k = 1; k <= extra; k++) {
            if (i + k >= s.size()) break;
            cp = (cp << 6) | (static_cast<unsigned char>(s[i + k]) & 0x3F);
        }
        i += extra + 1;
        auto it = rev.find(cp);
        if (it != rev.end()) out.push_back(static_cast<char>(it->second));
        else AppendUtf8(out, cp);
    }
    return out;
}

static uint64_t HashPair(const std::string& a, const std::string& b) {
    uint64_t h = 1469598103934665603ull;
    auto mix = [&h](const std::string& s) {
        for (unsigned char c : s) {
            h ^= c;
            h *= 1099511628211ull;
        }
        h ^= 0x20;
        h *= 1099511628211ull;
    };
    mix(a);
    mix(b);
    return h;
}

void Tokenizer::Load(const VocabData& v) {
    tokens_ = v.tokens;
    bos_ = v.bos;
    eos_ = v.eos;
    pad_ = v.pad;
    unk_ = v.unk;
    spm_style_ = !(v.model == "gpt2");
    token_to_id_.reserve(tokens_.size() * 2);
    for (size_t i = 0; i < tokens_.size(); i++) {
        if (token_to_id_.find(tokens_[i]) == token_to_id_.end()) {
            token_to_id_.emplace(tokens_[i], static_cast<int32_t>(i));
        }
    }
    byte_fallback_.assign(256, -1);
    for (int i = 0; i < 256; i++) {
        char buf[8];
        snprintf(buf, sizeof(buf), "<0x%02X>", i);
        auto it = token_to_id_.find(buf);
        if (it != token_to_id_.end()) {
            byte_fallback_[i] = it->second;
            continue;
        }
        snprintf(buf, sizeof(buf), "<0x%02x>", i);
        it = token_to_id_.find(buf);
        if (it != token_to_id_.end()) byte_fallback_[i] = it->second;
    }
    BuildMergeRanks(v.merges);
    BuildPrefixIndex();
    BuildSpecials(v);
}

void Tokenizer::BuildMergeRanks(const std::vector<std::string>& merges) {
    merge_rank_.clear();
    if (merges.empty()) return;
    merge_rank_.reserve(merges.size() * 2);
    for (size_t i = 0; i < merges.size(); i++) {
        const std::string& m = merges[i];
        size_t sp = m.find(' ');
        if (sp == std::string::npos || sp == 0 || sp + 1 >= m.size()) continue;
        uint64_t h = HashPair(m.substr(0, sp), m.substr(sp + 1));
        if (merge_rank_.find(h) == merge_rank_.end()) {
            merge_rank_.emplace(h, static_cast<int32_t>(i));
        }
    }
    use_merges_ = !merge_rank_.empty();
}

void Tokenizer::BuildPrefixIndex() {
    longest_.clear();
    if (use_merges_) return;
    longest_.reserve(tokens_.size() * 2);
    for (size_t i = 0; i < tokens_.size(); i++) {
        const std::string& t = tokens_[i];
        if (t.empty()) continue;
        longest_.emplace(t, static_cast<int32_t>(i));
    }
}

int32_t Tokenizer::LookupToken(const std::string& s) const {
    auto it = token_to_id_.find(s);
    return it == token_to_id_.end() ? -1 : it->second;
}

std::vector<std::string> Tokenizer::Pretokenize(const std::string& text) const {
    std::vector<std::string> out;
    auto is_space = [](uint32_t cp) {
        return cp == ' ' || cp == '\t' || cp == '\n' || cp == '\r' || cp == 0x0B || cp == 0x0C || cp == 0xA0;
    };
    auto decode_cp = [](const std::string& s, size_t& i, uint32_t& cp) -> bool {
        if (i >= s.size()) return false;
        unsigned char c = static_cast<unsigned char>(s[i]);
        size_t extra = 0;
        if (c < 0x80) { cp = c; extra = 0; }
        else if ((c >> 5) == 0x6) { cp = c & 0x1Fu; extra = 1; }
        else if ((c >> 4) == 0xE) { cp = c & 0x0Fu; extra = 2; }
        else if ((c >> 3) == 0x1E) { cp = c & 0x07u; extra = 3; }
        else { cp = c; i++; return true; }
        if (i + extra >= s.size()) { cp = c; i++; return true; }
        for (size_t k = 1; k <= extra; k++) {
            cp = (cp << 6) | (static_cast<unsigned char>(s[i + k]) & 0x3Fu);
        }
        i += extra + 1;
        return true;
    };
    auto is_alpha = [](uint32_t cp) {
        if (cp < 0x80) return (cp >= 'a' && cp <= 'z') || (cp >= 'A' && cp <= 'Z');
        return (cp >= 0x00C0 && cp <= 0x024F) || (cp >= 0x0370 && cp <= 0x052F) ||
               (cp >= 0x0400 && cp <= 0x05FF) || (cp >= 0x0590 && cp <= 0x06FF) ||
               (cp >= 0x0900 && cp <= 0x097F) || (cp >= 0x1E00 && cp <= 0x1EFF) ||
               (cp >= 0x3040 && cp <= 0x30FF) || (cp >= 0x3400 && cp <= 0x4DBF) ||
               (cp >= 0x4E00 && cp <= 0x9FFF) || (cp >= 0xAC00 && cp <= 0xD7AF) ||
               (cp >= 0xF900 && cp <= 0xFAFF);
    };
    auto is_digit = [](uint32_t cp) { return cp >= '0' && cp <= '9'; };
    auto is_cjk = [](uint32_t cp) {
        return (cp >= 0x3040 && cp <= 0x30FF) || (cp >= 0x3400 && cp <= 0x4DBF) ||
               (cp >= 0x4E00 && cp <= 0x9FFF) || (cp >= 0xAC00 && cp <= 0xD7AF) ||
               (cp >= 0xF900 && cp <= 0xFAFF);
    };

    size_t i = 0;
    while (i < text.size()) {
        size_t start = i;
        uint32_t cp = 0;
        if (!decode_cp(text, i, cp)) break;
        if (is_space(cp)) {
            std::string chunk = text.substr(start, i - start);
            while (i < text.size()) {
                size_t save = i;
                uint32_t c2 = 0;
                if (!decode_cp(text, i, c2)) break;
                if (!is_space(c2)) { i = save; break; }
                chunk.append(text, save, i - save);
            }
            out.push_back(chunk);
            continue;
        }
        if (is_digit(cp)) {
            out.push_back(text.substr(start, i - start));
            continue;
        }
        if (is_cjk(cp)) {
            out.push_back(text.substr(start, i - start));
            continue;
        }
        if (is_alpha(cp)) {
            std::string chunk = text.substr(start, i - start);
            while (i < text.size()) {
                size_t save = i;
                uint32_t c2 = 0;
                if (!decode_cp(text, i, c2)) break;
                if (!is_alpha(c2)) { i = save; break; }
                chunk.append(text, save, i - save);
            }
            out.push_back(chunk);
            continue;
        }
        if (cp == '\'' || cp == 0x2019) {
            static const char* suffixes[] = {"s", "t", "re", "ve", "m", "ll", "d"};
            bool matched = false;
            for (const char* suf : suffixes) {
                size_t len = strlen(suf);
                if (i + len <= text.size() && strncasecmp(text.c_str() + i, suf, len) == 0) {
                    bool boundary = (i + len >= text.size()) ||
                                    !is_alpha(static_cast<unsigned char>(text[i + len]));
                    if (boundary) {
                        out.push_back(text.substr(start, i - start + len));
                        i += len;
                        matched = true;
                        break;
                    }
                }
            }
            if (matched) continue;
        }
        std::string chunk = text.substr(start, i - start);
        while (i < text.size()) {
            size_t save = i;
            uint32_t c2 = 0;
            if (!decode_cp(text, i, c2)) break;
            if (is_space(c2) || is_alpha(c2) || is_digit(c2) || is_cjk(c2)) { i = save; break; }
            chunk.append(text, save, i - save);
        }
        out.push_back(chunk);
    }
    std::vector<std::string> merged;
    merged.reserve(out.size());
    for (size_t k = 0; k < out.size(); k++) {
        bool space_only = !out[k].empty();
        for (char c : out[k]) {
            if (c != ' ' && c != '\t' && c != '\n' && c != '\r') { space_only = false; break; }
        }
        if (space_only && k + 1 < out.size()) {
            std::string lead = out[k];
            size_t cut = lead.find('\n');
            if (cut != std::string::npos) lead = lead.substr(0, cut);
            merged.push_back(lead + out[k + 1]);
            k++;
        } else {
            merged.push_back(out[k]);
        }
    }
    return merged;
}

std::vector<int32_t> Tokenizer::ByteFallback(const std::string& word) const {
    std::vector<int32_t> ids;
    for (unsigned char c : word) {
        if (byte_fallback_[c] >= 0) {
            ids.push_back(byte_fallback_[c]);
        } else if (unk_ >= 0) {
            ids.push_back(unk_);
        }
    }
    return ids;
}

static void SplitCodepoints(const std::string& s, std::vector<std::string>& out) {
    size_t i = 0;
    while (i < s.size()) {
        unsigned char c = static_cast<unsigned char>(s[i]);
        size_t len = 1;
        if (c < 0x80) len = 1;
        else if ((c >> 5) == 0x6) len = 2;
        else if ((c >> 4) == 0xE) len = 3;
        else if ((c >> 3) == 0x1E) len = 4;
        if (i + len > s.size()) len = s.size() - i;
        out.push_back(s.substr(i, len));
        i += len;
    }
}

std::vector<int32_t> Tokenizer::BpeWord(const std::string& word) const {
    std::vector<std::string> parts;
    SplitCodepoints(word, parts);
    if (parts.empty()) return {};
    if (use_merges_) {
        while (parts.size() > 1) {
            int32_t best_rank = std::numeric_limits<int32_t>::max();
            size_t best_at = 0;
            bool found = false;
            for (size_t k = 0; k + 1 < parts.size(); k++) {
                uint64_t h = HashPair(parts[k], parts[k + 1]);
                auto it = merge_rank_.find(h);
                if (it == merge_rank_.end()) continue;
                if (it->second < best_rank) {
                    best_rank = it->second;
                    best_at = k;
                    found = true;
                }
            }
            if (!found) break;
            const std::string first = parts[best_at];
            const std::string second = parts[best_at + 1];
            std::vector<std::string> next;
            next.reserve(parts.size());
            size_t i = 0;
            while (i < parts.size()) {
                if (parts[i] == first && i + 1 < parts.size() && parts[i + 1] == second) {
                    next.push_back(first + second);
                    i += 2;
                } else {
                    next.push_back(parts[i]);
                    i += 1;
                }
            }
            if (next.size() == parts.size()) break;
            parts.swap(next);
        }
    } else {
        std::vector<std::string> next;
        size_t i = 0;
        while (i < word.size()) {
            size_t best_len = 0;
            size_t max_len = std::min<size_t>(word.size() - i, 64);
            for (size_t len = max_len; len >= 1; len--) {
                auto it = token_to_id_.find(word.substr(i, len));
                if (it != token_to_id_.end()) {
                    best_len = len;
                    break;
                }
            }
            if (best_len == 0) best_len = 1;
            next.push_back(word.substr(i, best_len));
            i += best_len;
        }
        parts.swap(next);
        if (parts.empty()) SplitCodepoints(word, parts);
    }
    std::vector<int32_t> ids;
    for (const auto& p : parts) {
        int32_t id = LookupToken(p);
        if (id >= 0) {
            ids.push_back(id);
        } else {
            std::vector<int32_t> fb = spm_style_ ? ByteFallback(p) : ByteFallback(DecodeTextAsBytes(p));
            ids.insert(ids.end(), fb.begin(), fb.end());
        }
    }
    return ids;
}

void Tokenizer::BuildSpecials(const VocabData& v) {
    specials_.clear();
    special_first_.assign(256, false);
    special_max_ = 0;
    for (size_t i = 0; i < tokens_.size(); i++) {
        const std::string& t = tokens_[i];
        if (t.empty() || t.size() > 64) continue;
        int32_t id = static_cast<int32_t>(i);
        bool is_special = false;
        if (i < v.types.size() && (v.types[i] == 3 || v.types[i] == 2)) is_special = true;
        if (!is_special && (id == bos_ || id == eos_ || id == pad_ || id == unk_) && t.front() == '<' &&
            t.back() == '>') {
            is_special = true;
        }
        if (!is_special) continue;
        specials_.emplace_back(t, id);
    }
    std::stable_sort(specials_.begin(), specials_.end(),
                     [](const std::pair<std::string, int32_t>& a, const std::pair<std::string, int32_t>& b) {
                         return a.first.size() > b.first.size();
                     });
    for (const auto& s : specials_) {
        special_first_[static_cast<uint8_t>(s.first[0])] = true;
        if (s.first.size() > special_max_) special_max_ = s.first.size();
    }
}

std::vector<int32_t> Tokenizer::Encode(const std::string& text, bool add_bos) const {
    std::vector<int32_t> ids;
    if (add_bos && bos_ >= 0) ids.push_back(bos_);
    if (text.empty()) return ids;
    if (specials_.empty() || special_max_ == 0) {
        EncodeChunk(text, ids);
        return ids;
    }
    std::string chunk;
    size_t i = 0;
    while (i < text.size()) {
        int32_t hit = -1;
        size_t hit_len = 0;
        uint8_t c = static_cast<uint8_t>(text[i]);
        if (special_first_[c] && text.size() - i >= 2) {
            for (const auto& s : specials_) {
                if (s.first.size() > text.size() - i) continue;
                if (memcmp(text.data() + i, s.first.data(), s.first.size()) == 0) {
                    hit = s.second;
                    hit_len = s.first.size();
                    break;
                }
            }
        }
        if (hit >= 0) {
            if (!chunk.empty()) {
                EncodeChunk(chunk, ids);
                chunk.clear();
            }
            ids.push_back(hit);
            i += hit_len;
            continue;
        }
        chunk.push_back(text[i]);
        i++;
    }
    if (!chunk.empty()) EncodeChunk(chunk, ids);
    return ids;
}

void Tokenizer::EncodeChunk(const std::string& text, std::vector<int32_t>& ids) const {
    if (text.empty()) return;
    if (!spm_style_) {
        std::vector<std::string> words = Pretokenize(text);
        for (const auto& w : words) {
            std::string enc = EncodeBytesAsText(w);
            std::vector<int32_t> sub = BpeWord(enc);
            ids.insert(ids.end(), sub.begin(), sub.end());
        }
        return;
    }
    std::string norm;
    norm.reserve(text.size() + 8);
    norm += "\xE2\x96\x81";
    for (size_t i = 0; i < text.size(); i++) {
        char c = text[i];
        if (c == ' ') {
            if (!norm.empty() && norm.compare(norm.size() - 3, 3, "\xE2\x96\x81") != 0) norm += "\xE2\x96\x81";
        } else if (c == '\n') {
            norm += "<0x0A>";
        } else if (c == '\t') {
            norm += "<0x09>";
        } else if (c == '\r') {
            norm += "<0x0D>";
        } else {
            norm.push_back(c);
        }
    }
    std::vector<std::string> words;
    const std::string sp = "\xE2\x96\x81";
    size_t i = 0;
    size_t start = 0;
    while (i < norm.size()) {
        if (i > 0 && norm.compare(i, sp.size(), sp) == 0) {
            words.push_back(norm.substr(start, i - start));
            start = i;
            i += sp.size();
            continue;
        }
        i++;
    }
    words.push_back(norm.substr(start));
    for (const auto& w : words) {
        if (w.empty()) continue;
        std::vector<int32_t> sub = BpeWord(w);
        ids.insert(ids.end(), sub.begin(), sub.end());
    }
}

std::string Tokenizer::DecodePiece(const std::string& piece) const {
    if (piece.size() == 6 && piece[0] == '<' && piece[1] == '0' && piece[2] == 'x' && piece[5] == '>') {
        auto hexv = [](char c, int& v) -> bool {
            if (c >= '0' && c <= '9') { v = c - '0'; return true; }
            if (c >= 'a' && c <= 'f') { v = c - 'a' + 10; return true; }
            if (c >= 'A' && c <= 'F') { v = c - 'A' + 10; return true; }
            return false;
        };
        int hi = 0, lo = 0;
        if (hexv(piece[3], hi) && hexv(piece[4], lo)) {
            return std::string(1, static_cast<char>((hi << 4) | lo));
        }
    }
    return piece;
}

std::string Tokenizer::Decode(const std::vector<int32_t>& ids) const {
    std::string joined;
    for (int32_t id : ids) {
        if (id < 0 || static_cast<size_t>(id) >= tokens_.size()) continue;
        if (id == bos_ || id == eos_ || id == pad_) continue;
        joined += DecodePiece(tokens_[static_cast<size_t>(id)]);
    }
    if (!spm_style_) return DecodeTextAsBytes(joined);
    std::string out;
    const std::string sp = "\xE2\x96\x81";
    size_t i = 0;
    while (i < joined.size()) {
        if (joined.compare(i, sp.size(), sp) == 0) {
            if (!out.empty()) out.push_back(' ');
            i += sp.size();
        } else {
            out.push_back(joined[i]);
            i++;
        }
    }
    return out;
}

}
namespace aip {

void PutLe32(uint8_t* p, uint32_t v) {
    p[0] = static_cast<uint8_t>(v);
    p[1] = static_cast<uint8_t>(v >> 8);
    p[2] = static_cast<uint8_t>(v >> 16);
    p[3] = static_cast<uint8_t>(v >> 24);
}

void PutLe64(uint8_t* p, uint64_t v) {
    for (int i = 0; i < 8; i++) p[i] = static_cast<uint8_t>(v >> (8 * i));
}

uint32_t GetLe32(const uint8_t* p) {
    return static_cast<uint32_t>(p[0]) | (static_cast<uint32_t>(p[1]) << 8) |
           (static_cast<uint32_t>(p[2]) << 16) | (static_cast<uint32_t>(p[3]) << 24);
}

uint64_t GetLe64(const uint8_t* p) {
    uint64_t v = 0;
    for (int i = 0; i < 8; i++) v |= static_cast<uint64_t>(p[i]) << (8 * i);
    return v;
}

static void EnsureSodium() {
    static const int rc = sodium_init();
    if (rc < 0) {
        ThrowError(ErrClass::kCrypto, "libsodium failed to initialize");
    }
}

void SodiumStartup() { EnsureSodium(); }

std::string SodiumVersion() {
    EnsureSodium();
    return std::string(sodium_version_string());
}

KdfParams KdfParams::Generate(uint64_t opslimit, uint64_t memlimit_kib) {
    EnsureSodium();
    KdfParams p;
    p.alg = 1;
    p.opslimit = opslimit;
    p.memlimit_kib = memlimit_kib;
    random::Bytes(p.salt.data(), p.salt.size());
    p.ClampToLibraryLimits();
    return p;
}

void KdfParams::ClampToLibraryLimits() {
    if (alg != 1) alg = 1;
    if (opslimit < crypto_pwhash_argon2id_OPSLIMIT_MIN) opslimit = crypto_pwhash_argon2id_OPSLIMIT_MIN;
    if (opslimit > crypto_pwhash_argon2id_OPSLIMIT_MAX) opslimit = crypto_pwhash_argon2id_OPSLIMIT_MAX;
    uint64_t min_mem = crypto_pwhash_argon2id_MEMLIMIT_MIN / 1024u;
    uint64_t max_mem = crypto_pwhash_argon2id_MEMLIMIT_MAX / 1024u;
    uint64_t floor_by_ops = opslimit * 8u * 1024u;
    if (memlimit_kib < floor_by_ops) memlimit_kib = floor_by_ops;
    if (memlimit_kib < min_mem) memlimit_kib = min_mem;
    if (memlimit_kib > max_mem) memlimit_kib = max_mem;
}

std::string KdfParams::Describe() const {
    return FormatErrorF("Argon2id (opslimit=%llu, memlimit=%llu MiB, salt=%s)",
                        static_cast<unsigned long long>(opslimit),
                        static_cast<unsigned long long>(memlimit_kib / 1024u),
                        HexEncode(salt.data(), salt.size()).c_str());
}

DerivedKey KdfDerive(const std::string& password, const KdfParams& p) {
    EnsureSodium();
    if (p.alg != 1) {
        ThrowErrorF(ErrClass::kCrypto, "unsupported key derivation algorithm id %u", p.alg);
    }
    if (password.empty()) {
        ThrowError(ErrClass::kUsage, "an empty password is not accepted");
    }
    if (password.size() > crypto_pwhash_PASSWD_MAX) {
        ThrowError(ErrClass::kUsage, "the password is longer than the Argon2id maximum");
    }
    DerivedKey out;
    out.key.resize(kMasterKeyBytes);
    unsigned long long opslimit = static_cast<unsigned long long>(p.opslimit);
    unsigned long long memlimit = static_cast<unsigned long long>(p.memlimit_kib) * 1024ull;
    int rc = crypto_pwhash(out.key.data(), out.key.size(), password.data(), password.size(),
                           p.salt.data(), opslimit, memlimit, crypto_pwhash_ALG_ARGON2ID13);
    if (rc != 0) {
        out.key.Clear();
        if (memlimit > static_cast<unsigned long long>(crypto_pwhash_argon2id_MEMLIMIT_MAX)) {
            ThrowErrorF(ErrClass::kMemory,
                        "Argon2id requires %llu MiB of memory which exceeds what this process can allocate",
                        static_cast<unsigned long long>(memlimit / (1024 * 1024)));
        }
        ThrowError(ErrClass::kCrypto, "Argon2id key derivation failed");
    }
    return out;
}

bool KdfVerify(const std::string& password, const KdfParams& p, std::span<const uint8_t> expected) {
    DerivedKey k = KdfDerive(password, p);
    bool ok = false;
    if (k.key.size() == expected.size()) {
        ok = sodium_memcmp(k.key.data(), expected.data(), expected.size()) == 0;
    }
    k.key.Clear();
    return ok;
}

void KeyRing::Clear() {
    master.Clear();
    weights.Clear();
    manifest.Clear();
    bytecode.Clear();
    integrity.Clear();
    rmp.Clear();
    vocab.Clear();
}

static void DeriveSubKey(const SecureBytes& root, const char* label, SecureBytes& out) {
    out.resize(kMasterKeyBytes);
    std::vector<uint8_t> msg(label, label + strlen(label));
    msg.push_back(0x01);
    if (crypto_auth_hmacsha512256(out.data(), msg.data(), msg.size(), root.data()) != 0) {
        out.Clear();
        sodium_memzero(msg.data(), msg.size());
        ThrowError(ErrClass::kCrypto, "subkey derivation failed");
    }
    sodium_memzero(msg.data(), msg.size());
}

static void HmacOnce(std::span<const uint8_t> key, std::span<const uint8_t> msg, uint8_t out[32]) {
    if (crypto_auth_hmacsha512256(out, msg.data(), static_cast<unsigned long long>(msg.size()), key.data()) != 0) {
        ThrowError(ErrClass::kCrypto, "HMAC-SHA512/256 computation failed");
    }
}

KeyRing KeyRing::Derive(const SecureBytes& master, std::span<const uint8_t, 16> container_id) {
    EnsureSodium();
    KeyRing ring;
    if (master.size() != kMasterKeyBytes) {
        ThrowError(ErrClass::kCrypto, "master key has an unexpected length");
    }
    SecureBytes root;
    root.resize(kMasterKeyBytes);
    std::vector<uint8_t> msg;
    msg.reserve(96);
    const char* dom = "AIProtect/v1/container-keyring";
    msg.insert(msg.end(), dom, dom + strlen(dom));
    msg.insert(msg.end(), container_id.begin(), container_id.end());
    HmacOnce(master.Span(), std::span<const uint8_t>(msg.data(), msg.size()), root.data());
    sodium_memzero(msg.data(), msg.size());
    DeriveSubKey(root, "AIProtect/v1/subkey/weights", ring.weights);
    DeriveSubKey(root, "AIProtect/v1/subkey/manifest", ring.manifest);
    DeriveSubKey(root, "AIProtect/v1/subkey/bytecode", ring.bytecode);
    DeriveSubKey(root, "AIProtect/v1/subkey/integrity", ring.integrity);
    DeriveSubKey(root, "AIProtect/v1/subkey/rmp", ring.rmp);
    DeriveSubKey(root, "AIProtect/v1/subkey/vocab", ring.vocab);
    ring.master.resize(master.size());
    memcpy(ring.master.data(), master.data(), master.size());
    root.Clear();
    return ring;
}

void BlockCipher::BuildNonce(std::array<uint8_t, kNonceBytes>& nonce,
                             std::span<const uint8_t, 8> section_nonce,
                             uint32_t section_id, uint64_t chunk_index) {
    nonce.fill(0);
    memcpy(nonce.data(), section_nonce.data(), 8);
    PutLe32(nonce.data() + 8, section_id);
    PutLe64(nonce.data() + 16, chunk_index);
}

bool BlockCipher::Encrypt(std::span<const uint8_t> key, std::span<const uint8_t, kNonceBytes> nonce,
                          std::span<const uint8_t> aad, std::span<const uint8_t> plain,
                          uint8_t* out, size_t out_cap, size_t& out_len) {
    EnsureSodium();
    if (key.size() != kKeyBytes) return false;
    if (out_cap < plain.size() + kTagBytes) return false;
    unsigned long long clen = 0;
    int rc = crypto_aead_xchacha20poly1305_ietf_encrypt(
        out, &clen, plain.data(), plain.size(), aad.empty() ? nullptr : aad.data(), aad.size(),
        nullptr, nonce.data(), key.data());
    if (rc != 0) return false;
    out_len = static_cast<size_t>(clen);
    return true;
}

bool BlockCipher::Decrypt(std::span<const uint8_t> key, std::span<const uint8_t, kNonceBytes> nonce,
                          std::span<const uint8_t> aad, std::span<const uint8_t> cipher,
                          uint8_t* out, size_t out_cap, size_t& out_len) {
    EnsureSodium();
    if (key.size() != kKeyBytes) return false;
    if (cipher.size() < kTagBytes) return false;
    if (cipher.size() - kTagBytes > out_cap) return false;
    unsigned long long mlen = 0;
    int rc = crypto_aead_xchacha20poly1305_ietf_decrypt(
        out, &mlen, nullptr, cipher.data(), cipher.size(), aad.empty() ? nullptr : aad.data(), aad.size(),
        nonce.data(), key.data());
    if (rc != 0) return false;
    out_len = static_cast<size_t>(mlen);
    return true;
}

struct KeyedHash::State {
    crypto_auth_hmacsha512256_state st{};
    SecureBytes key;
};

KeyedHash::KeyedHash(std::span<const uint8_t> key) : st_(std::make_unique<State>()) {
    EnsureSodium();
    if (key.size() < 16) ThrowError(ErrClass::kCrypto, "MAC key is too short");
    std::array<uint8_t, ChunkMac::kKeyBytes> padded{};
    if (key.size() >= ChunkMac::kKeyBytes) {
        memcpy(padded.data(), key.data(), ChunkMac::kKeyBytes);
    } else {
        memcpy(padded.data(), key.data(), key.size());
    }
    st_->key.Assign(padded.data(), padded.size());
    crypto_auth_hmacsha512256_init(&st_->st, st_->key.data(), st_->key.size());
}

KeyedHash::~KeyedHash() {
    if (st_) {
        st_->key.Clear();
    }
}

void KeyedHash::Update(const void* p, size_t n) {
    crypto_auth_hmacsha512256_update(&st_->st, static_cast<const unsigned char*>(p), n);
}

void KeyedHash::Final(uint8_t out[32]) {
    crypto_auth_hmacsha512256_final(&st_->st, out);
}

void KeyedHash::Once(std::span<const uint8_t> key, std::span<const uint8_t> data, uint8_t out[32]) {
    EnsureSodium();
    std::array<uint8_t, ChunkMac::kKeyBytes> padded{};
    if (key.size() >= ChunkMac::kKeyBytes) memcpy(padded.data(), key.data(), ChunkMac::kKeyBytes);
    else memcpy(padded.data(), key.data(), key.size());
    crypto_auth_hmacsha512256_state st;
    crypto_auth_hmacsha512256_init(&st, padded.data(), padded.size());
    crypto_auth_hmacsha512256_update(&st, data.data(), data.size());
    crypto_auth_hmacsha512256_final(&st, out);
    sodium_memzero(padded.data(), padded.size());
    sodium_memzero(&st, sizeof(st));
}

void KeyedHash::Plain(std::span<const uint8_t> data, uint8_t out[32]) {
    EnsureSodium();
    crypto_generichash(out, 32, data.data(), data.size(), nullptr, 0);
}

const char* SectionPurposeName(SectionPurpose p) {
    switch (p) {
        case SectionPurpose::kManifest: return "manifest";
        case SectionPurpose::kBytecode: return "bytecode";
        case SectionPurpose::kWeights: return "weights";
        case SectionPurpose::kRmp: return "rmp-policy";
        case SectionPurpose::kVocab: return "vocabulary";
        default: return "unknown";
    }
}

void BuildChunkAad(std::span<const uint8_t, 16> container_id, uint32_t section_id, uint32_t purpose,
                   uint64_t chunk_index, uint64_t chunk_plain_size, std::array<uint8_t, 40>& aad) {
    memcpy(aad.data(), container_id.data(), 16);
    PutLe32(aad.data() + 16, section_id);
    PutLe32(aad.data() + 20, purpose);
    PutLe64(aad.data() + 24, chunk_index);
    PutLe64(aad.data() + 32, chunk_plain_size);
}

}
namespace aip {

static void WriteAxis(ByteWriter& w, const TransformRecord::Axis& ax) {
    w.U32(ax.kind);
    w.U32(ax.enabled);
    w.U32(ax.length);
    w.U32(ax.granularity);
    w.U32(ax.group_count);
    w.U32(ax.signed_perm);
    w.U64(ax.perm.size());
    for (uint32_t v : ax.perm) w.U32(v);
    w.U64(ax.kv_perm.size());
    for (uint32_t v : ax.kv_perm) w.U32(v);
    w.U64(ax.signs.size());
    for (int8_t v : ax.signs) w.U8(v > 0 ? 1u : 0u);
}

static bool ReadAxis(ByteReader& r, TransformRecord::Axis& ax, size_t budget) {
    if (!r.U32(ax.kind) || !r.U32(ax.enabled) || !r.U32(ax.length) || !r.U32(ax.granularity) ||
        !r.U32(ax.group_count) || !r.U32(ax.signed_perm)) {
        return false;
    }
    if (ax.length > (1u << 22) || ax.group_count > (1u << 22)) return false;
    uint64_t pn = 0;
    if (!r.U64(pn)) return false;
    if (pn > budget || pn > ax.group_count + 1) return false;
    ax.perm.resize(static_cast<size_t>(pn));
    for (uint64_t i = 0; i < pn; i++) {
        if (!r.U32(ax.perm[static_cast<size_t>(i)])) return false;
        if (ax.perm[static_cast<size_t>(i)] >= ax.length && ax.length != 0) return false;
    }
    uint64_t kn = 0;
    if (!r.U64(kn)) return false;
    if (kn > budget || kn > (1u << 22)) return false;
    ax.kv_perm.resize(static_cast<size_t>(kn));
    for (uint64_t i = 0; i < kn; i++) {
        if (!r.U32(ax.kv_perm[static_cast<size_t>(i)])) return false;
        if (ax.kv_perm[static_cast<size_t>(i)] >= ax.length && ax.length != 0) return false;
    }
    uint64_t sn = 0;
    if (!r.U64(sn)) return false;
    if (sn > budget || sn > ax.group_count + 1) return false;
    ax.signs.resize(static_cast<size_t>(sn));
    for (uint64_t i = 0; i < sn; i++) {
        uint8_t v = 0;
        if (!r.U8(v)) return false;
        if (v != 0 && v != 1) return false;
        ax.signs[static_cast<size_t>(i)] = v ? 1 : -1;
    }
    return true;
}

std::vector<uint8_t> Manifest::Serialize() const {
    ByteWriter w;
    w.U32(kManifestMagic);
    w.U32(kManifestVersion);
    w.U32(model.arch);
    w.Str(model.arch_name);
    w.Str(model.general_name);
    w.U32(model.n_layer);
    w.U32(model.n_vocab);
    w.U32(model.n_embd);
    w.U32(model.n_ff);
    w.U32(model.n_head);
    w.U32(model.n_head_kv);
    w.U32(model.n_ctx_train);
    w.U32(model.head_dim);
    w.U32(model.n_rot);
    w.U32(model.n_embd_gqa);
    w.U32(model.n_embd_v_gqa);
    w.F32(model.rope_theta);
    w.F32(model.rope_scale);
    w.F32(model.norm_eps);
    w.U32(model.norm_kind);
    w.U32(model.ffn_kind);
    w.U32(model.tied_output);
    w.U32(model.has_qkv_bias);
    w.U32(model.has_output_bias);
    w.F32(model.embd_scale);
    w.F32(model.attn_logit_scale);
    w.F32(model.attn_softcap);
    w.F32(model.final_softcap);
    w.Str(model.rope_scaling_type);

    w.Str(prov.source_file_name);
    w.U64(prov.source_file_size);
    w.U32(prov.source_gguf_version);
    w.Raw(prov.source_digest, 32);
    w.I64(prov.created_unix);
    w.Str(prov.created_by);

    w.U32(transform.enabled);
    WriteAxis(w, transform.residual);
    WriteAxis(w, transform.ffn);
    WriteAxis(w, transform.head);
    WriteAxis(w, transform.vocab);
    w.U64(transform.key_space_bits);
    w.U64(transform.notes.size());
    for (const auto& n : transform.notes) w.Str(n);

    w.U32(rmp.policy.enabled ? 1u : 0u);
    w.U32(rmp.policy.anti_debug ? 1u : 0u);
    w.U32(rmp.policy.periodic_integrity ? 1u : 0u);
    w.U32(rmp.policy.verify_blocks ? 1u : 0u);
    w.U32(rmp.policy.env_scan ? 1u : 0u);
    w.U32(rmp.policy.probe_interval_tokens);
    w.U32(rmp.policy.max_violations);
    w.U32(rmp.policy.allow_ptrace_self ? 1u : 0u);
    w.U32(rmp.anti_debug_available);
    w.Str(rmp.platform);

    w.U32(storage_type);
    w.U64(weights_plain_bytes);
    w.U32(bytecode_present);
    w.U64(bytecode_size);
    w.Raw(bytecode_digest, 32);

    w.U64(tensors.size());
    for (const auto& t : tensors) {
        w.U32(t.slot_id);
        w.Str(t.name);
        w.U32(t.role);
        w.I32(t.layer);
        w.U32(t.type_id);
        w.U32(t.n_dims);
        for (int i = 0; i < 4; i++) w.U64(t.dims[i]);
        w.U64(t.n_elems);
        w.U64(t.n_rows);
        w.U64(t.row_elems);
        w.U32(t.block_size);
        w.U32(t.type_size);
        w.U64(t.row_bytes);
        w.U64(t.total_bytes);
        w.U64(t.stream_offset);
        w.U32(t.transform_mask);
        w.Raw(t.digest, 32);
    }

    w.U64(warnings.size());
    for (const auto& s : warnings) w.Str(s);
    w.U32(0xA11CE001u);
    return w.Take();
}

bool Manifest::Deserialize(std::span<const uint8_t> data, Manifest& out, std::string& err) {
    ByteReader r(data);
    auto bad = [&](const char* what) {
        err = std::string("corrupt AIProtect manifest: ") + what;
        return false;
    };
    uint32_t magic = 0, version = 0;
    if (!r.U32(magic) || !r.U32(version)) return bad("truncated header");
    if (magic != kManifestMagic) return bad("bad magic");
    if (version != kManifestVersion) {
        err = FormatErrorF("AIProtect manifest version %u is not supported by this build (expected %u)", version,
                           kManifestVersion);
        return false;
    }
    Manifest m;
    if (!r.U32(m.model.arch)) return bad("arch");
    if (!r.Str(m.model.arch_name, 128)) return bad("arch name");
    if (!r.Str(m.model.general_name, 4096)) return bad("general name");
    if (!r.U32(m.model.n_layer) || !r.U32(m.model.n_vocab) || !r.U32(m.model.n_embd) ||
        !r.U32(m.model.n_ff) || !r.U32(m.model.n_head) || !r.U32(m.model.n_head_kv) ||
        !r.U32(m.model.n_ctx_train) || !r.U32(m.model.head_dim) || !r.U32(m.model.n_rot) ||
        !r.U32(m.model.n_embd_gqa) || !r.U32(m.model.n_embd_v_gqa)) {
        return bad("model dimensions");
    }
    if (!r.F32(m.model.rope_theta) || !r.F32(m.model.rope_scale) || !r.F32(m.model.norm_eps)) {
        return bad("model floats");
    }
    if (!r.U32(m.model.norm_kind) || !r.U32(m.model.ffn_kind) || !r.U32(m.model.tied_output) ||
        !r.U32(m.model.has_qkv_bias) || !r.U32(m.model.has_output_bias)) {
        return bad("model flags");
    }
    if (!r.F32(m.model.embd_scale) || !r.F32(m.model.attn_logit_scale) || !r.F32(m.model.attn_softcap) ||
        !r.F32(m.model.final_softcap)) {
        return bad("model scales");
    }
    if (!r.Str(m.model.rope_scaling_type, 64)) return bad("rope scaling");
    if (!r.Str(m.prov.source_file_name, 8192)) return bad("source name");
    if (!r.U64(m.prov.source_file_size) || !r.U32(m.prov.source_gguf_version)) return bad("provenance");
    if (!r.Raw(m.prov.source_digest, 32)) return bad("source digest");
    if (!r.I64(m.prov.created_unix)) return bad("timestamp");
    if (!r.Str(m.prov.created_by, 256)) return bad("producer");
    if (!r.U32(m.transform.enabled)) return bad("transform flag");
    if (!ReadAxis(r, m.transform.residual, data.size())) return bad("residual axis");
    if (!ReadAxis(r, m.transform.ffn, data.size())) return bad("ffn axis");
    if (!ReadAxis(r, m.transform.head, data.size())) return bad("head axis");
    if (!ReadAxis(r, m.transform.vocab, data.size())) return bad("vocab axis");
    if (!r.U64(m.transform.key_space_bits)) return bad("key space");
    uint64_t nn = 0;
    if (!r.U64(nn) || nn > 4096) return bad("notes count");
    for (uint64_t i = 0; i < nn; i++) {
        std::string s;
        if (!r.Str(s, 4096)) return bad("note");
        m.transform.notes.push_back(std::move(s));
    }
    uint32_t f = 0;
    if (!r.U32(f)) return bad("rmp enabled");
    m.rmp.policy.enabled = f != 0;
    if (!r.U32(f)) return bad("rmp anti debug");
    m.rmp.policy.anti_debug = f != 0;
    if (!r.U32(f)) return bad("rmp periodic");
    m.rmp.policy.periodic_integrity = f != 0;
    if (!r.U32(f)) return bad("rmp verify blocks");
    m.rmp.policy.verify_blocks = f != 0;
    if (!r.U32(f)) return bad("rmp env scan");
    m.rmp.policy.env_scan = f != 0;
    if (!r.U32(m.rmp.policy.probe_interval_tokens)) return bad("rmp interval");
    if (!r.U32(m.rmp.policy.max_violations)) return bad("rmp max violations");
    if (!r.U32(f)) return bad("rmp ptrace self");
    m.rmp.policy.allow_ptrace_self = f != 0;
    if (!r.U32(m.rmp.anti_debug_available)) return bad("rmp capability");
    if (!r.Str(m.rmp.platform, 64)) return bad("rmp platform");
    if (!r.U32(m.storage_type)) return bad("storage type");
    if (!r.U64(m.weights_plain_bytes)) return bad("weights plain bytes");
    if (!r.U32(m.bytecode_present)) return bad("bytecode flag");
    if (!r.U64(m.bytecode_size)) return bad("bytecode size");
    if (!r.Raw(m.bytecode_digest, 32)) return bad("bytecode digest");

    uint64_t n_tensors = 0;
    if (!r.U64(n_tensors)) return bad("tensor count");
    if (n_tensors > (4u << 20)) return bad("tensor count out of range");
    m.tensors.reserve(static_cast<size_t>(std::min<uint64_t>(n_tensors, 1u << 16)));
    for (uint64_t i = 0; i < n_tensors; i++) {
        ManifestTensor t;
        if (!r.U32(t.slot_id)) return bad("slot id");
        if (!r.Str(t.name, 4096)) return bad("tensor name");
        if (!r.U32(t.role) || !r.I32(t.layer) || !r.U32(t.type_id) || !r.U32(t.n_dims)) {
            return bad("tensor header");
        }
        if (t.n_dims > 4) return bad("tensor dims");
        for (int d = 0; d < 4; d++) {
            if (!r.U64(t.dims[d])) return bad("tensor dim");
        }
        if (!r.U64(t.n_elems) || !r.U64(t.n_rows) || !r.U64(t.row_elems)) return bad("tensor sizes");
        if (!r.U32(t.block_size) || !r.U32(t.type_size)) return bad("tensor block");
        if (!r.U64(t.row_bytes) || !r.U64(t.total_bytes) || !r.U64(t.stream_offset)) {
            return bad("tensor offsets");
        }
        if (!r.U32(t.transform_mask)) return bad("tensor transform mask");
        if (!r.Raw(t.digest, 32)) return bad("tensor digest");
        if (t.block_size == 0 || t.type_size == 0) return bad("tensor block geometry");
        if (t.row_elems == 0 || t.row_elems % t.block_size != 0) return bad("tensor row alignment");
        uint64_t rb = 0;
        if (!checked::MulU64(t.row_elems / t.block_size, t.type_size, rb)) return bad("row bytes overflow");
        if (rb != t.row_bytes) return bad("row bytes mismatch");
        uint64_t tb = 0;
        if (!checked::MulU64(t.n_rows, t.row_bytes, tb)) return bad("tensor bytes overflow");
        if (tb != t.total_bytes) return bad("tensor byte size mismatch");
        uint64_t ne = 0;
        if (!checked::MulU64(t.n_rows, t.row_elems, ne)) return bad("element overflow");
        if (ne != t.n_elems) return bad("element count mismatch");
        m.tensors.push_back(std::move(t));
    }
    uint64_t nw = 0;
    if (!r.U64(nw) || nw > 4096) return bad("warning count");
    for (uint64_t i = 0; i < nw; i++) {
        std::string s;
        if (!r.Str(s, 4096)) return bad("warning");
        m.warnings.push_back(std::move(s));
    }
    uint32_t sentinel = 0;
    if (!r.U32(sentinel) || sentinel != 0xA11CE001u) return bad("missing terminator");
    if (!r.Eof()) return bad("trailing data");
    out = std::move(m);
    return true;
}

WeightLayout Manifest::ToLayout() const {
    WeightLayout l;
    l.storage_type = storage_type;
    l.total_plain_bytes = weights_plain_bytes;
    l.slots.reserve(tensors.size());
    for (const auto& t : tensors) {
        TensorSlot s;
        s.slot_id = t.slot_id;
        s.name = t.name;
        s.role = static_cast<TensorRole::Kind>(t.role);
        s.layer = t.layer;
        s.type_id = t.type_id;
        s.dims = t.dims;
        s.n_dims = t.n_dims;
        s.n_elems = t.n_elems;
        s.n_rows = t.n_rows;
        s.row_elems = t.row_elems;
        s.block_size = t.block_size;
        s.type_size = t.type_size;
        s.row_bytes = t.row_bytes;
        s.total_bytes = t.total_bytes;
        s.dst_offset = t.stream_offset;
        s.dst_size = t.total_bytes;
        s.transform_mask = t.transform_mask;
        memcpy(s.digest, t.digest, 32);
        s.present = true;
        l.index.emplace(s.name, s.slot_id);
        l.slots.push_back(std::move(s));
    }
    return l;
}

const TensorSlot* WeightLayout::Find(const std::string& name) const {
    auto it = index.find(name);
    if (it == index.end()) return nullptr;
    return FindBySlot(it->second);
}

const TensorSlot* WeightLayout::FindBySlot(uint32_t id) const {
    for (const auto& s : slots) {
        if (s.slot_id == id) return &s;
    }
    return nullptr;
}

namespace vocabcodec {

constexpr uint32_t kVocabMagic = 0x424F4341;
constexpr uint32_t kVocabVersion = 1;

std::vector<uint8_t> Serialize(const VocabData& v) {
    ByteWriter w;
    w.U32(kVocabMagic);
    w.U32(kVocabVersion);
    w.Str(v.model);
    w.Str(v.pre);
    w.I32(v.bos);
    w.I32(v.eos);
    w.I32(v.pad);
    w.I32(v.unk);
    w.U32(v.add_bos ? 1u : 0u);
    w.U32(v.add_eos ? 1u : 0u);
    w.U64(v.tokens.size());
    for (const auto& t : v.tokens) w.Str(t);
    w.U64(v.scores.size());
    for (float s : v.scores) w.F32(s);
    w.U64(v.types.size());
    for (int32_t t : v.types) w.I32(t);
    w.U64(v.merges.size());
    for (const auto& m : v.merges) w.Str(m);
    w.U32(0xB0CA1234u);
    return w.Take();
}

bool Deserialize(std::span<const uint8_t> data, VocabData& out, std::string& err) {
    ByteReader r(data);
    uint32_t magic = 0, version = 0;
    if (!r.U32(magic) || !r.U32(version)) { err = "truncated vocabulary record"; return false; }
    if (magic != kVocabMagic) { err = "vocabulary record has an invalid magic"; return false; }
    if (version != kVocabVersion) {
        err = FormatErrorF("vocabulary record version %u is not supported", version);
        return false;
    }
    VocabData v;
    if (!r.Str(v.model, 64)) { err = "bad tokenizer model"; return false; }
    if (!r.Str(v.pre, 64)) { err = "bad tokenizer pre"; return false; }
    if (!r.I32(v.bos) || !r.I32(v.eos) || !r.I32(v.pad) || !r.I32(v.unk)) {
        err = "bad special token ids";
        return false;
    }
    uint32_t f = 0;
    if (!r.U32(f)) { err = "bad add_bos"; return false; }
    v.add_bos = f != 0;
    if (!r.U32(f)) { err = "bad add_eos"; return false; }
    v.add_eos = f != 0;
    uint64_t n = 0;
    if (!r.U64(n) || n > (4u << 20)) { err = "bad token count"; return false; }
    v.tokens.reserve(static_cast<size_t>(std::min<uint64_t>(n, 1u << 20)));
    for (uint64_t i = 0; i < n; i++) {
        std::string s;
        if (!r.Str(s, 4096)) { err = "bad token string"; return false; }
        v.tokens.push_back(std::move(s));
    }
    if (!r.U64(n) || n > (4u << 20)) { err = "bad score count"; return false; }
    for (uint64_t i = 0; i < n; i++) {
        float s = 0;
        if (!r.F32(s)) { err = "bad score"; return false; }
        v.scores.push_back(s);
    }
    if (!r.U64(n) || n > (4u << 20)) { err = "bad type count"; return false; }
    for (uint64_t i = 0; i < n; i++) {
        int32_t t = 0;
        if (!r.I32(t)) { err = "bad token type"; return false; }
        v.types.push_back(t);
    }
    if (!r.U64(n) || n > (8u << 20)) { err = "bad merge count"; return false; }
    v.merges.reserve(static_cast<size_t>(std::min<uint64_t>(n, 1u << 20)));
    for (uint64_t i = 0; i < n; i++) {
        std::string s;
        if (!r.Str(s, 4096)) { err = "bad merge string"; return false; }
        v.merges.push_back(std::move(s));
    }
    uint32_t sentinel = 0;
    if (!r.U32(sentinel) || sentinel != 0xB0CA1234u) { err = "vocabulary record is truncated"; return false; }
    if (!r.Eof()) { err = "vocabulary record has trailing data"; return false; }
    out = std::move(v);
    return true;
}

}

const SectionEntry* ContainerReader::FindSection(const std::vector<SectionEntry>& s, SectionPurpose p) {
    for (const auto& e : s) {
        if (e.purpose == static_cast<uint32_t>(p)) return &e;
    }
    return nullptr;
}

ContainerReader::OpenResult ContainerReader::OpenHeader(const std::string& path, FileReader& fr,
                                                        std::string& err) {
    OpenResult res;
    err.clear();
    if (fr.Size() < kHeaderSize) {
        err = FormatErrorF("'%s' is %llu bytes which is smaller than the %u byte AIProtect header",
                           path.c_str(), static_cast<unsigned long long>(fr.Size()), kHeaderSize);
        return res;
    }
    if (!fr.ReadAt(0, &res.header, sizeof(ContainerHeader))) {
        err = "failed to read the AIProtect header";
        return res;
    }
    if (res.header.magic_a != kContainerMagicA || res.header.magic_b != kContainerMagicB) {
        uint8_t m[4];
        memcpy(m, &res.header.magic_a, 4);
        if (m[0] == 'G' && m[1] == 'G' && m[2] == 'U' && m[3] == 'F') {
            err = "this is a plain GGUF file, not an AIProtect container; run the protect command first";
        } else {
            err = FormatErrorF("'%s' does not carry the AIProtect container magic (found %02x %02x %02x %02x)",
                               path.c_str(), m[0], m[1], m[2], m[3]);
        }
        return res;
    }
    if (res.header.header_size != kHeaderSize) {
        err = FormatErrorF("AIProtect header size %u does not match this build (%u)", res.header.header_size,
                           kHeaderSize);
        return res;
    }
    if (res.header.format_version < kMinContainerVersion || res.header.format_version > kContainerVersion) {
        err = FormatErrorF("AIProtect container format version %u is not supported by this build "
                           "(supported: %u..%u)",
                           res.header.format_version, kMinContainerVersion, kContainerVersion);
        return res;
    }
    if (res.header.file_size != 0 && res.header.file_size != fr.Size()) {
        err = FormatErrorF("the container declares %llu bytes but the file holds %llu bytes",
                           static_cast<unsigned long long>(res.header.file_size),
                           static_cast<unsigned long long>(fr.Size()));
        return res;
    }
    if (res.header.kdf_alg != 1) {
        err = FormatErrorF("unsupported key derivation algorithm id %u", res.header.kdf_alg);
        return res;
    }
    if (res.header.kdf_opslimit == 0 || res.header.kdf_opslimit > 1000) {
        err = FormatErrorF("the container header declares an Argon2id opslimit of %llu which is outside the "
                           "supported range 1..1000",
                           static_cast<unsigned long long>(res.header.kdf_opslimit));
        return res;
    }
    if (res.header.kdf_memlimit < 8192 || res.header.kdf_memlimit > (4ull << 20)) {
        err = FormatErrorF("the container header declares an Argon2id memory limit of %llu KiB which is outside the "
                           "supported range 8192..4194304 KiB",
                           static_cast<unsigned long long>(res.header.kdf_memlimit));
        return res;
    }
    if (res.header.cipher_alg != 1) {
        err = FormatErrorF("unsupported cipher suite id %u", res.header.cipher_alg);
        return res;
    }
    if (res.header.chunk_plain == 0 || res.header.chunk_plain > (64u << 20) ||
        (res.header.chunk_plain & (res.header.chunk_plain - 1)) != 0) {
        err = FormatErrorF("invalid chunk size %u in the container header", res.header.chunk_plain);
        return res;
    }
    if (res.header.section_count == 0 || res.header.section_count > 64) {
        err = FormatErrorF("invalid section count %llu", static_cast<unsigned long long>(res.header.section_count));
        return res;
    }
    uint64_t table_bytes = 0;
    if (!checked::MulU64(res.header.section_count, kSectionEntrySize, table_bytes)) {
        err = "section table size overflows";
        return res;
    }
    if (res.header.section_table_size != table_bytes) {
        err = FormatErrorF("section table size %llu does not match section count %llu",
                           static_cast<unsigned long long>(res.header.section_table_size),
                           static_cast<unsigned long long>(res.header.section_count));
        return res;
    }
    uint64_t table_end = 0;
    if (!checked::AddU64(res.header.section_table_offset, table_bytes, table_end)) {
        err = "section table offset overflows";
        return res;
    }
    if (res.header.section_table_offset < kHeaderSize || table_end > fr.Size()) {
        err = FormatErrorF("the section table at offset %llu (size %llu) lies outside the file",
                           static_cast<unsigned long long>(res.header.section_table_offset),
                           static_cast<unsigned long long>(table_bytes));
        return res;
    }
    res.sections.resize(static_cast<size_t>(res.header.section_count));
    if (!fr.ReadAt(res.header.section_table_offset, res.sections.data(), static_cast<size_t>(table_bytes))) {
        err = "failed to read the section table";
        res.sections.clear();
        return res;
    }
    for (size_t i = 0; i < res.sections.size(); i++) {
        const SectionEntry& se = res.sections[i];
        if (se.purpose < static_cast<uint32_t>(SectionPurpose::kManifest) ||
            se.purpose > static_cast<uint32_t>(SectionPurpose::kVocab)) {
            err = FormatErrorF("section %zu declares an unknown purpose id %u", i, se.purpose);
            return res;
        }
        if (se.chunk_plain == 0 || se.chunk_plain > (64u << 20)) {
            err = FormatErrorF("section %zu has an invalid plaintext chunk size %u", i, se.chunk_plain);
            return res;
        }
        if (se.chunk_stored != se.chunk_plain + BlockCipher::kTagBytes) {
            err = FormatErrorF("section %zu has an inconsistent stored chunk size (%u vs %u + tag)", i,
                               se.chunk_stored, se.chunk_plain);
            return res;
        }
        uint64_t expect_chunks = (se.plain_size + se.chunk_plain - 1) / se.chunk_plain;
        if (se.plain_size == 0) expect_chunks = 0;
        if (se.chunk_count != expect_chunks) {
            err = FormatErrorF("section %zu declares %llu chunks but %llu are implied by its size", i,
                               static_cast<unsigned long long>(se.chunk_count),
                               static_cast<unsigned long long>(expect_chunks));
            return res;
        }
        uint64_t full_chunks = se.plain_size / se.chunk_plain;
        uint64_t tail_plain = se.plain_size % se.chunk_plain;
        uint64_t tail_stored = (tail_plain == 0) ? 0 : tail_plain + BlockCipher::kTagBytes;
        uint64_t stored_bytes = 0;
        if (!checked::MulAddU64(full_chunks, se.chunk_stored, tail_stored, stored_bytes)) {
            err = FormatErrorF("section %zu stored size overflows", i);
            return res;
        }
        if (stored_bytes != se.stored_size) {
            err = FormatErrorF("section %zu stored size %llu does not match its chunk count", i,
                               static_cast<unsigned long long>(se.stored_size));
            return res;
        }
        uint64_t end = 0;
        if (!checked::AddU64(se.data_offset, stored_bytes, end)) {
            err = FormatErrorF("section %zu range overflows", i);
            return res;
        }
        if (se.data_offset < table_end || end > fr.Size()) {
            err = FormatErrorF("section %zu data range [%llu, %llu) lies outside the file", i,
                               static_cast<unsigned long long>(se.data_offset),
                               static_cast<unsigned long long>(end));
            return res;
        }
        if (se.key_slot < 1 || se.key_slot > 5) {
            err = FormatErrorF("section %zu references an unknown key slot %u", i, se.key_slot);
            return res;
        }
    }
    for (size_t i = 0; i < res.sections.size(); i++) {
        for (size_t j = i + 1; j < res.sections.size(); j++) {
            const SectionEntry& a = res.sections[i];
            const SectionEntry& b = res.sections[j];
            if (a.purpose == b.purpose) {
                err = FormatErrorF("the container holds two sections with purpose %s",
                                   SectionPurposeName(static_cast<SectionPurpose>(a.purpose)));
                return res;
            }
            uint64_t a_end = a.data_offset + a.stored_size;
            uint64_t b_end = b.data_offset + b.stored_size;
            if (a.data_offset < b_end && b.data_offset < a_end) {
                err = FormatErrorF("sections %zu and %zu overlap in the file", i, j);
                return res;
            }
        }
    }
    res.header_ok = true;
    return res;
}

bool ContainerReader::VerifyHeaderMac(const ContainerHeader& h, const std::vector<SectionEntry>& s,
                                      std::span<const uint8_t> integrity_key) {
    KeyedHash mac(integrity_key);
    mac.Update(&h, offsetof(ContainerHeader, header_mac));
    mac.Update(s.data(), s.size() * sizeof(SectionEntry));
    uint8_t computed[32];
    mac.Final(computed);
    return sodium_memcmp(computed, h.header_mac, 32) == 0;
}

bool ContainerReader::ReadSection(FileReader& fr, const ContainerHeader& h, const SectionEntry& se,
                                  std::span<const uint8_t> key, std::span<const uint8_t, 16> container_id,
                                  SecureBytes& out, std::string& err) {
    if (key.size() != BlockCipher::kKeyBytes) {
        err = "wrong key length for section decryption";
        return false;
    }
    if (se.plain_size > (2ull << 30)) {
        err = FormatErrorF("section of %llu plaintext bytes is too large to materialise in memory",
                           static_cast<unsigned long long>(se.plain_size));
        return false;
    }
    out.Clear();
    out.resize(static_cast<size_t>(se.plain_size));
    std::vector<uint8_t> cipher(static_cast<size_t>(se.chunk_stored));
    std::array<uint8_t, 40> aad{};
    for (uint64_t i = 0; i < se.chunk_count; i++) {
        uint64_t file_off = 0;
        if (!checked::MulAddU64(i, se.chunk_stored, se.data_offset, file_off)) {
            err = "chunk offset overflow";
            out.Clear();
            return false;
        }
        uint64_t plain_off = i * se.chunk_plain;
        uint64_t plain_len = std::min<uint64_t>(se.chunk_plain, se.plain_size - plain_off);
        size_t stored_len = static_cast<size_t>(plain_len + BlockCipher::kTagBytes);
        if (!fr.ReadAt(file_off, cipher.data(), stored_len)) {
            err = FormatErrorF("failed to read chunk %llu of section %u", static_cast<unsigned long long>(i),
                               se.section_id);
            out.Clear();
            return false;
        }
        std::array<uint8_t, BlockCipher::kNonceBytes> nonce{};
        BlockCipher::BuildNonce(nonce, std::span<const uint8_t, 8>(se.nonce_prefix, 8), se.section_id, i);
        BuildChunkAad(container_id, se.section_id, se.purpose, i, plain_len, aad);
        size_t got = 0;
        if (!BlockCipher::Decrypt(key, nonce, std::span<const uint8_t>(aad.data(), aad.size()),
                                  std::span<const uint8_t>(cipher.data(), stored_len),
                                  out.data() + plain_off, static_cast<size_t>(plain_len), got)) {
            err = FormatErrorF("authentication of chunk %llu in section %u (%s) failed; the container was "
                               "modified, truncated, or the password is wrong",
                               static_cast<unsigned long long>(i), se.section_id,
                               SectionPurposeName(static_cast<SectionPurpose>(se.purpose)));
            out.Clear();
            sodium_memzero(cipher.data(), cipher.size());
            return false;
        }
        if (got != static_cast<size_t>(plain_len)) {
            err = FormatErrorF("chunk %llu decrypted to an unexpected length", static_cast<unsigned long long>(i));
            out.Clear();
            return false;
        }
    }
    uint8_t computed[32];
    KeyedHash::Plain(out.Span(), computed);
    if (sodium_memcmp(computed, se.digest, 32) != 0) {
        err = FormatErrorF("the decrypted %s section does not match its recorded digest",
                           SectionPurposeName(static_cast<SectionPurpose>(se.purpose)));
        out.Clear();
        return false;
    }
    (void)h;
    return true;
}

}
namespace aip {

static void FlipHalfSign(uint8_t* p) {
    uint16_t v;
    memcpy(&v, p, 2);
    v = static_cast<uint16_t>(v ^ 0x8000u);
    memcpy(p, &v, 2);
}

static void FlipFloatSign(uint8_t* p) {
    uint32_t v;
    memcpy(&v, p, 4);
    v ^= 0x80000000u;
    memcpy(p, &v, 4);
}

static bool NegateBlockScales(uint32_t type_id, uint8_t* block, uint32_t block_size, uint32_t type_size) {
    switch (type_id) {
        case 0:
            for (uint32_t i = 0; i < block_size; i++) FlipFloatSign(block + i * 4);
            return true;
        case 1:
        case 30:
            for (uint32_t i = 0; i < block_size; i++) FlipHalfSign(block + i * 2);
            return true;
        case 2:
        case 6:
        case 8:
        case 20:
            FlipHalfSign(block);
            return true;
        case 3:
        case 7:
            FlipHalfSign(block);
            FlipHalfSign(block + 2);
            return true;
        case 12:
        case 13:
            FlipHalfSign(block);
            FlipHalfSign(block + 2);
            return true;
        case 23:
            FlipHalfSign(block);
            return true;
        case 10:
            if (type_size < 84) return false;
            FlipHalfSign(block + 80);
            FlipHalfSign(block + 82);
            return true;
        case 11:
            if (type_size < 110) return false;
            FlipHalfSign(block + 108);
            return true;
        case 14:
            if (type_size < 210) return false;
            FlipHalfSign(block + 208);
            return true;
        case 15:
            FlipFloatSign(block);
            return true;
        default:
            return false;
    }
}

struct RoleSides {
    uint32_t residual;
    uint32_t ffn;
    uint32_t head;
    uint32_t vocab;
};

static RoleSides SidesForRole(TensorRole::Kind role) {
    RoleSides s{0, 0, 0, 0};
    switch (role) {
        case TensorRole::kTokenEmbd:
            s.residual = kTfResidualCol;
            s.vocab = kTfVocabRow;
            break;
        case TensorRole::kOutputWeight:
            s.residual = kTfResidualCol;
            s.vocab = kTfVocabRow;
            break;
        case TensorRole::kOutputNorm:
        case TensorRole::kAttnNorm:
        case TensorRole::kFfnNorm:
            s.residual = kTfResidualColUnsigned;
            break;
        case TensorRole::kAttnQ:
            s.residual = kTfResidualCol;
            s.head = kTfHeadRowQ;
            break;
        case TensorRole::kAttnK:
        case TensorRole::kAttnV:
            s.residual = kTfResidualCol;
            s.head = kTfHeadRowKv;
            break;
        case TensorRole::kAttnQBias:
            s.head = kTfHeadColQ;
            break;
        case TensorRole::kAttnKBias:
        case TensorRole::kAttnVBias:
            s.head = kTfHeadColKv;
            break;
        case TensorRole::kAttnOut:
            s.residual = kTfResidualRow;
            s.head = kTfHeadColQ;
            break;
        case TensorRole::kFfnGate:
        case TensorRole::kFfnUp:
            s.residual = kTfResidualCol;
            s.ffn = kTfFfnRow;
            break;
        case TensorRole::kFfnDown:
            s.residual = kTfResidualRow;
            s.ffn = kTfFfnCol;
            break;
        default:
            break;
    }
    return s;
}

uint64_t WeightTransformEngine::TransformMaskFor(const TensorSlot& s, const TransformPlan& plan) {
    RoleSides sides = SidesForRole(s.role);
    uint32_t mask = 0;
    if (plan.residual.enabled) mask |= sides.residual;
    if (plan.ffn.enabled) mask |= sides.ffn;
    if (plan.head.enabled) mask |= sides.head;
    if (plan.vocab.enabled) mask |= sides.vocab;
    return mask;
}

static bool AxisApplies(const AxisPlan& ax, uint32_t length, uint32_t& granularity) {
    if (!ax.enabled) return false;
    if (ax.length != length) return false;
    granularity = ax.granularity;
    return true;
}

static uint32_t GroupOf(uint64_t index, uint32_t granularity) {
    return static_cast<uint32_t>(index / granularity);
}

static uint32_t MapIndex(const AxisPlan& ax, uint64_t dst_index, bool signed_axis, int8_t* sign_out) {
    if (sign_out) *sign_out = 1;
    if (!ax.enabled || ax.perm.empty()) return static_cast<uint32_t>(dst_index);
    uint32_t g = GroupOf(dst_index, ax.granularity);
    if (g >= ax.group_count) return static_cast<uint32_t>(dst_index);
    uint32_t src_group = ax.perm[g];
    uint32_t within = static_cast<uint32_t>(dst_index) % ax.granularity;
    if (signed_axis && !ax.signs.empty() && g < ax.signs.size()) {
        if (sign_out) *sign_out = ax.signs[g];
    }
    return src_group * ax.granularity + within;
}

uint64_t WeightTransformEngine::MapRow(const TensorSlot& s, const TransformPlan& plan, uint64_t dst_row) {
    uint64_t src = dst_row;
    if (s.transform_mask & kTfVocabRow) {
        uint32_t gran = 1;
        if (AxisApplies(plan.vocab, static_cast<uint32_t>(s.n_rows), gran)) {
            src = MapIndex(plan.vocab, src, false, nullptr);
        }
    }
    if (s.transform_mask & kTfResidualRow) {
        uint32_t gran = 1;
        if (AxisApplies(plan.residual, static_cast<uint32_t>(s.n_rows), gran)) {
            src = MapIndex(plan.residual, src, false, nullptr);
        }
    }
    if (s.transform_mask & kTfFfnRow) {
        uint32_t gran = 1;
        if (AxisApplies(plan.ffn, static_cast<uint32_t>(s.n_rows), gran)) {
            src = MapIndex(plan.ffn, src, false, nullptr);
        }
    }
    if (s.transform_mask & kTfHeadRowQ) {
        if (plan.head.enabled && !plan.head.perm.empty()) {
            uint32_t hd = plan.head.granularity;
            uint32_t h = static_cast<uint32_t>(src / hd);
            uint32_t d = static_cast<uint32_t>(src % hd);
            if (h < plan.head.length) src = static_cast<uint64_t>(plan.head.perm[h]) * hd + d;
        }
    }
    if (s.transform_mask & kTfHeadRowKv) {
        if (plan.head.enabled && !plan.head.kv_perm.empty() && plan.head.kv_groups > 0) {
            uint32_t hd = plan.head.granularity;
            uint32_t g = static_cast<uint32_t>(src / hd);
            uint32_t rem = static_cast<uint32_t>(src % hd);
            if (g < plan.head.kv_groups && g < plan.head.kv_perm.size()) {
                src = static_cast<uint64_t>(plan.head.kv_perm[g]) * hd + rem;
            }
        }
    }
    return src;
}

int8_t WeightTransformEngine::RowSign(const TensorSlot& s, const TransformPlan& plan, uint64_t dst_row) {
    if (!(s.transform_mask & kTfResidualRow)) return 1;
    if (!plan.residual.enabled || !plan.residual.signed_perm) return 1;
    uint32_t g = GroupOf(dst_row, plan.residual.granularity);
    if (g >= plan.residual.signs.size()) return 1;
    return plan.residual.signs[g];
}

static void ApplyColumnAxis(const TensorSlot& s, const AxisPlan& ax, bool signed_axis, const uint8_t* src,
                            uint8_t* dst) {
    uint32_t G = ax.granularity;
    uint32_t B = s.block_size;
    uint32_t S = s.type_size;
    if (G == 0 || B == 0 || G % B != 0) return;
    uint32_t blocks_per_group = G / B;
    uint64_t run = static_cast<uint64_t>(blocks_per_group) * S;
    uint32_t groups = static_cast<uint32_t>(s.row_elems / G);
    for (uint32_t g = 0; g < groups; g++) {
        uint32_t sg = ax.perm[g];
        if (sg >= groups) sg = g;
        memcpy(dst + g * run, src + sg * run, static_cast<size_t>(run));
        if (signed_axis && ax.signed_perm && g < ax.signs.size() && ax.signs[g] < 0) {
            for (uint32_t b = 0; b < blocks_per_group; b++) {
                NegateBlockScales(s.type_id, dst + g * run + static_cast<uint64_t>(b) * S, B, S);
            }
        }
    }
}

static void ApplyHeadColumnAxis(const TensorSlot& s, const AxisPlan& ax, bool kv_side, const uint8_t* src,
                                uint8_t* dst) {
    uint32_t hd = ax.granularity;
    uint32_t B = s.block_size;
    uint32_t S = s.type_size;
    if (hd == 0 || B == 0 || hd % B != 0) return;
    uint32_t blocks_per_head = hd / B;
    uint64_t run = static_cast<uint64_t>(blocks_per_head) * S;
    uint32_t heads = static_cast<uint32_t>(s.row_elems / hd);
    const std::vector<uint32_t>& perm = kv_side ? ax.kv_perm : ax.perm;
    uint32_t plen = kv_side ? ax.kv_groups : ax.length;
    for (uint32_t h = 0; h < heads && h < plen; h++) {
        uint32_t sh = perm[h];
        if (sh >= plen) sh = h;
        memcpy(dst + h * run, src + sh * run, static_cast<size_t>(run));
    }
}

void WeightTransformEngine::ElementMap(const AxisPlan& ax, bool signed_axis, std::vector<uint32_t>& idx,
                                      std::vector<int8_t>& sign) {
    idx.assign(ax.length, 0);
    sign.assign(ax.length, 1);
    if (!ax.enabled) {
        for (uint32_t i = 0; i < ax.length; i++) idx[i] = i;
        return;
    }
    for (uint32_t i = 0; i < ax.length; i++) {
        idx[i] = MapIndex(ax, i, signed_axis, &sign[i]);
    }
}

void WeightTransformEngine::TransformRowBytes(const TensorSlot& s, const TransformPlan& plan, uint64_t dst_row,
                                              const uint8_t* src, uint8_t* dst) {
    bool use_res = false, use_ffn = false, use_head_q = false, use_head_kv = false;
    bool res_signed = (s.transform_mask & kTfResidualColUnsigned) == 0;
    uint32_t gran = 0;
    if (s.transform_mask & (kTfResidualCol | kTfResidualColUnsigned)) {
        use_res = AxisApplies(plan.residual, static_cast<uint32_t>(s.row_elems), gran) &&
                  plan.residual.granularity % s.block_size == 0;
    }
    if (s.transform_mask & kTfFfnCol) {
        use_ffn = AxisApplies(plan.ffn, static_cast<uint32_t>(s.row_elems), gran) &&
                  plan.ffn.granularity % s.block_size == 0;
    }
    if (s.transform_mask & kTfHeadColQ) {
        use_head_q = plan.head.enabled && plan.head.granularity > 0 &&
                     s.row_elems % plan.head.granularity == 0 &&
                     plan.head.granularity % s.block_size == 0 &&
                     s.row_elems / plan.head.granularity == plan.head.length;
    }
    if (s.transform_mask & kTfHeadColKv) {
        use_head_kv = plan.head.enabled && plan.head.granularity > 0 &&
                      s.row_elems % plan.head.granularity == 0 &&
                      plan.head.granularity % s.block_size == 0 && plan.head.kv_groups > 0 &&
                      s.row_elems / plan.head.granularity == plan.head.kv_groups;
    }
    int ops = (use_res ? 1 : 0) + (use_ffn ? 1 : 0) + (use_head_q ? 1 : 0) + (use_head_kv ? 1 : 0);
    const uint8_t* cur = src;
    if (ops == 0) {
        if (dst != src) memcpy(dst, src, static_cast<size_t>(s.row_bytes));
    } else if (ops == 1) {
        if (use_res) ApplyColumnAxis(s, plan.residual, res_signed, src, dst);
        else if (use_ffn) ApplyColumnAxis(s, plan.ffn, false, src, dst);
        else if (use_head_q) ApplyHeadColumnAxis(s, plan.head, false, src, dst);
        else ApplyHeadColumnAxis(s, plan.head, true, src, dst);
    } else {
        std::vector<uint8_t> buf_a(static_cast<size_t>(s.row_bytes));
        std::vector<uint8_t> buf_b(static_cast<size_t>(s.row_bytes));
        uint8_t* out = buf_a.data();
        if (use_res) {
            ApplyColumnAxis(s, plan.residual, res_signed, cur, out);
            cur = out;
            out = buf_b.data();
        }
        if (use_ffn) {
            ApplyColumnAxis(s, plan.ffn, false, cur, out);
            cur = out;
            out = (out == buf_a.data()) ? buf_b.data() : buf_a.data();
        }
        if (use_head_q) {
            ApplyHeadColumnAxis(s, plan.head, false, cur, out);
            cur = out;
            out = (out == buf_a.data()) ? buf_b.data() : buf_a.data();
        }
        if (use_head_kv) {
            ApplyHeadColumnAxis(s, plan.head, true, cur, out);
            cur = out;
        }
        memcpy(dst, cur, static_cast<size_t>(s.row_bytes));
    }
    int8_t sign = RowSign(s, plan, dst_row);
    if (sign < 0) {
        uint64_t blocks = s.row_bytes / s.type_size;
        for (uint64_t b = 0; b < blocks; b++) {
            if (!NegateBlockScales(s.type_id, dst + b * s.type_size, s.block_size, s.type_size)) {
                ThrowErrorF(ErrClass::kUnsupported,
                            "tensor %s uses a storage format whose block scale cannot be negated exactly, so the "
                            "signed residual permutation is not safe for it",
                            s.name.c_str());
            }
        }
    }
}

static double Log2Factorial(uint64_t n) {
    double r = 0.0;
    for (uint64_t i = 2; i <= n; i++) r += std::log2(static_cast<double>(i));
    return r;
}

static void AppendRejectionNotes(TransformPlan& plan) {
    const char* names[] = {"residual", "feed forward", "attention head", "vocabulary"};
    const AxisPlan* axes[] = {&plan.residual, &plan.ffn, &plan.head, &plan.vocab};
    for (int i = 0; i < 4; i++) {
        if (!axes[i]->enabled && !axes[i]->reject_reason.empty()) {
            plan.notes.push_back(std::string(names[i]) + " axis not applied: " + axes[i]->reject_reason);
        }
    }
}

TransformPlan WeightTransformEngine::Plan(const ModelSpec& spec, const WeightLayout& layout, bool want_transform) {
    TransformPlan plan;
    plan.residual.axis = TransformAxis::kResidual;
    plan.residual.length = spec.n_embd;
    plan.ffn.axis = TransformAxis::kFfn;
    plan.ffn.length = spec.n_ff;
    plan.head.axis = TransformAxis::kHead;
    plan.head.length = spec.n_head;
    plan.head.granularity = spec.head_dim;
    plan.head.kv_groups = spec.n_head_kv;
    plan.vocab.axis = TransformAxis::kVocab;
    plan.vocab.length = spec.n_vocab;
    plan.vocab.granularity = 1;

    if (!want_transform) {
        plan.residual.reject_reason = "disabled by --no-transform";
        plan.ffn.reject_reason = "disabled by --no-transform";
        plan.head.reject_reason = "disabled by --no-transform";
        plan.vocab.reject_reason = "disabled by --no-transform";
        plan.notes.push_back("weight transform disabled by request");
        return plan;
    }

    uint32_t g_res = 1;
    uint32_t g_ffn = 1;
    uint32_t head_col_kv_block = 1;
    bool have_res_col = false, have_res_row = false, have_ffn_col = false, have_ffn_row = false;
    bool have_head_row = false;
    bool have_vocab_row = false;
    const TensorSlot* attn_out = nullptr;
    const uint64_t qd = static_cast<uint64_t>(spec.n_head) * spec.head_dim;
    const uint64_t kd = static_cast<uint64_t>(spec.n_head_kv) * spec.head_dim;
    for (const auto& s : layout.slots) {
        RoleSides sides = SidesForRole(s.role);
        if (sides.residual == kTfResidualCol || sides.residual == kTfResidualColUnsigned) {
            have_res_col = true;
            if (s.row_elems != spec.n_embd) {
                plan.residual.reject_reason = "tensor '" + s.name + "' does not span the residual axis";
                g_res = 0;
                break;
            }
            g_res = std::max(g_res, s.block_size);
        }
        if (sides.residual == kTfResidualRow) {
            have_res_row = true;
            if (s.n_rows != spec.n_embd) {
                plan.residual.reject_reason = "tensor '" + s.name + "' does not span the residual axis";
                g_res = 0;
                break;
            }
        }
        if (sides.ffn == kTfFfnCol) {
            have_ffn_col = true;
            if (s.row_elems != spec.n_ff) {
                plan.ffn.reject_reason = "tensor '" + s.name + "' does not span the feed forward axis";
                g_ffn = 0;
                break;
            }
            g_ffn = std::max(g_ffn, s.block_size);
        }
        if (sides.ffn == kTfFfnRow) {
            have_ffn_row = true;
            if (s.n_rows != spec.n_ff) {
                plan.ffn.reject_reason = "tensor '" + s.name + "' does not span the feed forward axis";
                g_ffn = 0;
                break;
            }
        }
        if (sides.vocab == kTfVocabRow) {
            have_vocab_row = true;
            if (s.n_rows != spec.n_vocab) {
                plan.vocab.reject_reason = "tensor '" + s.name + "' does not span the vocabulary axis";
            }
        }
        if (sides.head == kTfHeadColQ) {
            attn_out = &s;
            if (s.row_elems != qd) plan.head.reject_reason = "tensor '" + s.name + "' does not span the head axis";
        }
        if (sides.head == kTfHeadColKv) {
            if (head_col_kv_block < s.block_size) head_col_kv_block = s.block_size;
            if (s.row_elems != kd) plan.head.reject_reason = "tensor '" + s.name + "' does not span the head axis";
        }
        if (sides.head == kTfHeadRowQ) {
            have_head_row = true;
            if (s.n_rows != qd) plan.head.reject_reason = "tensor '" + s.name + "' does not span the head axis";
        }
        if (sides.head == kTfHeadRowKv) {
            have_head_row = true;
            if (s.n_rows != kd) plan.head.reject_reason = "tensor '" + s.name + "' does not span the head axis";
        }
    }
    if (g_res == 0) {
        plan.ffn.reject_reason = "skipped because the residual axis was rejected";
        plan.head.reject_reason = "skipped because the residual axis was rejected";
        plan.vocab.reject_reason = "skipped because the residual axis was rejected";
        AppendRejectionNotes(plan);
        return plan;
    }
    if (g_ffn == 0) {
        plan.ffn.reject_reason = plan.ffn.reject_reason.empty() ? "feed forward axis rejected" : plan.ffn.reject_reason;
    }
    if (!plan.head.reject_reason.empty()) {
        plan.residual.reject_reason =
            plan.residual.reject_reason.empty() ? "skipped because the head axis was rejected" : plan.residual.reject_reason;
    }

    if (!have_res_col || !have_res_row) {
        plan.residual.reject_reason = "the model does not expose both sides of the residual axis";
    } else if (spec.n_embd % g_res != 0) {
        plan.residual.reject_reason = FormatErrorF(
            "residual axis length %u is not a multiple of %u, the coarsest quantization block among the "
            "tensors that store the residual stream contiguously; a block aligned permutation cannot be "
            "built without re-quantizing weights",
            spec.n_embd, g_res);
    } else {
        plan.residual.granularity = g_res;
        plan.residual.group_count = spec.n_embd / g_res;
        if (plan.residual.group_count < 2) {
            plan.residual.reject_reason = "the residual axis has fewer than two permutation groups";
        } else {
            plan.residual.enabled = true;
            plan.residual.signed_perm = true;
        }
    }

    if (!plan.ffn.reject_reason.empty()) {
        plan.ffn.enabled = false;
    } else if (!have_ffn_col || !have_ffn_row) {
        plan.ffn.reject_reason = "the model does not expose both sides of the feed forward axis";
    } else if (spec.n_ff % g_ffn != 0) {
        plan.ffn.reject_reason = FormatErrorF(
            "feed forward axis length %u is not a multiple of %u, the quantization block size of the tensor "
            "that consumes it",
            spec.n_ff, g_ffn);
    } else {
        plan.ffn.granularity = g_ffn;
        plan.ffn.group_count = spec.n_ff / g_ffn;
        if (plan.ffn.group_count < 2) {
            plan.ffn.reject_reason = "the feed forward axis has fewer than two permutation groups";
        } else {
            plan.ffn.enabled = true;
            plan.ffn.signed_perm = false;
        }
    }

    if (!attn_out) {
        plan.head.reject_reason = "no attention output tensor was found";
    } else if (!have_head_row) {
        plan.head.reject_reason = "the model does not expose the head row axis";
    } else if (!plan.head.reject_reason.empty()) {
    } else if (spec.head_dim == 0 || spec.head_dim % attn_out->block_size != 0 ||
               spec.head_dim % head_col_kv_block != 0) {
        plan.head.reject_reason = FormatErrorF(
            "head dimension %u is not a multiple of the %u element quantization block used by %s, so heads "
            "cannot be reordered without re-quantizing",
            spec.head_dim, attn_out->block_size, attn_out->name.c_str());
    } else if (spec.n_head < 2) {
        plan.head.reject_reason = "the model has a single attention head";
    } else {
        plan.head.enabled = true;
        plan.head.signed_perm = false;
        plan.head.group_count = spec.n_head;
    }

    if (!have_vocab_row) {
        plan.vocab.reject_reason = "the model does not expose the vocabulary axis";
    } else if (!plan.vocab.reject_reason.empty()) {
    } else if (spec.n_vocab < 2) {
        plan.vocab.reject_reason = "the vocabulary is too small to permute";
    } else {
        plan.vocab.enabled = true;
        plan.vocab.signed_perm = false;
        plan.vocab.granularity = 1;
        plan.vocab.group_count = spec.n_vocab;
    }

    AppendRejectionNotes(plan);
    plan.enabled = plan.residual.enabled || plan.ffn.enabled || plan.head.enabled || plan.vocab.enabled;
    if (!plan.enabled) {
        plan.notes.push_back("no safe weight transform could be constructed; weights are stored in the "
                             "original quantized representation, encrypted only");
        return plan;
    }

    auto make_perm = [](uint32_t n) {
        std::vector<uint32_t> p(n);
        for (uint32_t i = 0; i < n; i++) p[i] = i;
        random::Shuffle(p.data(), p.size());
        return p;
    };

    if (plan.residual.enabled) {
        plan.residual.perm = make_perm(plan.residual.group_count);
        plan.residual.signs.resize(plan.residual.group_count);
        uint32_t negative = 0;
        for (uint32_t i = 0; i < plan.residual.group_count; i++) {
            plan.residual.signs[i] = (random::Below(2) == 0) ? -1 : 1;
            if (plan.residual.signs[i] < 0) negative++;
        }
        if (negative == 0 || negative == plan.residual.group_count) {
            plan.residual.signs[random::Below(plan.residual.group_count)] =
                (negative == 0) ? static_cast<int8_t>(-1) : static_cast<int8_t>(1);
        }
        plan.key_space_bits += static_cast<uint64_t>(Log2Factorial(plan.residual.group_count));
        plan.key_space_bits += plan.residual.group_count;
        plan.notes.push_back(FormatErrorF(
            "residual axis: signed permutation over %u groups of %u channels", plan.residual.group_count,
            plan.residual.granularity));
    }
    if (plan.ffn.enabled) {
        plan.ffn.perm = make_perm(plan.ffn.group_count);
        plan.key_space_bits += static_cast<uint64_t>(Log2Factorial(plan.ffn.group_count));
        plan.notes.push_back(
            FormatErrorF("feed forward axis: permutation over %u groups of %u units", plan.ffn.group_count,
                         plan.ffn.granularity));
    }
    if (plan.head.enabled) {
        uint32_t n_rep = spec.n_head / spec.n_head_kv;
        std::vector<uint32_t> tau = make_perm(spec.n_head_kv);
        plan.head.kv_perm = tau;
        plan.head.perm.resize(spec.n_head);
        for (uint32_t g = 0; g < spec.n_head_kv; g++) {
            std::vector<uint32_t> inner = make_perm(n_rep);
            for (uint32_t r = 0; r < n_rep; r++) {
                plan.head.perm[g * n_rep + r] = tau[g] * n_rep + inner[r];
            }
        }
        double bits = Log2Factorial(spec.n_head_kv);
        for (uint32_t g = 0; g < spec.n_head_kv; g++) bits += Log2Factorial(n_rep);
        plan.key_space_bits += static_cast<uint64_t>(bits);
        plan.notes.push_back(FormatErrorF(
            "attention heads: permutation of %u key/value groups with %u query heads each", spec.n_head_kv,
            n_rep));
    }
    if (plan.vocab.enabled) {
        plan.vocab.perm = make_perm(spec.n_vocab);
        plan.key_space_bits += static_cast<uint64_t>(Log2Factorial(std::min<uint64_t>(spec.n_vocab, 4096)));
        plan.notes.push_back(FormatErrorF("vocabulary axis: permutation of %u embedding rows", spec.n_vocab));
    }
    return plan;
}

std::string TransformPlan::Describe() const {
    std::ostringstream os;
    if (!enabled) {
        os << "weight transform: DISABLED\n";
        if (!residual.reject_reason.empty()) os << "  residual axis : " << residual.reject_reason << "\n";
        if (!ffn.reject_reason.empty()) os << "  feed-forward  : " << ffn.reject_reason << "\n";
        if (!head.reject_reason.empty()) os << "  attention head: " << head.reject_reason << "\n";
        if (!vocab.reject_reason.empty()) os << "  vocabulary    : " << vocab.reject_reason << "\n";
        return os.str();
    }
    os << "weight transform: ENABLED (key space ~2^" << key_space_bits << ")\n";
    os << "  residual axis : " << (residual.enabled ? FormatErrorF("signed permutation, %u groups of %u",
                                                                   residual.group_count, residual.granularity)
                                                    : std::string("off"))
       << "\n";
    os << "  feed-forward  : " << (ffn.enabled ? FormatErrorF("permutation, %u groups of %u", ffn.group_count,
                                                              ffn.granularity)
                                              : std::string("off"))
       << "\n";
    os << "  attention head: "
       << (head.enabled ? FormatErrorF("permutation of %u heads", head.length) : std::string("off")) << "\n";
    os << "  vocabulary    : "
       << (vocab.enabled ? FormatErrorF("permutation of %u rows", vocab.length) : std::string("off")) << "\n";
    for (const auto& s : {&residual, &ffn, &head, &vocab}) {
        if (!s->enabled && !s->reject_reason.empty()) {
            os << "  note: " << s->reject_reason << "\n";
        }
    }
    return os.str();
}

}
namespace aip {

const char* VmOpName(VmOp op) {
    switch (op) {
        case VmOp::kNop: return "NOP";
        case VmOp::kHalt: return "HALT";
        case VmOp::kEmbedRow: return "EMBED_ROW";
        case VmOp::kScale: return "SCALE";
        case VmOp::kRmsNorm: return "RMS_NORM";
        case VmOp::kRmsNormNoGain: return "RMS_NORM_PLAIN";
        case VmOp::kMulMatVec: return "MUL_MAT_VEC";
        case VmOp::kAddWeightVec: return "ADD_WEIGHT_VEC";
        case VmOp::kMulWeightVec: return "MUL_WEIGHT_VEC";
        case VmOp::kRope: return "ROPE";
        case VmOp::kKvStore: return "KV_STORE";
        case VmOp::kAttention: return "ATTENTION";
        case VmOp::kAdd: return "ADD";
        case VmOp::kMul: return "MUL";
        case VmOp::kSwiGlu: return "SWI_GLU";
        case VmOp::kGeGlu: return "GE_GLU";
        case VmOp::kCopy: return "COPY";
        case VmOp::kLogits: return "LOGITS";
        case VmOp::kIntegrityProbe: return "RMP_PROBE";
        case VmOp::kAssertFinite: return "ASSERT_FINITE";
        default: return "INVALID";
    }
}

bool VmOpKnown(uint16_t v) {
    return v <= static_cast<uint16_t>(VmOp::kRmsNormNoGain);
}

const char* GraphOpName(GraphOp op) {
    switch (op) {
        case GraphOp::kInput: return "input";
        case GraphOp::kEmbed: return "embed";
        case GraphOp::kScale: return "scale";
        case GraphOp::kRmsNorm: return "rms_norm";
        case GraphOp::kMulMatVec: return "mul_mat_vec";
        case GraphOp::kAddWeightVec: return "add_weight_vec";
        case GraphOp::kRope: return "rope";
        case GraphOp::kKvStore: return "kv_store";
        case GraphOp::kAttention: return "attention";
        case GraphOp::kAdd: return "add";
        case GraphOp::kMul: return "mul";
        case GraphOp::kSwiGlu: return "swiglu";
        case GraphOp::kGeGlu: return "geglu";
        case GraphOp::kLogits: return "logits";
        case GraphOp::kOutput: return "output";
        case GraphOp::kIntegrityProbe: return "integrity_probe";
        default: return "?";
    }
}

uint32_t ModelGraph::Add(GraphNode n) {
    n.id = static_cast<uint32_t>(nodes.size());
    nodes.push_back(std::move(n));
    return n.id;
}

static std::string TensorNameFor(TensorRole::Kind role, int layer, bool bias) {
    std::string base;
    switch (role) {
        case TensorRole::kTokenEmbd: base = "token_embd.weight"; break;
        case TensorRole::kOutputWeight: base = "output.weight"; break;
        case TensorRole::kOutputNorm: base = "output_norm.weight"; break;
        case TensorRole::kAttnNorm: base = "blk.L.attn_norm.weight"; break;
        case TensorRole::kAttnQ: base = "blk.L.attn_q.weight"; break;
        case TensorRole::kAttnK: base = "blk.L.attn_k.weight"; break;
        case TensorRole::kAttnV: base = "blk.L.attn_v.weight"; break;
        case TensorRole::kAttnQBias: base = "blk.L.attn_q.bias"; break;
        case TensorRole::kAttnKBias: base = "blk.L.attn_k.bias"; break;
        case TensorRole::kAttnVBias: base = "blk.L.attn_v.bias"; break;
        case TensorRole::kAttnOut: base = "blk.L.attn_output.weight"; break;
        case TensorRole::kFfnNorm: base = "blk.L.ffn_norm.weight"; break;
        case TensorRole::kFfnGate: base = "blk.L.ffn_gate.weight"; break;
        case TensorRole::kFfnUp: base = "blk.L.ffn_up.weight"; break;
        case TensorRole::kFfnDown: base = "blk.L.ffn_down.weight"; break;
        default: return std::string();
    }
    (void)bias;
    if (layer >= 0) {
        size_t p = base.find('L');
        base.replace(p, 1, std::to_string(layer));
    }
    return base;
}

ModelGraph ModelGraph::BuildForArch(const ModelSpec& spec, const WeightLayout& layout) {
    ModelGraph g;
    auto need = [&](TensorRole::Kind role, int layer) -> const TensorSlot* {
        std::string name = TensorNameFor(role, layer, false);
        const TensorSlot* s = layout.Find(name);
        if (!s) {
            ThrowErrorF(ErrClass::kUnsupported,
                        "the graph for architecture '%s' requires tensor '%s' which is missing from the model",
                        spec.arch_name.c_str(), name.c_str());
        }
        return s;
    };
    auto mk = [&](GraphOp op, std::vector<uint32_t> inputs, uint32_t ne0, const char* name) {
        GraphNode n;
        n.op = op;
        n.inputs = std::move(inputs);
        n.ne0 = ne0;
        n.ne1 = 1;
        n.name = name ? name : "";
        return g.Add(n);
    };

    uint32_t token_in = mk(GraphOp::kInput, {}, 1, "token");
    uint32_t pos_in = mk(GraphOp::kInput, {}, 1, "position");
    g.input_node = token_in;
    g.nodes[pos_in].iparam = 1;

    const TensorSlot* embd = need(TensorRole::kTokenEmbd, -1);
    const TensorSlot* out_norm = need(TensorRole::kOutputNorm, -1);
    const TensorSlot* out_w = spec.tied_output ? embd : need(TensorRole::kOutputWeight, -1);

    uint32_t x = mk(GraphOp::kEmbed, {token_in}, spec.n_embd, "embed");
    g.nodes[x].weight = embd->name;
    if (spec.embd_scale != 0.0f && spec.embd_scale != 1.0f) {
        uint32_t xs = mk(GraphOp::kScale, {x}, spec.n_embd, "embd_scale");
        g.nodes[xs].fparam = spec.embd_scale;
        x = xs;
    }

    const uint32_t qd = spec.n_head * spec.head_dim;
    const uint32_t kd = spec.n_head_kv * spec.head_dim;

    for (uint32_t l = 0; l < spec.n_layer; l++) {
        int li = static_cast<int>(l);
        std::string tag = "l" + std::to_string(l) + ".";

        const TensorSlot* an = need(TensorRole::kAttnNorm, li);
        uint32_t n1 = mk(GraphOp::kRmsNorm, {x}, spec.n_embd, (tag + "attn_norm").c_str());
        g.nodes[n1].weight = an->name;
        g.nodes[n1].fparam = spec.norm_eps;
        g.nodes[n1].layer = l;

        const TensorSlot* wq = need(TensorRole::kAttnQ, li);
        const TensorSlot* wk = need(TensorRole::kAttnK, li);
        const TensorSlot* wv = need(TensorRole::kAttnV, li);
        uint32_t q = mk(GraphOp::kMulMatVec, {n1}, qd, (tag + "q").c_str());
        g.nodes[q].weight = wq->name;
        uint32_t k = mk(GraphOp::kMulMatVec, {n1}, kd, (tag + "k").c_str());
        g.nodes[k].weight = wk->name;
        uint32_t v = mk(GraphOp::kMulMatVec, {n1}, kd, (tag + "v").c_str());
        g.nodes[v].weight = wv->name;

        if (spec.has_qkv_bias) {
            const TensorSlot* bq = need(TensorRole::kAttnQBias, li);
            const TensorSlot* bk = need(TensorRole::kAttnKBias, li);
            const TensorSlot* bv = need(TensorRole::kAttnVBias, li);
            uint32_t qb = mk(GraphOp::kAddWeightVec, {q}, qd, (tag + "q_bias").c_str());
            g.nodes[qb].weight = bq->name;
            q = qb;
            uint32_t kb = mk(GraphOp::kAddWeightVec, {k}, kd, (tag + "k_bias").c_str());
            g.nodes[kb].weight = bk->name;
            k = kb;
            uint32_t vb = mk(GraphOp::kAddWeightVec, {v}, kd, (tag + "v_bias").c_str());
            g.nodes[vb].weight = bv->name;
            v = vb;
        }

        uint32_t qr = mk(GraphOp::kRope, {q, pos_in}, qd, (tag + "q_rope").c_str());
        g.nodes[qr].iparam = spec.n_rot;
        q = qr;
        uint32_t kr = mk(GraphOp::kRope, {k, pos_in}, kd, (tag + "k_rope").c_str());
        g.nodes[kr].iparam = spec.n_rot;
        k = kr;

        uint32_t ks = mk(GraphOp::kKvStore, {k, pos_in}, kd, (tag + "kv_k").c_str());
        g.nodes[ks].layer = l;
        g.nodes[ks].iparam = 1;
        uint32_t vs = mk(GraphOp::kKvStore, {v, pos_in}, kd, (tag + "kv_v").c_str());
        g.nodes[vs].layer = l;
        g.nodes[vs].iparam = 0;

        uint32_t att = mk(GraphOp::kAttention, {q, pos_in}, qd, (tag + "attn").c_str());
        g.nodes[att].layer = l;
        g.nodes[att].fparam = 1.0f / std::sqrt(static_cast<float>(spec.head_dim));
        if (spec.attn_softcap > 0.0f) g.nodes[att].iparam = 1;

        const TensorSlot* wo = need(TensorRole::kAttnOut, li);
        uint32_t ao = mk(GraphOp::kMulMatVec, {att}, spec.n_embd, (tag + "attn_out").c_str());
        g.nodes[ao].weight = wo->name;
        uint32_t xa = mk(GraphOp::kAdd, {x, ao}, spec.n_embd, (tag + "resid1").c_str());
        x = xa;

        const TensorSlot* fn = need(TensorRole::kFfnNorm, li);
        uint32_t n2 = mk(GraphOp::kRmsNorm, {x}, spec.n_embd, (tag + "ffn_norm").c_str());
        g.nodes[n2].weight = fn->name;
        g.nodes[n2].fparam = spec.norm_eps;
        g.nodes[n2].layer = l;

        const TensorSlot* wg = need(TensorRole::kFfnGate, li);
        const TensorSlot* wu = need(TensorRole::kFfnUp, li);
        const TensorSlot* wd = need(TensorRole::kFfnDown, li);
        uint32_t gate = mk(GraphOp::kMulMatVec, {n2}, spec.n_ff, (tag + "gate").c_str());
        g.nodes[gate].weight = wg->name;
        uint32_t up = mk(GraphOp::kMulMatVec, {n2}, spec.n_ff, (tag + "up").c_str());
        g.nodes[up].weight = wu->name;
        GraphOp glu = (spec.ffn == FfnKind::kGeGlu) ? GraphOp::kGeGlu : GraphOp::kSwiGlu;
        uint32_t h = mk(glu, {gate, up}, spec.n_ff, (tag + "act").c_str());
        uint32_t down = mk(GraphOp::kMulMatVec, {h}, spec.n_embd, (tag + "down").c_str());
        g.nodes[down].weight = wd->name;
        uint32_t xf = mk(GraphOp::kAdd, {x, down}, spec.n_embd, (tag + "resid2").c_str());
        x = xf;
    }

    uint32_t xn = mk(GraphOp::kRmsNorm, {x}, spec.n_embd, "output_norm");
    g.nodes[xn].weight = out_norm->name;
    g.nodes[xn].fparam = spec.norm_eps;

    uint32_t lg = mk(GraphOp::kLogits, {xn}, spec.n_vocab, "logits");
    g.nodes[lg].weight = out_w->name;
    g.logits_node = lg;

    if (spec.final_softcap > 0.0f) {
        GraphNode sc;
        sc.op = GraphOp::kScale;
        sc.inputs = {lg};
        sc.ne0 = spec.n_vocab;
        sc.fparam = spec.final_softcap;
        sc.iparam = 2;
        sc.name = "final_softcap";
        uint32_t id = g.Add(sc);
        g.logits_node = id;
    }
    GraphNode halt;
    halt.op = GraphOp::kOutput;
    halt.inputs = {g.logits_node};
    halt.ne0 = spec.n_vocab;
    halt.name = "halt";
    g.Add(halt);
    return g;
}

bool ModelGraph::Validate(std::string& err) const {
    if (nodes.empty()) {
        err = "the computation graph is empty";
        return false;
    }
    for (const auto& n : nodes) {
        for (uint32_t in : n.inputs) {
            if (in >= nodes.size()) {
                err = FormatErrorF("node %u references a non existing input node %u", n.id, in);
                return false;
            }
            if (in >= n.id) {
                err = FormatErrorF("node %u references node %u which is not defined earlier", n.id, in);
                return false;
            }
        }
        if (n.ne0 == 0 && n.op != GraphOp::kOutput) {
            err = FormatErrorF("node %u (%s) has a zero width output", n.id, GraphOpName(n.op));
            return false;
        }
    }
    return true;
}

std::vector<uint8_t> VmProgram::Serialize() const {
    ByteWriter w;
    VmProgramHeader h = header;
    w.Raw(&h, sizeof(h));
    w.Raw(code.data(), code.size() * sizeof(VmInstr));
    w.Raw(regs.data(), regs.size() * sizeof(VmRegDecl));
    w.Raw(slots.data(), slots.size() * sizeof(VmSlotRef));
    for (float c : consts) w.F32(c);
    return w.Take();
}

void VmProgram::ComputeDigest(uint8_t out[32]) const {
    VmProgram copy = *this;
    memset(copy.header.program_digest, 0, 32);
    std::vector<uint8_t> blob = copy.Serialize();
    KeyedHash::Plain(std::span<const uint8_t>(blob.data(), blob.size()), out);
}

VmProgram VmProgram::FromBlob(std::span<const uint8_t> blob) {
    VmProgram p;
    if (blob.size() < sizeof(VmProgramHeader)) {
        ThrowError(ErrClass::kFormat, "the bytecode section is smaller than a program header");
    }
    memcpy(&p.header, blob.data(), sizeof(VmProgramHeader));
    if (p.header.magic != kBytecodeMagic) {
        ThrowErrorF(ErrClass::kFormat, "bytecode magic mismatch (found 0x%08x, expected 0x%08x)", p.header.magic,
                    kBytecodeMagic);
    }
    if (p.header.version != kBytecodeVersion) {
        ThrowErrorF(ErrClass::kFormat, "bytecode version %u is not supported by this build (expected %u)",
                    p.header.version, kBytecodeVersion);
    }
    if (p.header.instr_size != sizeof(VmInstr)) {
        ThrowErrorF(ErrClass::kFormat, "bytecode instruction width %u does not match this build (%zu)",
                    p.header.instr_size, sizeof(VmInstr));
    }
    uint64_t need = sizeof(VmProgramHeader);
    uint64_t add = 0;
    if (!checked::MulU64(p.header.instr_count, sizeof(VmInstr), add)) {
        ThrowError(ErrClass::kFormat, "bytecode instruction count overflows");
    }
    need += add;
    if (!checked::MulAddU64(p.header.reg_count, sizeof(VmRegDecl), need, need)) {
        ThrowError(ErrClass::kFormat, "bytecode register count overflows");
    }
    if (!checked::MulAddU64(p.header.slot_count, sizeof(VmSlotRef), need, need)) {
        ThrowError(ErrClass::kFormat, "bytecode slot count overflows");
    }
    if (!checked::MulAddU64(p.header.const_count, 4, need, need)) {
        ThrowError(ErrClass::kFormat, "bytecode constant count overflows");
    }
    if (need != blob.size()) {
        ThrowErrorF(ErrClass::kFormat,
                    "bytecode section size %llu does not match the %llu bytes implied by its header",
                    static_cast<unsigned long long>(blob.size()), static_cast<unsigned long long>(need));
    }
    ByteReader r(blob.data() + sizeof(VmProgramHeader), blob.size() - sizeof(VmProgramHeader));
    p.code.resize(p.header.instr_count);
    if (!r.Raw(p.code.data(), p.code.size() * sizeof(VmInstr))) {
        ThrowError(ErrClass::kFormat, "truncated bytecode instruction stream");
    }
    p.regs.resize(p.header.reg_count);
    if (p.header.reg_count && !r.Raw(p.regs.data(), p.regs.size() * sizeof(VmRegDecl))) {
        ThrowError(ErrClass::kFormat, "truncated bytecode register table");
    }
    p.slots.resize(p.header.slot_count);
    if (p.header.slot_count && !r.Raw(p.slots.data(), p.slots.size() * sizeof(VmSlotRef))) {
        ThrowError(ErrClass::kFormat, "truncated bytecode slot table");
    }
    p.consts.resize(p.header.const_count);
    for (uint32_t i = 0; i < p.header.const_count; i++) {
        if (!r.F32(p.consts[i])) ThrowError(ErrClass::kFormat, "truncated bytecode constant table");
    }
    p.blob.assign(blob.begin(), blob.end());
    return p;
}

bool VmProgram::Verify(std::string& err) const {
    return BytecodeVerifier::Verify(*this, err);
}

static bool CheckReg(const VmProgram& p, uint16_t r, const char* what, size_t i, std::string& err) {
    if (r >= p.header.reg_count) {
        err = FormatErrorF("instruction %zu (%s) references register %u but the program declares only %u", i,
                           what, r, p.header.reg_count);
        return false;
    }
    return true;
}

static bool CheckSlot(const VmProgram& p, uint32_t s, const char* what, size_t i, std::string& err) {
    if (s >= p.header.slot_count) {
        err = FormatErrorF("instruction %zu (%s) references weight slot %u but the program declares only %u", i,
                           what, s, p.header.slot_count);
        return false;
    }
    return true;
}

bool BytecodeVerifier::Verify(const VmProgram& p, std::string& err) {
    err.clear();
    if (p.header.magic != kBytecodeMagic) {
        err = "bytecode magic mismatch";
        return false;
    }
    if (p.header.version != kBytecodeVersion) {
        err = FormatErrorF("unsupported bytecode version %u", p.header.version);
        return false;
    }
    if (p.header.instr_count == 0 || p.header.instr_count > 2000000) {
        err = FormatErrorF("bytecode declares an implausible instruction count %u", p.header.instr_count);
        return false;
    }
    if (p.code.size() != p.header.instr_count) {
        err = "bytecode instruction stream length does not match its header";
        return false;
    }
    if (p.regs.size() != p.header.reg_count || p.slots.size() != p.header.slot_count ||
        p.consts.size() != p.header.const_count) {
        err = "bytecode table lengths do not match the header";
        return false;
    }
    if (p.header.n_layer == 0 || p.header.n_layer > 4096) {
        err = "bytecode declares an implausible layer count";
        return false;
    }
    if (p.header.n_embd == 0 || p.header.head_dim == 0 || p.header.n_head == 0 || p.header.n_head_kv == 0) {
        err = "bytecode declares a zero model dimension";
        return false;
    }
    if (p.header.n_head % p.header.n_head_kv != 0) {
        err = "bytecode head counts are inconsistent";
        return false;
    }
    if (p.header.n_head * p.header.head_dim > (1u << 22) || p.header.n_vocab > (1u << 22)) {
        err = "bytecode declares dimensions outside the supported range";
        return false;
    }
    if (p.header.max_ctx == 0 || p.header.max_ctx > (1u << 20)) {
        err = "bytecode declares an implausible context length";
        return false;
    }
    if (p.header.n_rot == 0 || p.header.n_rot > p.header.head_dim || (p.header.n_rot % 2) != 0) {
        err = "bytecode declares an invalid rope dimension count";
        return false;
    }
    if (!(p.header.rope_theta > 0.0f) || !std::isfinite(p.header.rope_theta)) {
        err = "bytecode declares an invalid rope theta";
        return false;
    }
    if (!(p.header.rope_scale > 0.0f) || !std::isfinite(p.header.rope_scale)) {
        err = "bytecode declares an invalid rope scale";
        return false;
    }
    if (!(p.header.norm_eps >= 0.0f) || !std::isfinite(p.header.norm_eps)) {
        err = "bytecode declares an invalid norm epsilon";
        return false;
    }
    uint64_t arena = 0;
    for (uint32_t i = 0; i < p.header.reg_count; i++) {
        const VmRegDecl& d = p.regs[i];
        if (d.ne0 == 0) {
            err = FormatErrorF("register %u declares a zero width", i);
            return false;
        }
        if (d.ne1 != 1) {
            err = FormatErrorF("register %u declares an unsupported row count %u", i, d.ne1);
            return false;
        }
        arena += d.ne0;
    }
    if (arena != p.header.arena_floats) {
        err = FormatErrorF("bytecode arena size %llu does not match the register table (%llu)",
                           static_cast<unsigned long long>(p.header.arena_floats),
                           static_cast<unsigned long long>(arena));
        return false;
    }
    if (p.header.entry_reg >= p.header.reg_count) {
        err = "bytecode entry register is out of range";
        return false;
    }
    if (p.regs[p.header.entry_reg].ne0 != p.header.n_vocab) {
        err = "bytecode entry register does not hold a vocabulary sized vector";
        return false;
    }
    for (uint32_t i = 0; i < p.header.slot_count; i++) {
        const VmSlotRef& s = p.slots[i];
        if (s.n_rows == 0 || s.row_elems == 0) {
            err = FormatErrorF("weight slot %u declares an empty geometry", i);
            return false;
        }
        if (s.slot_id != i) {
            err = FormatErrorF("weight slot table entry %u declares slot id %u", i, s.slot_id);
            return false;
        }
    }
    bool halted = false;
    for (size_t i = 0; i < p.code.size(); i++) {
        const VmInstr& in = p.code[i];
        if (!VmOpKnown(in.op)) {
            err = FormatErrorF("instruction %zu carries the unknown opcode %u", i, in.op);
            return false;
        }
        VmOp op = static_cast<VmOp>(in.op);
        const char* nm = VmOpName(op);
        auto width = [&](uint16_t r) -> uint32_t { return p.regs[r].ne0; };
        switch (op) {
            case VmOp::kNop:
                break;
            case VmOp::kHalt:
                halted = true;
                break;
            case VmOp::kEmbedRow:
                if (!CheckReg(p, in.dst, nm, i, err) || !CheckReg(p, in.src0, nm, i, err)) return false;
                if (!CheckSlot(p, in.slot, nm, i, err)) return false;
                if (width(in.dst) != p.slots[in.slot].row_elems) {
                    err = FormatErrorF("instruction %zu (%s) writes %u values but the weight row holds %llu", i,
                                       nm, width(in.dst),
                                       static_cast<unsigned long long>(p.slots[in.slot].row_elems));
                    return false;
                }
                if (width(in.src0) != 1) {
                    err = FormatErrorF("instruction %zu (%s) needs a scalar token register", i, nm);
                    return false;
                }
                break;
            case VmOp::kScale:
            case VmOp::kCopy:
                if (!CheckReg(p, in.dst, nm, i, err) || !CheckReg(p, in.src0, nm, i, err)) return false;
                if (width(in.dst) != width(in.src0)) {
                    err = FormatErrorF("instruction %zu (%s) has mismatched register widths", i, nm);
                    return false;
                }
                break;
            case VmOp::kRmsNorm:
            case VmOp::kMulWeightVec:
                if (!CheckReg(p, in.dst, nm, i, err) || !CheckReg(p, in.src0, nm, i, err)) return false;
                if (!CheckSlot(p, in.slot, nm, i, err)) return false;
                if (width(in.dst) != width(in.src0) || width(in.dst) != p.slots[in.slot].row_elems) {
                    err = FormatErrorF("instruction %zu (%s) width mismatch (dst %u, src %u, weight %llu)", i,
                                       nm, width(in.dst), width(in.src0),
                                       static_cast<unsigned long long>(p.slots[in.slot].row_elems));
                    return false;
                }
                if (p.slots[in.slot].n_rows != 1) {
                    err = FormatErrorF("instruction %zu (%s) needs a one dimensional weight tensor", i, nm);
                    return false;
                }
                if (!(in.fvalue >= 0.0f) || !std::isfinite(in.fvalue)) {
                    err = FormatErrorF("instruction %zu (%s) carries an invalid epsilon", i, nm);
                    return false;
                }
                break;
            case VmOp::kRmsNormNoGain:
                if (!CheckReg(p, in.dst, nm, i, err) || !CheckReg(p, in.src0, nm, i, err)) return false;
                if (width(in.dst) != width(in.src0)) {
                    err = FormatErrorF("instruction %zu (%s) width mismatch", i, nm);
                    return false;
                }
                break;
            case VmOp::kMulMatVec:
            case VmOp::kLogits:
                if (!CheckReg(p, in.dst, nm, i, err) || !CheckReg(p, in.src0, nm, i, err)) return false;
                if (!CheckSlot(p, in.slot, nm, i, err)) return false;
                if (width(in.dst) != p.slots[in.slot].n_rows) {
                    err = FormatErrorF("instruction %zu (%s) output width %u does not match the %llu rows of "
                                       "weight slot %u",
                                       i, nm, width(in.dst),
                                       static_cast<unsigned long long>(p.slots[in.slot].n_rows), in.slot);
                    return false;
                }
                if (width(in.src0) != p.slots[in.slot].row_elems) {
                    err = FormatErrorF("instruction %zu (%s) input width %u does not match the %llu columns of "
                                       "weight slot %u",
                                       i, nm, width(in.src0),
                                       static_cast<unsigned long long>(p.slots[in.slot].row_elems), in.slot);
                    return false;
                }
                break;
            case VmOp::kAddWeightVec:
                if (!CheckReg(p, in.dst, nm, i, err)) return false;
                if (!CheckSlot(p, in.slot, nm, i, err)) return false;
                if (width(in.dst) != p.slots[in.slot].row_elems || p.slots[in.slot].n_rows != 1) {
                    err = FormatErrorF("instruction %zu (%s) needs a bias vector matching the register width", i,
                                       nm);
                    return false;
                }
                break;
            case VmOp::kRope:
                if (!CheckReg(p, in.dst, nm, i, err) || !CheckReg(p, in.src0, nm, i, err) ||
                    !CheckReg(p, in.src1, nm, i, err)) {
                    return false;
                }
                if (width(in.dst) != width(in.src0) || width(in.src1) != 1) {
                    err = FormatErrorF("instruction %zu (%s) has inconsistent widths", i, nm);
                    return false;
                }
                if (in.imm == 0 || in.imm > p.header.n_rot || (in.imm % 2) != 0) {
                    err = FormatErrorF("instruction %zu (%s) declares an invalid rope width %u", i, nm, in.imm);
                    return false;
                }
                if (width(in.dst) % p.header.head_dim != 0) {
                    err = FormatErrorF("instruction %zu (%s) register width is not head aligned", i, nm);
                    return false;
                }
                break;
            case VmOp::kKvStore:
                if (!CheckReg(p, in.src0, nm, i, err) || !CheckReg(p, in.src1, nm, i, err)) return false;
                if (width(in.src1) != 1) {
                    err = FormatErrorF("instruction %zu (%s) needs a scalar position register", i, nm);
                    return false;
                }
                if (width(in.src0) != p.header.n_head_kv * p.header.head_dim) {
                    err = FormatErrorF("instruction %zu (%s) width %u does not match the key/value width %u", i,
                                       nm, width(in.src0), p.header.n_head_kv * p.header.head_dim);
                    return false;
                }
                if (in.imm >= p.header.n_layer) {
                    err = FormatErrorF("instruction %zu (%s) targets layer %u of %u", i, nm, in.imm,
                                       p.header.n_layer);
                    return false;
                }
                break;
            case VmOp::kAttention:
                if (!CheckReg(p, in.dst, nm, i, err) || !CheckReg(p, in.src0, nm, i, err) ||
                    !CheckReg(p, in.src1, nm, i, err)) {
                    return false;
                }
                if (width(in.dst) != p.header.n_head * p.header.head_dim || width(in.src0) != width(in.dst)) {
                    err = FormatErrorF("instruction %zu (%s) width mismatch", i, nm);
                    return false;
                }
                if (width(in.src1) != 1) {
                    err = FormatErrorF("instruction %zu (%s) needs a scalar position register", i, nm);
                    return false;
                }
                if (in.imm >= p.header.n_layer) {
                    err = FormatErrorF("instruction %zu (%s) targets layer %u of %u", i, nm, in.imm,
                                       p.header.n_layer);
                    return false;
                }
                if (!(in.fvalue > 0.0f) || !std::isfinite(in.fvalue)) {
                    err = FormatErrorF("instruction %zu (%s) carries an invalid attention scale", i, nm);
                    return false;
                }
                break;
            case VmOp::kAdd:
            case VmOp::kMul:
            case VmOp::kSwiGlu:
            case VmOp::kGeGlu:
                if (!CheckReg(p, in.dst, nm, i, err) || !CheckReg(p, in.src0, nm, i, err) ||
                    !CheckReg(p, in.src1, nm, i, err)) {
                    return false;
                }
                if (width(in.dst) != width(in.src0) || width(in.dst) != width(in.src1)) {
                    err = FormatErrorF("instruction %zu (%s) has mismatched register widths (%u, %u, %u)", i, nm,
                                       width(in.dst), width(in.src0), width(in.src1));
                    return false;
                }
                break;
            case VmOp::kIntegrityProbe:
                if (in.imm > 4096) {
                    err = FormatErrorF("instruction %zu (%s) declares an implausible probe scope", i, nm);
                    return false;
                }
                break;
            case VmOp::kAssertFinite:
                if (!CheckReg(p, in.src0, nm, i, err)) return false;
                break;
            default:
                err = FormatErrorF("instruction %zu carries an unhandled opcode %u", i, in.op);
                return false;
        }
    }
    if (!halted) {
        err = "the bytecode program does not terminate with a HALT instruction";
        return false;
    }
    uint8_t digest[32];
    p.ComputeDigest(digest);
    if (sodium_memcmp(digest, p.header.program_digest, 32) != 0) {
        err = "the bytecode program digest does not match its contents";
        return false;
    }
    return true;
}

VmProgram BytecodeCompiler::Compile(const ModelGraph& g, const ModelSpec& spec, const WeightLayout& layout,
                                    uint32_t max_ctx, bool rmp_enabled, std::string& err) {
    VmProgram p;
    err.clear();
    if (!g.Validate(err)) return p;

    std::vector<uint32_t> slot_of_node(g.nodes.size(), UINT32_MAX);
    std::unordered_map<std::string, uint32_t> slot_by_name;
    p.slots.reserve(layout.slots.size());
    for (const auto& s : layout.slots) {
        uint32_t id = static_cast<uint32_t>(p.slots.size());
        VmSlotRef ref{};
        ref.slot_id = id;
        ref.role = static_cast<uint32_t>(s.role);
        ref.layer = s.layer;
        ref.storage_type = s.type_id;
        ref.n_rows = s.n_rows;
        ref.row_elems = s.row_elems;
        memcpy(ref.digest, s.digest, 32);
        p.slots.push_back(ref);
        slot_by_name.emplace(s.name, id);
    }

    std::vector<uint32_t> last_use(g.nodes.size(), 0);
    for (size_t i = 0; i < g.nodes.size(); i++) {
        for (uint32_t in : g.nodes[i].inputs) last_use[in] = static_cast<uint32_t>(i);
    }

    std::vector<int> reg_of(g.nodes.size(), -1);
    std::vector<bool> reg_busy;
    std::vector<uint32_t> reg_width;
    auto alloc_reg = [&](uint32_t width) -> uint16_t {
        for (size_t r = 0; r < reg_busy.size(); r++) {
            if (!reg_busy[r] && reg_width[r] == width) {
                reg_busy[r] = true;
                return static_cast<uint16_t>(r);
            }
        }
        reg_busy.push_back(true);
        reg_width.push_back(width);
        return static_cast<uint16_t>(reg_busy.size() - 1);
    };

    uint16_t token_reg = alloc_reg(1);
    uint16_t pos_reg = alloc_reg(1);
    uint16_t logits_reg = alloc_reg(spec.n_vocab);
    reg_busy[token_reg] = true;
    reg_busy[pos_reg] = true;
    reg_busy[logits_reg] = true;

    std::vector<VmInstr> code;
    code.reserve(g.nodes.size() + 16);
    auto emit = [&](VmOp op, uint16_t dst, uint16_t s0, uint16_t s1, uint32_t slot, uint32_t imm, float fv,
                    uint16_t a0 = 0, uint16_t a1 = 0) {
        VmInstr in{};
        in.op = static_cast<uint16_t>(op);
        in.dst = dst;
        in.src0 = s0;
        in.src1 = s1;
        in.slot = slot;
        in.imm = imm;
        in.fvalue = fv;
        in.aux0 = a0;
        in.aux1 = a1;
        code.push_back(in);
    };

    uint32_t probes = 0;
    for (size_t i = 0; i < g.nodes.size(); i++) {
        const GraphNode& n = g.nodes[i];
        uint16_t src0 = UINT16_MAX, src1 = UINT16_MAX;
        for (size_t k = 0; k < n.inputs.size(); k++) {
            uint32_t in = n.inputs[k];
            int r = reg_of[in];
            if (r < 0) {
                err = FormatErrorF("graph node %zu uses node %u which was never assigned a register", i, in);
                return p;
            }
            if (k == 0) src0 = static_cast<uint16_t>(r);
            else if (k == 1) src1 = static_cast<uint16_t>(r);
        }
        uint32_t slot = UINT32_MAX;
        if (!n.weight.empty()) {
            auto it = slot_by_name.find(n.weight);
            if (it == slot_by_name.end()) {
                err = "graph references weight '" + n.weight + "' which is not in the container";
                return p;
            }
            slot = it->second;
        }
        if (n.op == GraphOp::kInput) {
            if (n.iparam == 1) reg_of[n.id] = pos_reg;
            else reg_of[n.id] = token_reg;
            continue;
        }
        if (n.op == GraphOp::kOutput) {
            reg_of[n.id] = src0;
            continue;
        }
        uint16_t dst = UINT16_MAX;
        bool in_place = (n.op == GraphOp::kAddWeightVec);
        if (!in_place) dst = (n.id == g.logits_node) ? logits_reg : alloc_reg(n.ne0);
        switch (n.op) {
            case GraphOp::kEmbed:
                emit(VmOp::kEmbedRow, dst, src0, 0, slot, 0, 0.0f);
                break;
            case GraphOp::kScale:
                if (n.iparam == 2) {
                    err = "final logit soft capping is not expressible in this bytecode revision";
                    return p;
                }
                emit(VmOp::kScale, dst, src0, 0, UINT32_MAX, 0, n.fparam);
                break;
            case GraphOp::kRmsNorm:
                emit(VmOp::kRmsNorm, dst, src0, 0, slot, 0, n.fparam);
                break;
            case GraphOp::kMulMatVec:
                emit(VmOp::kMulMatVec, dst, src0, 0, slot, 0, 0.0f);
                break;
            case GraphOp::kAddWeightVec:
                emit(VmOp::kAddWeightVec, src0, src0, 0, slot, 0, 0.0f);
                dst = src0;
                break;
            case GraphOp::kRope:
                emit(VmOp::kRope, dst, src0, src1, UINT32_MAX, n.iparam, 0.0f,
                     static_cast<uint16_t>(spec.head_dim), 0);
                break;
            case GraphOp::kKvStore:
                emit(VmOp::kKvStore, 0, src0, src1, UINT32_MAX, n.layer, 0.0f,
                     static_cast<uint16_t>(n.iparam), 0);
                break;
            case GraphOp::kAttention:
                emit(VmOp::kAttention, dst, src0, src1, UINT32_MAX, n.layer, n.fparam,
                     static_cast<uint16_t>(n.iparam), 0);
                break;
            case GraphOp::kAdd:
                emit(VmOp::kAdd, dst, src0, src1, UINT32_MAX, 0, 0.0f);
                break;
            case GraphOp::kMul:
                emit(VmOp::kMul, dst, src0, src1, UINT32_MAX, 0, 0.0f);
                break;
            case GraphOp::kSwiGlu:
                emit(VmOp::kSwiGlu, dst, src0, src1, UINT32_MAX, 0, 0.0f);
                break;
            case GraphOp::kGeGlu:
                emit(VmOp::kGeGlu, dst, src0, src1, UINT32_MAX, 0, 0.0f);
                break;
            case GraphOp::kLogits:
                emit(VmOp::kLogits, dst, src0, 0, slot, 0, 0.0f);
                break;
            case GraphOp::kIntegrityProbe:
                emit(VmOp::kIntegrityProbe, 0, 0, 0, UINT32_MAX, 0, 0.0f);
                probes++;
                break;
            default:
                err = FormatErrorF("graph node %zu uses operation %s which has no bytecode encoding", i,
                                   GraphOpName(n.op));
                return p;
        }
        if (rmp_enabled && (n.op == GraphOp::kAdd || n.op == GraphOp::kLogits ||
                            n.op == GraphOp::kRmsNorm || n.op == GraphOp::kAttention)) {
            emit(VmOp::kAssertFinite, 0, dst, 0, UINT32_MAX, static_cast<uint32_t>(i), 0.0f);
        }
        if (n.op != GraphOp::kKvStore) reg_of[n.id] = dst;
        else reg_of[n.id] = src0;
        for (uint32_t in : n.inputs) {
            if (last_use[in] == i && reg_of[in] >= 0 && reg_of[in] != token_reg && reg_of[in] != pos_reg &&
                reg_of[in] != logits_reg) {
                if (reg_of[in] != dst) reg_busy[static_cast<size_t>(reg_of[in])] = false;
            }
        }
    }

    if (rmp_enabled) {
        emit(VmOp::kIntegrityProbe, 0, 0, 0, UINT32_MAX, 1, 0.0f);
        probes++;
    }
    emit(VmOp::kHalt, 0, 0, 0, UINT32_MAX, 0, 0.0f);

    int out_reg = reg_of[g.logits_node];
    if (out_reg < 0) {
        err = "the compiler did not produce a logits register";
        return p;
    }

    p.code.swap(code);
    p.header.magic = kBytecodeMagic;
    p.header.version = kBytecodeVersion;
    p.header.instr_size = sizeof(VmInstr);
    p.header.instr_count = static_cast<uint32_t>(p.code.size());
    p.header.reg_count = static_cast<uint32_t>(reg_width.size());
    p.header.slot_count = static_cast<uint32_t>(p.slots.size());
    p.header.const_count = 0;
    p.header.max_ctx = max_ctx;
    p.header.n_layer = spec.n_layer;
    p.header.n_embd = spec.n_embd;
    p.header.n_head = spec.n_head;
    p.header.n_head_kv = spec.n_head_kv;
    p.header.head_dim = spec.head_dim;
    p.header.n_rot = spec.n_rot;
    p.header.n_ff = spec.n_ff;
    p.header.n_vocab = spec.n_vocab;
    p.header.rope_theta = spec.rope_theta;
    p.header.rope_scale = spec.rope_scale;
    p.header.norm_eps = spec.norm_eps;
    p.header.attn_scale = 1.0f / std::sqrt(static_cast<float>(spec.head_dim));
    p.header.attn_softcap = spec.attn_softcap;
    p.header.final_softcap = spec.final_softcap;
    p.header.embd_scale = spec.embd_scale;
    p.header.ffn_kind = static_cast<uint32_t>(spec.ffn);
    p.header.tied_output = spec.tied_output ? 1u : 0u;
    p.header.rmp_probes = probes;
    p.header.entry_reg = static_cast<uint32_t>(out_reg);
    uint64_t arena = 0;
    p.regs.resize(reg_width.size());
    for (size_t r = 0; r < reg_width.size(); r++) {
        VmRegDecl d{};
        d.ne0 = reg_width[r];
        d.ne1 = 1;
        d.kind = (r == token_reg) ? 1u : ((r == pos_reg) ? 2u : 0u);
        p.regs[r] = d;
        arena += d.ne0;
    }
    p.header.arena_floats = arena;
    memset(p.header.program_digest, 0, 32);
    memset(p.header.reserved, 0, 32);
    p.ComputeDigest(p.header.program_digest);
    if (!p.Verify(err)) {
        err = "the compiler produced a program that fails its own verification: " + err;
        p = VmProgram();
        return p;
    }
    p.blob = p.Serialize();
    return p;
}

}
namespace aip {

void KvCache::Allocate(uint32_t layers, uint32_t ctx, uint32_t head_kv, uint32_t hdim) {
    uint64_t per = static_cast<uint64_t>(layers) * ctx * head_kv * hdim;
    if (per == 0 || per > (1ull << 34)) {
        ThrowErrorF(ErrClass::kMemory, "the requested key/value cache needs %llu cells which is out of range",
                    static_cast<unsigned long long>(per));
    }
    n_layer = layers;
    n_ctx = ctx;
    n_head_kv = head_kv;
    head_dim = hdim;
    try {
        k.assign(static_cast<size_t>(per), 0.0f);
        v.assign(static_cast<size_t>(per), 0.0f);
    } catch (const std::bad_alloc&) {
        ThrowErrorF(ErrClass::kMemory,
                    "failed to allocate %s of key/value cache memory (layers=%u, ctx=%u, kv heads=%u, "
                    "head dim=%u); reduce the context length with --ctx",
                    HumanBytes(per * 2 * sizeof(float)).c_str(), layers, ctx, head_kv, hdim);
    }
    size = 0;
}

void KvCache::Reset() {
    size = 0;
    std::fill(k.begin(), k.end(), 0.0f);
    std::fill(v.begin(), v.end(), 0.0f);
}

float* KvCache::KPtr(uint32_t layer, uint32_t pos) {
    uint64_t stride = static_cast<uint64_t>(n_head_kv) * head_dim;
    return k.data() + (static_cast<uint64_t>(layer) * n_ctx + pos) * stride;
}

float* KvCache::VPtr(uint32_t layer, uint32_t pos) {
    uint64_t stride = static_cast<uint64_t>(n_head_kv) * head_dim;
    return v.data() + (static_cast<uint64_t>(layer) * n_ctx + pos) * stride;
}

static inline float DotF32(const float* a, const float* b, uint64_t n) {
    float s0 = 0, s1 = 0, s2 = 0, s3 = 0;
    uint64_t i = 0;
    for (; i + 4 <= n; i += 4) {
        s0 += a[i + 0] * b[i + 0];
        s1 += a[i + 1] * b[i + 1];
        s2 += a[i + 2] * b[i + 2];
        s3 += a[i + 3] * b[i + 3];
    }
    for (; i < n; i++) s0 += a[i] * b[i];
    return (s0 + s1) + (s2 + s3);
}

static inline float SiluF32(float x) {
    if (x <= -80.0f) return 0.0f;
    return x / (1.0f + std::exp(-x));
}

static inline float GeluTanhF32(float x) {
    if (x <= -10.0f) return 0.0f;
    if (x >= 10.0f) return x;
    const float kA = 0.044715f;
    const float kS = 0.79788456080286535587989211986876f;
    return 0.5f * x * (1.0f + std::tanh(kS * x * (1.0f + kA * x * x)));
}

VirtualMachine::VirtualMachine(VmProgram program, WeightProvider& weights, Limits limits)
    : prog_(std::move(program)), weights_(weights), limits_(limits) {
    threads_ = 1;
}

VirtualMachine::~VirtualMachine() { PoolStop(); }

void VirtualMachine::Configure(uint32_t n_ctx, uint32_t threads) {
    if (n_ctx == 0) n_ctx = 512;
    if (n_ctx > prog_.header.max_ctx) {
        ThrowErrorF(ErrClass::kRuntime,
                    "the requested context length %u exceeds the %u positions this container was compiled for",
                    n_ctx, prog_.header.max_ctx);
    }
    uint32_t hw = std::thread::hardware_concurrency();
    if (hw == 0) hw = 1;
    if (threads == 0) threads = std::min<uint32_t>(hw, 4u);
    if (threads > hw) threads = hw;
    if (threads == 0) threads = 1;
    threads_ = threads;
    kv_.Allocate(prog_.header.n_layer, n_ctx, prog_.header.n_head_kv, prog_.header.head_dim);
}

void VirtualMachine::PoolStart(uint32_t n) {
    PoolStop();
    pool_.nthreads = std::max<uint32_t>(n, 1);
    if (pool_.nthreads <= 1) return;
    pool_.stop = false;
    pool_.job_id = 0;
    pool_.finished = 0;
    for (uint32_t t = 1; t < pool_.nthreads; t++) {
        pool_.workers.emplace_back([this, t]() {
            uint64_t last = 0;
            for (;;) {
                std::function<void(uint64_t, uint64_t)> job;
                uint64_t total = 0;
                uint64_t nth = 1;
                {
                    std::unique_lock<std::mutex> lk(pool_.mu);
                    pool_.cv_start.wait(lk, [this, &last]() { return pool_.stop || pool_.job_id != last; });
                    if (pool_.stop) return;
                    last = pool_.job_id;
                    job = pool_.job;
                    total = pool_.total;
                    nth = pool_.nthreads;
                }
                uint64_t begin = (total * t) / nth;
                uint64_t end = (total * (t + 1)) / nth;
                if (end > begin && job) {
                    try {
                        job(begin, end);
                    } catch (...) {
                        std::lock_guard<std::mutex> lk(pool_.mu);
                        if (!pool_.error) pool_.error = std::current_exception();
                    }
                }
                {
                    std::lock_guard<std::mutex> lk(pool_.mu);
                    pool_.finished++;
                }
                pool_.cv_done.notify_all();
            }
        });
    }
}

void VirtualMachine::PoolStop() {
    if (!pool_.workers.empty()) {
        {
            std::lock_guard<std::mutex> lk(pool_.mu);
            pool_.stop = true;
        }
        pool_.cv_start.notify_all();
        for (auto& t : pool_.workers) {
            if (t.joinable()) t.join();
        }
        pool_.workers.clear();
    }
    {
        std::lock_guard<std::mutex> lk(pool_.mu);
        pool_.stop = false;
        pool_.job = nullptr;
        pool_.finished = 0;
        pool_.total = 0;
    }
}

void VirtualMachine::ParallelFor(uint64_t n, const std::function<void(uint64_t, uint64_t)>& fn) {
    if (pool_.nthreads <= 1 || n < 4096) {
        fn(0, n);
        return;
    }
    uint32_t nth = pool_.nthreads;
    {
        std::lock_guard<std::mutex> lk(pool_.mu);
        pool_.job = fn;
        pool_.total = n;
        pool_.finished = 0;
        pool_.error = nullptr;
        pool_.job_id++;
    }
    pool_.cv_start.notify_all();
    uint64_t main_end = n / nth;
    std::exception_ptr main_error;
    try {
        if (main_end > 0) fn(0, main_end);
    } catch (...) {
        main_error = std::current_exception();
    }
    {
        std::unique_lock<std::mutex> lk(pool_.mu);
        pool_.cv_done.wait(lk, [this, nth]() { return pool_.finished + 1 >= nth; });
    }
    std::exception_ptr worker_error;
    {
        std::lock_guard<std::mutex> lk(pool_.mu);
        pool_.job = nullptr;
        worker_error = pool_.error;
        pool_.error = nullptr;
    }
    if (main_error) std::rethrow_exception(main_error);
    if (worker_error) std::rethrow_exception(worker_error);
}

bool VirtualMachine::Prepare(std::string& err) {
    if (!prog_.Verify(err)) return false;
    if (prog_.header.instr_count > limits_.max_instructions) {
        err = FormatErrorF("the program holds %u instructions which exceeds the safety limit %u",
                           prog_.header.instr_count, limits_.max_instructions);
        return false;
    }
    if (prog_.header.arena_floats * sizeof(float) > limits_.max_arena_bytes) {
        err = FormatErrorF("the program needs %s of activation memory which exceeds the configured limit",
                           HumanBytes(prog_.header.arena_floats * sizeof(float)).c_str());
        return false;
    }
    reg_base_.assign(prog_.regs.size() + 1, 0);
    for (size_t r = 0; r < prog_.regs.size(); r++) {
        reg_base_[r + 1] = reg_base_[r] + prog_.regs[r].ne0;
    }
    try {
        arena_.assign(static_cast<size_t>(reg_base_.back()), 0.0f);
    } catch (const std::bad_alloc&) {
        err = "failed to allocate the activation arena";
        return false;
    }
    regs_.resize(prog_.regs.size());
    token_reg_ = UINT16_MAX;
    pos_reg_ = UINT16_MAX;
    for (size_t r = 0; r < prog_.regs.size(); r++) {
        regs_[r].ptr = arena_.data() + reg_base_[r];
        regs_[r].ne0 = prog_.regs[r].ne0;
        regs_[r].ne1 = prog_.regs[r].ne1;
        regs_[r].owned = false;
        if (prog_.regs[r].kind == 1) token_reg_ = static_cast<uint16_t>(r);
        if (prog_.regs[r].kind == 2) pos_reg_ = static_cast<uint16_t>(r);
    }
    if (token_reg_ == UINT16_MAX || pos_reg_ == UINT16_MAX) {
        err = "the bytecode program does not declare token and position input registers";
        return false;
    }
    scores_.resize(std::max<uint32_t>(prog_.header.max_ctx, 1));
    rope_cos_.resize(prog_.header.n_rot);
    rope_sin_.resize(prog_.header.n_rot);
    rope_pos_cached_ = -1;
    logits_size_ = prog_.regs[prog_.header.entry_reg].ne0;
    logits_ptr_ = regs_[prog_.header.entry_reg].ptr;
    PoolStart(threads_);
    prepared_ = true;
    return true;
}

void VirtualMachine::ResetCache() {
    kv_.Reset();
    rope_pos_cached_ = -1;
}

float* VirtualMachine::RegPtr(uint16_t r) {
    if (r >= regs_.size()) {
        ThrowErrorF(ErrClass::kRuntime, "bytecode references register %u of %zu", r, regs_.size());
    }
    return regs_[r].ptr;
}

const VirtualMachine::Reg& VirtualMachine::R(uint16_t r) const {
    if (r >= regs_.size()) {
        ThrowErrorF(ErrClass::kRuntime, "bytecode references register %u of %zu", r, regs_.size());
    }
    return regs_[r];
}

void VirtualMachine::EnsureReg(uint16_t r) { (void)r; }

void VirtualMachine::MulMatVecRange(uint32_t slot_id, const float* src, float* dst, uint64_t row_begin,
                                    uint64_t row_end) {
    const TensorSlot* s = weights_.Slot(slot_id);
    if (!s) ThrowErrorF(ErrClass::kRuntime, "weight slot %u is not present in the container", slot_id);
    uint64_t k = s->row_elems;
    std::vector<float> row(static_cast<size_t>(k));
    for (uint64_t r = row_begin; r < row_end; r++) {
        weights_.ReadRow(slot_id, r, row.data());
        dst[r] = DotF32(row.data(), src, k);
    }
}

void VirtualMachine::OpEmbed(const VmInstr& in, int32_t token) {
    const TensorSlot* s = weights_.Slot(in.slot);
    if (!s) ThrowErrorF(ErrClass::kRuntime, "embedding slot %u is missing", in.slot);
    if (token < 0 || static_cast<uint64_t>(token) >= s->n_rows) {
        ThrowErrorF(ErrClass::kRuntime, "token id %d is outside the embedding table of %llu rows", token,
                    static_cast<unsigned long long>(s->n_rows));
    }
    float* dst = RegPtr(in.dst);
    weights_.ReadRow(in.slot, static_cast<uint64_t>(token), dst);
    if (static_cast<uint64_t>(s->row_elems) != R(in.dst).ne0) {
        ThrowError(ErrClass::kRuntime, "embedding row width does not match the destination register");
    }
}

void VirtualMachine::OpRmsNorm(const VmInstr& in) {
    const float* x = RegPtr(in.src0);
    float* y = RegPtr(in.dst);
    uint64_t n = R(in.dst).ne0;
    const float* gain = nullptr;
    if (in.op == static_cast<uint16_t>(VmOp::kRmsNorm)) gain = weights_.Vector(in.slot);
    long double sum = 0.0L;
    for (uint64_t i = 0; i < n; i++) sum += static_cast<long double>(x[i]) * static_cast<long double>(x[i]);
    float mean = static_cast<float>(sum / static_cast<long double>(n));
    float scale = 1.0f / std::sqrt(mean + in.fvalue);
    if (!std::isfinite(scale)) {
        ThrowError(ErrClass::kIntegrity, "RMSNorm produced a non finite scale; the model state is corrupt");
    }
    if (gain) {
        for (uint64_t i = 0; i < n; i++) y[i] = x[i] * scale * gain[i];
    } else {
        for (uint64_t i = 0; i < n; i++) y[i] = x[i] * scale;
    }
}

void VirtualMachine::OpMulMatVec(const VmInstr& in, bool logits_out) {
    const TensorSlot* s = weights_.Slot(in.slot);
    if (!s) ThrowErrorF(ErrClass::kRuntime, "weight slot %u is missing", in.slot);
    const float* src = RegPtr(in.src0);
    float* dst = RegPtr(in.dst);
    uint64_t n = s->n_rows;
    if (n != R(in.dst).ne0) {
        ThrowErrorF(ErrClass::kRuntime, "matrix vector product row count %llu does not match register width %llu",
                    static_cast<unsigned long long>(n), static_cast<unsigned long long>(R(in.dst).ne0));
    }
    if (s->row_elems != R(in.src0).ne0) {
        ThrowErrorF(ErrClass::kRuntime,
                    "matrix vector product column count %llu does not match the input register width %llu",
                    static_cast<unsigned long long>(s->row_elems),
                    static_cast<unsigned long long>(R(in.src0).ne0));
    }
    uint32_t slot_id = in.slot;
    ParallelFor(n, [this, slot_id, src, dst](uint64_t b, uint64_t e) { MulMatVecRange(slot_id, src, dst, b, e); });
    (void)logits_out;
}

void VirtualMachine::OpAddWeightVec(const VmInstr& in) {
    const float* w = weights_.Vector(in.slot);
    float* d = RegPtr(in.dst);
    uint64_t n = R(in.dst).ne0;
    for (uint64_t i = 0; i < n; i++) d[i] += w[i];
}

void VirtualMachine::OpMulWeightVec(const VmInstr& in) {
    const float* w = weights_.Vector(in.slot);
    float* d = RegPtr(in.dst);
    uint64_t n = R(in.dst).ne0;
    for (uint64_t i = 0; i < n; i++) d[i] *= w[i];
}

void VirtualMachine::OpRope(const VmInstr& in, int32_t position) {
    if (position < 0 || static_cast<uint32_t>(position) >= kv_.n_ctx) {
        ThrowErrorF(ErrClass::kRuntime, "position %d is outside the key/value cache of %u slots", position,
                    kv_.n_ctx);
    }
    uint32_t n_rot = in.imm;
    uint32_t head_dim = in.aux0;
    if (head_dim == 0 || n_rot == 0 || n_rot > head_dim) {
        ThrowError(ErrClass::kRuntime, "RoPE instruction carries an invalid geometry");
    }
    if (rope_pos_cached_ != static_cast<int64_t>(position)) {
        float theta_scale = std::pow(prog_.header.rope_theta, -2.0f / static_cast<float>(n_rot));
        float theta = static_cast<float>(position) * prog_.header.rope_scale;
        for (uint32_t i = 0; i < n_rot / 2; i++) {
            rope_cos_[i] = std::cos(theta);
            rope_sin_[i] = std::sin(theta);
            theta *= theta_scale;
        }
        rope_pos_cached_ = position;
    }
    const float* src = RegPtr(in.src0);
    float* dst = RegPtr(in.dst);
    uint64_t n = R(in.dst).ne0;
    if (n % head_dim != 0) ThrowError(ErrClass::kRuntime, "RoPE register width is not head aligned");
    uint64_t heads = n / head_dim;
    uint32_t half = n_rot / 2;
    for (uint64_t h = 0; h < heads; h++) {
        const float* s = src + h * head_dim;
        float* d = dst + h * head_dim;
        for (uint32_t i = 0; i < half; i++) {
            float c = rope_cos_[i];
            float sn = rope_sin_[i];
            float x0 = s[i];
            float x1 = s[i + half];
            d[i] = x0 * c - x1 * sn;
            d[i + half] = x0 * sn + x1 * c;
        }
        for (uint32_t i = n_rot; i < head_dim; i++) d[i] = s[i];
    }
}

void VirtualMachine::OpKvStore(const VmInstr& in, int32_t position) {
    if (in.imm >= prog_.header.n_layer) {
        ThrowErrorF(ErrClass::kRuntime, "key/value store targets layer %u of %u", in.imm, prog_.header.n_layer);
    }
    if (position < 0 || static_cast<uint32_t>(position) >= kv_.n_ctx) {
        ThrowErrorF(ErrClass::kRuntime, "position %d is outside the key/value cache of %u slots", position,
                    kv_.n_ctx);
    }
    const float* src = RegPtr(in.src0);
    uint64_t n = R(in.src0).ne0;
    float* dst = in.aux0 ? kv_.KPtr(in.imm, static_cast<uint32_t>(position))
                         : kv_.VPtr(in.imm, static_cast<uint32_t>(position));
    memcpy(dst, src, static_cast<size_t>(n) * sizeof(float));
    if (static_cast<uint32_t>(position) + 1 > kv_.size) kv_.size = static_cast<uint32_t>(position) + 1;
}

void VirtualMachine::OpAttention(const VmInstr& in, int32_t position) {
    uint32_t layer = in.imm;
    if (layer >= prog_.header.n_layer) {
        ThrowErrorF(ErrClass::kRuntime, "attention targets layer %u of %u", layer, prog_.header.n_layer);
    }
    if (position < 0 || static_cast<uint32_t>(position) >= kv_.n_ctx) {
        ThrowErrorF(ErrClass::kRuntime, "attention position %d is outside the cache", position);
    }
    const uint32_t npos = static_cast<uint32_t>(position) + 1;
    const uint32_t hd = prog_.header.head_dim;
    const uint32_t nh = prog_.header.n_head;
    const uint32_t nkv = prog_.header.n_head_kv;
    const uint32_t rep = nh / nkv;
    const float scale = in.fvalue;
    const bool softcap = in.aux0 != 0;
    const float cap = prog_.header.attn_softcap;
    const float* q = RegPtr(in.src0);
    float* out = RegPtr(in.dst);
    if (R(in.dst).ne0 != static_cast<uint64_t>(nh) * hd) {
        ThrowError(ErrClass::kRuntime, "attention output register has an unexpected width");
    }
    if (scores_.size() < npos) scores_.resize(npos);
    std::vector<float> head_scores(static_cast<size_t>(npos) * std::max<uint32_t>(threads_, 1));
    auto work = [&](uint64_t hb, uint64_t he) {
        for (uint64_t h = hb; h < he; h++) {
            uint32_t head = static_cast<uint32_t>(h);
            float* sc = head_scores.data() + static_cast<size_t>(head % std::max<uint32_t>(threads_, 1)) * npos;
            const float* qh = q + head * hd;
            uint32_t kvh = head / rep;
            float maxs = -std::numeric_limits<float>::infinity();
            for (uint32_t p = 0; p < npos; p++) {
                const float* kp = kv_.KPtr(layer, p) + static_cast<uint64_t>(kvh) * hd;
                float s = DotF32(qh, kp, hd) * scale;
                if (softcap && cap > 0.0f) s = std::tanh(s / cap) * cap;
                sc[p] = s;
                if (s > maxs) maxs = s;
            }
            float sum = 0.0f;
            for (uint32_t p = 0; p < npos; p++) {
                float e = std::exp(sc[p] - maxs);
                sc[p] = e;
                sum += e;
            }
            if (!(sum > 0.0f) || !std::isfinite(sum)) {
                ThrowError(ErrClass::kIntegrity, "attention softmax produced a degenerate distribution");
            }
            float inv = 1.0f / sum;
            float* oh = out + head * hd;
            for (uint32_t d = 0; d < hd; d++) oh[d] = 0.0f;
            for (uint32_t p = 0; p < npos; p++) {
                float w = sc[p] * inv;
                if (w == 0.0f) continue;
                const float* vp = kv_.VPtr(layer, p) + static_cast<uint64_t>(kvh) * hd;
                for (uint32_t d = 0; d < hd; d++) oh[d] += w * vp[d];
            }
        }
    };
    ParallelFor(nh, work);
}

void VirtualMachine::OpAdd(const VmInstr& in) {
    const float* a = RegPtr(in.src0);
    const float* b = RegPtr(in.src1);
    float* d = RegPtr(in.dst);
    uint64_t n = R(in.dst).ne0;
    for (uint64_t i = 0; i < n; i++) d[i] = a[i] + b[i];
}

void VirtualMachine::OpMul(const VmInstr& in) {
    const float* a = RegPtr(in.src0);
    const float* b = RegPtr(in.src1);
    float* d = RegPtr(in.dst);
    uint64_t n = R(in.dst).ne0;
    for (uint64_t i = 0; i < n; i++) d[i] = a[i] * b[i];
}

void VirtualMachine::OpGlu(const VmInstr& in, bool swiglu) {
    const float* g = RegPtr(in.src0);
    const float* u = RegPtr(in.src1);
    float* d = RegPtr(in.dst);
    uint64_t n = R(in.dst).ne0;
    if (swiglu) {
        for (uint64_t i = 0; i < n; i++) d[i] = SiluF32(g[i]) * u[i];
    } else {
        for (uint64_t i = 0; i < n; i++) d[i] = GeluTanhF32(g[i]) * u[i];
    }
}

void VirtualMachine::OpScale(const VmInstr& in) {
    const float* a = RegPtr(in.src0);
    float* d = RegPtr(in.dst);
    uint64_t n = R(in.dst).ne0;
    float s = in.fvalue;
    for (uint64_t i = 0; i < n; i++) d[i] = a[i] * s;
}

void VirtualMachine::OpCopy(const VmInstr& in) {
    const float* a = RegPtr(in.src0);
    float* d = RegPtr(in.dst);
    memcpy(d, a, static_cast<size_t>(R(in.dst).ne0) * sizeof(float));
}

void VirtualMachine::OpAssertFinite(const VmInstr& in) {
    const float* a = RegPtr(in.src0);
    uint64_t n = R(in.src0).ne0;
    for (uint64_t i = 0; i < n; i++) {
        if (!std::isfinite(a[i])) {
            ThrowErrorF(ErrClass::kIntegrity,
                        "runtime integrity check failed: value %llu of the activation vector produced by graph "
                        "node %u is %s",
                        static_cast<unsigned long long>(i), in.imm, std::isnan(a[i]) ? "NaN" : "infinite");
        }
    }
}

void VirtualMachine::OpIntegrityProbe(const VmInstr& in, std::vector<RmpFinding>* findings) {
    if (!rmp_ || !rmp_->Enabled()) return;
    uint8_t digest[32];
    prog_.ComputeDigest(digest);
    if (sodium_memcmp(digest, prog_.header.program_digest, 32) != 0) {
        RmpFinding f;
        f.source = "vm";
        f.detail = "the executing bytecode no longer matches the digest recorded in its header";
        f.fatal = true;
        if (findings) findings->push_back(f);
        ThrowError(ErrClass::kIntegrity, f.detail);
    }
    std::vector<RmpFinding> local;
    if (!rmp_->VerifyRegions(local)) {
        if (findings) findings->insert(findings->end(), local.begin(), local.end());
        ThrowError(ErrClass::kIntegrity, "the runtime detected that protected structures changed in memory");
    }
    if (findings) findings->insert(findings->end(), local.begin(), local.end());
    (void)in;
}

void VirtualMachine::ExecInstr(const VmInstr& in, int32_t token, int32_t position,
                              std::vector<RmpFinding>* findings) {
    switch (static_cast<VmOp>(in.op)) {
        case VmOp::kNop: break;
        case VmOp::kHalt: break;
        case VmOp::kEmbedRow: OpEmbed(in, token); break;
        case VmOp::kScale: OpScale(in); break;
        case VmOp::kRmsNorm:
        case VmOp::kRmsNormNoGain: OpRmsNorm(in); break;
        case VmOp::kMulMatVec: OpMulMatVec(in, false); break;
        case VmOp::kLogits: OpMulMatVec(in, true); break;
        case VmOp::kAddWeightVec: OpAddWeightVec(in); break;
        case VmOp::kMulWeightVec: OpMulWeightVec(in); break;
        case VmOp::kRope: OpRope(in, position); break;
        case VmOp::kKvStore: OpKvStore(in, position); break;
        case VmOp::kAttention: OpAttention(in, position); break;
        case VmOp::kAdd: OpAdd(in); break;
        case VmOp::kMul: OpMul(in); break;
        case VmOp::kSwiGlu: OpGlu(in, true); break;
        case VmOp::kGeGlu: OpGlu(in, false); break;
        case VmOp::kCopy: OpCopy(in); break;
        case VmOp::kIntegrityProbe: OpIntegrityProbe(in, findings); break;
        case VmOp::kAssertFinite: OpAssertFinite(in); break;
        default:
            ThrowErrorF(ErrClass::kRuntime, "the virtual machine encountered unknown opcode %u", in.op);
    }
}

const float* VirtualMachine::Forward(int32_t token, int32_t position, std::vector<RmpFinding>* findings) {
    if (!prepared_) ThrowError(ErrClass::kRuntime, "the virtual machine was not prepared");
    if (position < 0 || static_cast<uint32_t>(position) >= kv_.n_ctx) {
        ThrowErrorF(ErrClass::kRuntime,
                    "position %d exceeds the compiled context length %u; start a new session or raise --ctx",
                    position, kv_.n_ctx);
    }
    regs_[token_reg_].ptr[0] = static_cast<float>(token);
    regs_[pos_reg_].ptr[0] = static_cast<float>(position);
    auto t0 = std::chrono::steady_clock::now();
    for (const auto& in : prog_.code) {
        instr_executed_++;
        ExecInstr(in, token, position, findings);
        if (static_cast<VmOp>(in.op) == VmOp::kHalt) break;
    }
    auto t1 = std::chrono::steady_clock::now();
    last_seconds_ = std::chrono::duration<double>(t1 - t0).count();
    return logits_ptr_;
}

Sampler::Sampler(SamplerConfig cfg) : cfg_(cfg) {
    uint64_t seed = cfg.seed;
    if (!cfg.deterministic || seed == 0) {
        uint64_t r = random::Uniform64();
        seed = cfg.deterministic ? (seed ? seed : 12345) : r;
    }
    rng_.seed(seed ? seed : 1);
}

int32_t Sampler::Greedy(const float* logits, uint32_t n) const {
    int32_t best = 0;
    float bv = -std::numeric_limits<float>::infinity();
    for (uint32_t i = 0; i < n; i++) {
        if (logits[i] > bv) {
            bv = logits[i];
            best = static_cast<int32_t>(i);
        }
    }
    return best;
}

int32_t Sampler::Sample(const float* logits, uint32_t n, const std::vector<int32_t>& history) {
    if (n == 0) ThrowError(ErrClass::kRuntime, "the logits vector is empty");
    std::vector<float> work(logits, logits + n);
    if (cfg_.repeat_penalty != 1.0f && cfg_.repeat_last_n > 0 && !history.empty()) {
        size_t start = history.size() > cfg_.repeat_last_n ? history.size() - cfg_.repeat_last_n : 0;
        std::unordered_set<int32_t> seen;
        for (size_t i = start; i < history.size(); i++) seen.insert(history[i]);
        for (int32_t id : seen) {
            if (id < 0 || static_cast<uint32_t>(id) >= n) continue;
            float v = work[static_cast<size_t>(id)];
            work[static_cast<size_t>(id)] = (v > 0.0f) ? (v / cfg_.repeat_penalty) : (v * cfg_.repeat_penalty);
        }
    }
    if (cfg_.temperature <= 0.0f) return Greedy(work.data(), n);

    std::vector<uint32_t> idx(n);
    for (uint32_t i = 0; i < n; i++) idx[i] = i;
    uint32_t k = cfg_.top_k;
    if (k == 0 || k > n) k = n;
    std::partial_sort(idx.begin(), idx.begin() + k, idx.end(),
                      [&](uint32_t a, uint32_t b) { return work[a] > work[b]; });
    idx.resize(k);
    if (cfg_.min_p > 0.0f && k > 0) {
        float top = work[idx[0]];
        float thresh = cfg_.min_p * top;
        size_t keep = 0;
        for (size_t i = 0; i < idx.size(); i++) {
            if (work[idx[i]] >= thresh) keep = i + 1;
        }
        if (keep > 0) idx.resize(keep);
    }
    float maxv = work[idx[0]];
    std::vector<float> probs(idx.size());
    double sum = 0.0;
    float t = cfg_.temperature;
    for (size_t i = 0; i < idx.size(); i++) {
        float e = std::exp((work[idx[i]] - maxv) / t);
        probs[i] = e;
        sum += e;
    }
    if (!(sum > 0.0) || !std::isfinite(sum)) return Greedy(work.data(), n);
    if (cfg_.top_p > 0.0f && cfg_.top_p < 1.0f) {
        double target = cfg_.top_p * sum;
        double acc = 0.0;
        size_t keep = idx.size();
        for (size_t i = 0; i < idx.size(); i++) {
            acc += probs[i];
            if (acc >= target) {
                keep = i + 1;
                break;
            }
        }
        if (keep > 0 && keep < idx.size()) {
            idx.resize(keep);
            probs.resize(keep);
            sum = 0.0;
            for (float p : probs) sum += p;
        }
    }
    std::uniform_real_distribution<double> dist(0.0, sum);
    double pick = dist(rng_);
    double acc = 0.0;
    for (size_t i = 0; i < probs.size(); i++) {
        acc += probs[i];
        if (pick <= acc) return static_cast<int32_t>(idx[i]);
    }
    return static_cast<int32_t>(idx.back());
}

}
namespace aip {

static void SecureWipeVec(std::vector<uint8_t>& v) {
    if (!v.empty()) SecureWipe::Do(v.data(), v.size());
    v.clear();
    v.shrink_to_fit();
}

static std::string ChunkTag(uint64_t index) {
    char buf[40];
    snprintf(buf, sizeof(buf), "weights/chunk/%llu", static_cast<unsigned long long>(index));
    return std::string(buf);
}

StreamingWeightProvider::StreamingWeightProvider(FileReader& fr, const ContainerHeader& h, const SectionEntry& weights,
                                                 Manifest man, SecureBytes weight_key,
                                                 std::array<uint8_t, 16> container_id, uint64_t cache_bytes,
                                                 RmpMonitor* rmp)
    : fr_(fr), header_(h), section_(weights), manifest_(std::move(man)), key_(std::move(weight_key)),
      cid_(container_id), rmp_(rmp) {
    layout_ = manifest_.ToLayout();
    chunk_plain_ = section_.chunk_plain;
    chunk_stored_ = section_.chunk_stored;
    chunk_count_ = section_.chunk_count;

    if (chunk_plain_ == 0 || chunk_plain_ > (64u << 20)) {
        ThrowErrorF(ErrClass::kFormat, "the container declares an impossible weight chunk size of %u bytes",
                    chunk_plain_);
    }
    if (chunk_stored_ < chunk_plain_ + BlockCipher::kTagBytes) {
        ThrowErrorF(ErrClass::kFormat,
                    "the container declares a stored chunk size of %u bytes which cannot hold %u plaintext bytes "
                    "plus a %zu byte authentication tag",
                    chunk_stored_, chunk_plain_, BlockCipher::kTagBytes);
    }
    uint64_t expected_chunks = (section_.plain_size + chunk_plain_ - 1) / chunk_plain_;
    if (section_.plain_size > 0 && chunk_count_ != expected_chunks) {
        ThrowErrorF(ErrClass::kFormat,
                    "the weight section declares %llu chunks but %llu plaintext bytes require %llu",
                    static_cast<unsigned long long>(chunk_count_), static_cast<unsigned long long>(section_.plain_size),
                    static_cast<unsigned long long>(expected_chunks));
    }
    if (section_.plain_size != layout_.total_plain_bytes) {
        ThrowErrorF(ErrClass::kFormat,
                    "the manifest describes %llu plaintext weight bytes but the weight section holds %llu",
                    static_cast<unsigned long long>(layout_.total_plain_bytes),
                    static_cast<unsigned long long>(section_.plain_size));
    }
    if (key_.size() != BlockCipher::kKeyBytes) {
        ThrowErrorF(ErrClass::kCrypto, "the derived weight key is %zu bytes instead of %zu", key_.size(),
                    BlockCipher::kKeyBytes);
    }
    uint64_t end = section_.data_offset + section_.stored_size;
    if (end < section_.data_offset || end > fr_.Size()) {
        ThrowErrorF(ErrClass::kIoInput,
                    "the weight section claims to end at byte %llu but the container file is only %llu bytes long",
                    static_cast<unsigned long long>(end), static_cast<unsigned long long>(fr_.Size()));
    }

    cache_budget_ = std::max<uint64_t>(cache_bytes, 4ull * chunk_plain_ + 4096);
    cipher_buf_.resize(chunk_stored_);
    chunk_seen_.assign(static_cast<size_t>(chunk_count_), 0);
    uint64_t max_row = 1;
    for (const auto& s : layout_.slots) max_row = std::max(max_row, s.row_bytes);
    row_buf_.resize(static_cast<size_t>(max_row));
}

StreamingWeightProvider::~StreamingWeightProvider() {
    vec_cache_.clear();
    for (auto& e : lru_) e.data.Clear();
    lru_.clear();
    map_.clear();
    SecureWipeVec(cipher_buf_);
    SecureWipeVec(row_buf_);
    SecureWipeVec(chunk_seen_);
    key_.Clear();
}

const TensorSlot* StreamingWeightProvider::Slot(uint32_t id) const { return layout_.FindBySlot(id); }

size_t StreamingWeightProvider::SlotCount() const { return layout_.slots.size(); }

const TensorSlot* StreamingWeightProvider::RequireSlot(uint32_t slot_id) const {
    const TensorSlot* s = layout_.FindBySlot(slot_id);
    if (!s) {
        ThrowErrorF(ErrClass::kRuntime, "bytecode references weight slot %u which is not in the manifest", slot_id);
    }
    if (!s->present) {
        ThrowErrorF(ErrClass::kFormat, "weight tensor %s is required but was not stored in the container",
                    s->name.c_str());
    }
    if (s->row_bytes == 0 || s->type_size == 0 || s->block_size == 0) {
        ThrowErrorF(ErrClass::kFormat, "weight tensor %s has a degenerate geometry", s->name.c_str());
    }
    return s;
}

bool StreamingWeightProvider::DecryptChunkLocked(uint64_t index, SecureBytes& out_plain) {
    uint64_t base = index * static_cast<uint64_t>(chunk_plain_);
    if (base >= section_.plain_size) {
        ThrowErrorF(ErrClass::kRuntime, "weight chunk %llu is beyond the %llu byte plaintext stream",
                    static_cast<unsigned long long>(index),
                    static_cast<unsigned long long>(section_.plain_size));
    }
    uint64_t plain_len = chunk_plain_;
    if (base + plain_len > section_.plain_size) plain_len = section_.plain_size - base;
    size_t stored = static_cast<size_t>(plain_len) + BlockCipher::kTagBytes;
    if (stored > cipher_buf_.size()) {
        ThrowError(ErrClass::kInternal, "encrypted chunk does not fit the read buffer");
    }
    uint64_t file_off = section_.data_offset + index * static_cast<uint64_t>(chunk_stored_);
    if (file_off + stored > fr_.Size()) {
        ThrowErrorF(ErrClass::kIoInput,
                    "the container is truncated: weight chunk %llu needs bytes %llu to %llu but the file ends at %llu",
                    static_cast<unsigned long long>(index), static_cast<unsigned long long>(file_off),
                    static_cast<unsigned long long>(file_off + stored),
                    static_cast<unsigned long long>(fr_.Size()));
    }
    if (!fr_.ReadAt(file_off, cipher_buf_.data(), stored)) {
        ThrowErrorF(ErrClass::kIoInput, "failed to read weight chunk %llu at offset %llu: %s",
                    static_cast<unsigned long long>(index), static_cast<unsigned long long>(file_off),
                    LastOsError().c_str());
    }
    std::array<uint8_t, BlockCipher::kNonceBytes> nonce{};
    BlockCipher::BuildNonce(nonce, std::span<const uint8_t, 8>(section_.nonce_prefix, 8), section_.section_id, index);
    std::array<uint8_t, 40> aad{};
    BuildChunkAad(std::span<const uint8_t, 16>(cid_.data(), 16), section_.section_id, section_.purpose, index,
                  plain_len, aad);
    out_plain.resize(static_cast<size_t>(plain_len));
    size_t out_len = 0;
    bool ok = BlockCipher::Decrypt(std::span<const uint8_t>(key_.data(), key_.size()), nonce,
                                   std::span<const uint8_t>(aad.data(), aad.size()),
                                   std::span<const uint8_t>(cipher_buf_.data(), stored), out_plain.data(),
                                   out_plain.size(), out_len);
    if (!ok || out_len != static_cast<size_t>(plain_len)) {
        SecureWipe::Do(cipher_buf_.data(), cipher_buf_.size());
        out_plain.Clear();
        return false;
    }
    SecureWipe::Do(cipher_buf_.data(), cipher_buf_.size());
    bytes_decrypted_.fetch_add(stored, std::memory_order_relaxed);
    VerifyOrRecordChunk(index, std::span<const uint8_t>(out_plain.data(), out_plain.size()));
    return true;
}

void StreamingWeightProvider::VerifyOrRecordChunk(uint64_t index, std::span<const uint8_t> plain) {
    if (!rmp_ || !rmp_->Enabled() || !rmp_->Policy().verify_blocks) return;
    uint8_t d[32];
    KeyedHash::Plain(plain, d);
    std::string tag = ChunkTag(index);
    bool seen = index < chunk_seen_.size() && chunk_seen_[static_cast<size_t>(index)] != 0;
    if (!seen) {
        rmp_->RecordBlockDigest(tag, std::span<const uint8_t, 32>(d, 32));
        if (index < chunk_seen_.size()) chunk_seen_[static_cast<size_t>(index)] = 1;
        return;
    }
    if (!rmp_->VerifyBlockDigest(tag, std::span<const uint8_t, 32>(d, 32))) {
        ThrowErrorF(ErrClass::kIntegrity,
                    "weight chunk %llu changed on disk after it was first decrypted; the container has been "
                    "modified since this session started",
                    static_cast<unsigned long long>(index));
    }
}

void StreamingWeightProvider::FetchChunkLocked(uint64_t index) {
    SecureBytes plain;
    if (!DecryptChunkLocked(index, plain)) {
        ThrowErrorF(ErrClass::kAuth,
                    "weight chunk %llu failed its authentication tag: the container has been tampered with, is "
                    "truncated, or the password is wrong",
                    static_cast<unsigned long long>(index));
    }
    uint64_t sz = plain.size();
    CacheEntry e;
    e.index = index;
    e.data = std::move(plain);
    lru_.push_front(std::move(e));
    map_[index] = lru_.begin();
    cache_used_ += sz;
    EvictToLocked(cache_budget_);
}

void StreamingWeightProvider::EvictToLocked(uint64_t target_bytes) {
    while (cache_used_ > target_bytes && lru_.size() > 1) {
        CacheEntry& back = lru_.back();
        uint64_t sz = back.data.size();
        map_.erase(back.index);
        back.data.Clear();
        lru_.pop_back();
        cache_used_ -= sz;
    }
}

const uint8_t* StreamingWeightProvider::EnsureRangeLocked(uint64_t plain_off, size_t len) {
    if (len == 0) return nullptr;
    if (plain_off > section_.plain_size || len > section_.plain_size - plain_off) {
        ThrowErrorF(ErrClass::kRuntime,
                    "internal request for weight bytes %llu to %llu outside the %llu byte plaintext stream",
                    static_cast<unsigned long long>(plain_off), static_cast<unsigned long long>(plain_off + len),
                    static_cast<unsigned long long>(section_.plain_size));
    }
    uint64_t index = plain_off / chunk_plain_;
    uint64_t off = plain_off - index * chunk_plain_;
    if (off + len > chunk_plain_) {
        ThrowError(ErrClass::kInternal, "weight range crosses a chunk boundary");
    }
    auto it = map_.find(index);
    if (it != map_.end()) {
        lru_.splice(lru_.begin(), lru_, it->second);
        return it->second->data.data() + off;
    }
    FetchChunkLocked(index);
    it = map_.find(index);
    if (it == map_.end()) ThrowError(ErrClass::kInternal, "weight chunk vanished from the cache after decryption");
    return it->second->data.data() + off;
}

void StreamingWeightProvider::CopyRangeLocked(uint64_t plain_off, void* dst, size_t n) {
    uint8_t* d = static_cast<uint8_t*>(dst);
    uint64_t pos = plain_off;
    size_t left = n;
    while (left > 0) {
        uint64_t index = pos / chunk_plain_;
        uint64_t off = pos - index * chunk_plain_;
        size_t take = static_cast<size_t>(std::min<uint64_t>(left, chunk_plain_ - off));
        const uint8_t* p = EnsureRangeLocked(pos, take);
        memcpy(d, p, take);
        d += take;
        pos += take;
        left -= take;
    }
}

void StreamingWeightProvider::ReadRaw(uint32_t slot_id, uint64_t byte_off, void* dst, size_t n) {
    const TensorSlot* s = RequireSlot(slot_id);
    if (n == 0) return;
    if (byte_off < s->dst_offset) {
        ThrowErrorF(ErrClass::kRuntime, "byte offset %llu is before tensor %s",
                    static_cast<unsigned long long>(byte_off), s->name.c_str());
    }
    if (byte_off - s->dst_offset > s->dst_size || n > s->dst_size - (byte_off - s->dst_offset)) {
        ThrowErrorF(ErrClass::kRuntime, "read of %zu bytes at offset %llu runs past the end of tensor %s", n,
                    static_cast<unsigned long long>(byte_off), s->name.c_str());
    }
    std::lock_guard<std::mutex> lock(cache_mu_);
    CopyRangeLocked(byte_off, dst, n);
}

void StreamingWeightProvider::ReadRowRaw(uint32_t slot_id, uint64_t row, uint8_t* dst) {
    const TensorSlot* s = RequireSlot(slot_id);
    if (row >= s->n_rows) {
        ThrowErrorF(ErrClass::kRuntime, "row %llu is outside tensor %s which has %llu rows",
                    static_cast<unsigned long long>(row), s->name.c_str(),
                    static_cast<unsigned long long>(s->n_rows));
    }
    std::lock_guard<std::mutex> lock(cache_mu_);
    CopyRangeLocked(s->dst_offset + row * s->row_bytes, dst, static_cast<size_t>(s->row_bytes));
}

void StreamingWeightProvider::ReadRow(uint32_t slot_id, uint64_t row, float* out) {
    const TensorSlot* s = RequireSlot(slot_id);
    if (row >= s->n_rows) {
        ThrowErrorF(ErrClass::kRuntime, "row %llu is outside tensor %s which has %llu rows",
                    static_cast<unsigned long long>(row), s->name.c_str(),
                    static_cast<unsigned long long>(s->n_rows));
    }
    thread_local std::vector<uint8_t> scratch;
    if (scratch.size() < s->row_bytes) scratch.resize(static_cast<size_t>(s->row_bytes));
    {
        std::lock_guard<std::mutex> lock(cache_mu_);
        CopyRangeLocked(s->dst_offset + row * s->row_bytes, scratch.data(), static_cast<size_t>(s->row_bytes));
    }
    if (!quant::DequantizeRowChecked(s->type_id, scratch.data(), scratch.size(), out, s->row_elems)) {
        ThrowErrorF(ErrClass::kFormat,
                    "tensor %s uses storage type %u whose block layout does not divide its %llu element rows",
                    s->name.c_str(), s->type_id, static_cast<unsigned long long>(s->row_elems));
    }
    rows_served_.fetch_add(1, std::memory_order_relaxed);
}

const float* StreamingWeightProvider::Vector(uint32_t slot_id) {
    std::lock_guard<std::mutex> lock(cache_mu_);
    auto cached = vec_cache_.find(slot_id);
    if (cached != vec_cache_.end()) return cached->second.data();
    const TensorSlot* s = RequireSlot(slot_id);
    if (s->n_rows != 1) {
        ThrowErrorF(ErrClass::kRuntime,
                    "bytecode asked for tensor %s as a single vector but it stores %llu rows", s->name.c_str(),
                    static_cast<unsigned long long>(s->n_rows));
    }
    if (s->row_elems > (4u << 20)) {
        ThrowErrorF(ErrClass::kMemory, "tensor %s has %llu elements which is too large to cache as a vector",
                    s->name.c_str(), static_cast<unsigned long long>(s->row_elems));
    }
    std::vector<float> v(static_cast<size_t>(s->row_elems));
    CopyRangeLocked(s->dst_offset, row_buf_.data(), static_cast<size_t>(s->row_bytes));
    if (!quant::DequantizeRowChecked(s->type_id, row_buf_.data(), s->row_bytes, v.data(), s->row_elems)) {
        ThrowErrorF(ErrClass::kFormat, "tensor %s uses storage type %u which cannot be dequantized",
                    s->name.c_str(), s->type_id);
    }
    auto inserted = vec_cache_.emplace(slot_id, std::move(v));
    return inserted.first->second.data();
}

void StreamingWeightProvider::SlotDigest(uint32_t slot_id, uint8_t out[32]) {
    const TensorSlot* s = RequireSlot(slot_id);
    memcpy(out, s->digest, 32);
}

void StreamingWeightProvider::VerifySlotDigestLocked(uint64_t rotation) {
    std::vector<const TensorSlot*> small;
    for (const auto& s : layout_.slots) {
        if (s.present && s.total_bytes > 0 && s.total_bytes <= 512u * 1024u) small.push_back(&s);
    }
    if (small.empty()) return;
    const TensorSlot* s = small[static_cast<size_t>(rotation % small.size())];
    std::vector<uint8_t> buf(static_cast<size_t>(s->total_bytes));
    CopyRangeLocked(s->dst_offset, buf.data(), buf.size());
    uint8_t d[32];
    KeyedHash::Plain(std::span<const uint8_t>(buf.data(), buf.size()), d);
    SecureWipeVec(buf);
    if (memcmp(d, s->digest, 32) != 0) {
        ThrowErrorF(ErrClass::kIntegrity,
                    "the decrypted bytes of tensor %s no longer match the digest recorded when the container was "
                    "created",
                    s->name.c_str());
    }
    if (rmp_ && rmp_->Enabled()) {
        rmp_->RecordBlockDigest(s->name, std::span<const uint8_t, 32>(d, 32));
    }
}

void StreamingWeightProvider::IntegrityTick() {
    if (!rmp_ || !rmp_->Enabled()) return;
    const RmpPolicy& pol = rmp_->Policy();
    if (!pol.periodic_integrity) return;
    std::lock_guard<std::mutex> lock(cache_mu_);
    if (chunk_count_ > 0) {
        uint64_t index = tick_counter_ % chunk_count_;
        SecureBytes plain;
        if (!DecryptChunkLocked(index, plain)) {
            ThrowErrorF(ErrClass::kIntegrity,
                        "periodic verification of weight chunk %llu failed its authentication tag; the container "
                        "was modified while in use",
                        static_cast<unsigned long long>(index));
        }
        plain.Clear();
    }
    if ((tick_counter_ % 4) == 0) VerifySlotDigestLocked(tick_counter_ / 4);
    tick_counter_++;
}

}
namespace aip {

struct Blake2Stream {
    crypto_generichash_blake2b_state st{};
    Blake2Stream() { crypto_generichash_blake2b_init(&st, nullptr, 0, 32); }
    void Update(const void* p, size_t n) {
        if (n > 0) crypto_generichash_blake2b_update(&st, static_cast<const unsigned char*>(p), n);
    }
    void Final(uint8_t out[32]) { crypto_generichash_blake2b_final(&st, out, 32); }
};

void HashFileDigest(FileReader& fr, uint64_t bytes, uint8_t out[32], bool show_progress) {
    Blake2Stream h;
    std::vector<uint8_t> buf(1u << 20);
    Progress prog("hashing source", bytes, show_progress);
    uint64_t pos = 0;
    while (pos < bytes) {
        size_t want = static_cast<size_t>(std::min<uint64_t>(bytes - pos, buf.size()));
        if (!fr.ReadAt(pos, buf.data(), want)) {
            ThrowErrorF(ErrClass::kIoInput, "failed to read byte %llu of the source model: %s",
                        static_cast<unsigned long long>(pos), LastOsError().c_str());
        }
        h.Update(buf.data(), want);
        pos += want;
        prog.Set(pos);
    }
    prog.Finish();
    h.Final(out);
    SecureWipe::Do(buf.data(), buf.size());
}

std::vector<uint8_t> CanonicalHeaderCore(const ContainerHeader& h) {
    ByteWriter w;
    w.U32(h.magic_a);
    w.U32(h.magic_b);
    w.U32(h.format_version);
    w.U32(h.header_size);
    w.U64(h.flags);
    w.Raw(h.container_id, 16);
    w.U32(h.kdf_alg);
    w.U32(h.kdf_reserved);
    w.U64(h.kdf_opslimit);
    w.U64(h.kdf_memlimit);
    w.Raw(h.kdf_salt, 16);
    w.U32(h.cipher_alg);
    w.U32(h.chunk_plain);
    w.U64(h.section_count);
    w.U64(h.section_table_offset);
    w.U64(h.section_table_size);
    w.I64(h.created_unix);
    w.U32(h.product_major);
    w.U32(h.product_minor);
    w.U32(h.product_patch);
    w.U32(h.abi_flags);
    return w.Take();
}

class SectionSink {
public:
    SectionSink(AtomicFileWriter& out, uint32_t section_id, uint32_t purpose, uint32_t chunk_plain,
                std::span<const uint8_t, 8> nonce_prefix, std::span<const uint8_t> key,
                std::span<const uint8_t, 16> container_id, std::string what)
        : out_(out), section_id_(section_id), purpose_(purpose), chunk_plain_(chunk_plain), what_(std::move(what)) {
        memcpy(nonce_prefix_.data(), nonce_prefix.data(), 8);
        memcpy(cid_.data(), container_id.data(), 16);
        key_.assign(key.data(), key.data() + key.size());
        buf_.resize(chunk_plain_);
        cipher_.resize(static_cast<size_t>(chunk_plain_) + BlockCipher::kTagBytes);
    }

    ~SectionSink() {
        SecureWipe::Do(key_.data(), key_.size());
        SecureWipe::Do(buf_.data(), buf_.size());
        SecureWipe::Do(cipher_.data(), cipher_.size());
    }

    SectionSink(const SectionSink&) = delete;
    SectionSink& operator=(const SectionSink&) = delete;

    void Write(const void* p, size_t n) {
        const uint8_t* src = static_cast<const uint8_t*>(p);
        while (n > 0) {
            size_t space = buf_.size() - filled_;
            size_t take = std::min(space, n);
            memcpy(buf_.data() + filled_, src, take);
            filled_ += take;
            src += take;
            n -= take;
            if (filled_ == buf_.size()) Flush();
        }
    }

    void Finish(SectionEntry& entry, uint64_t data_offset) {
        Flush();
        memset(&entry, 0, sizeof(entry));
        entry.section_id = section_id_;
        entry.purpose = purpose_;
        entry.data_offset = data_offset;
        entry.plain_size = plain_total_;
        entry.stored_size = stored_total_;
        entry.chunk_plain = chunk_plain_;
        entry.chunk_stored = chunk_plain_ + static_cast<uint32_t>(BlockCipher::kTagBytes);
        entry.chunk_count = chunk_index_;
        memcpy(entry.nonce_prefix, nonce_prefix_.data(), 8);
        entry.key_slot = section_id_;
        digest_.Final(entry.digest);
        finished_ = true;
    }

    uint64_t PlainBytes() const { return plain_total_; }
    uint64_t Chunks() const { return chunk_index_; }

private:
    void Flush() {
        if (filled_ == 0) return;
        std::array<uint8_t, BlockCipher::kNonceBytes> nonce{};
        BlockCipher::BuildNonce(nonce, std::span<const uint8_t, 8>(nonce_prefix_.data(), 8), section_id_,
                                chunk_index_);
        std::array<uint8_t, 40> aad{};
        BuildChunkAad(std::span<const uint8_t, 16>(cid_.data(), 16), section_id_, purpose_, chunk_index_, filled_,
                      aad);
        size_t out_len = 0;
        if (!BlockCipher::Encrypt(std::span<const uint8_t>(key_.data(), key_.size()), nonce,
                                  std::span<const uint8_t>(aad.data(), aad.size()),
                                  std::span<const uint8_t>(buf_.data(), filled_), cipher_.data(), cipher_.size(),
                                  out_len)) {
            ThrowErrorF(ErrClass::kCrypto, "encryption of %s chunk %llu failed", what_.c_str(),
                        static_cast<unsigned long long>(chunk_index_));
        }
        if (out_len != filled_ + BlockCipher::kTagBytes) {
            ThrowError(ErrClass::kInternal, "cipher produced an unexpected length");
        }
        digest_.Update(buf_.data(), filled_);
        SecureWipe::Do(buf_.data(), filled_);
        if (!out_.Write(cipher_.data(), out_len)) {
            ThrowErrorF(ErrClass::kIoOutput, "failed to write %s chunk %llu: %s", what_.c_str(),
                        static_cast<unsigned long long>(chunk_index_), LastOsError().c_str());
        }
        SecureWipe::Do(cipher_.data(), out_len);
        stored_total_ += out_len;
        plain_total_ += filled_;
        chunk_index_++;
        filled_ = 0;
    }

    AtomicFileWriter& out_;
    uint32_t section_id_;
    uint32_t purpose_;
    uint32_t chunk_plain_;
    std::string what_;
    std::array<uint8_t, 8> nonce_prefix_{};
    std::array<uint8_t, 16> cid_{};
    std::vector<uint8_t> key_;
    std::vector<uint8_t> buf_;
    std::vector<uint8_t> cipher_;
    size_t filled_ = 0;
    uint64_t chunk_index_ = 0;
    uint64_t stored_total_ = 0;
    uint64_t plain_total_ = 0;
    Blake2Stream digest_;
    bool finished_ = false;
};

class RowReader {
public:
    RowReader(GgufReaderAccess& acc, size_t window_bytes) : acc_(acc), window_(window_bytes) {}

    const uint8_t* Row(const GgufTensorInfo& t, uint64_t row) {
        uint64_t rb = t.n_bytes / t.n_rows;
        if (rb == 0) ThrowErrorF(ErrClass::kFormat, "tensor %s has zero byte rows", t.name.c_str());
        if (cur_ == &t && row >= first_ && row < first_ + rows_) {
            return buf_.data() + static_cast<size_t>((row - first_) * rb);
        }
        uint64_t cap = std::max<uint64_t>(1, window_ / rb);
        uint64_t want = std::min<uint64_t>(cap, t.n_rows - row);
        if (want == 0) {
            ThrowErrorF(ErrClass::kFormat, "row %llu is outside tensor %s", static_cast<unsigned long long>(row),
                        t.name.c_str());
        }
        size_t bytes = static_cast<size_t>(want * rb);
        if (buf_.size() < bytes) buf_.resize(bytes);
        if (!acc_.ReadTensorRows(t, row, want, buf_.data())) {
            ThrowErrorF(ErrClass::kIoInput, "failed to read %llu rows of tensor %s at row %llu: %s",
                        static_cast<unsigned long long>(want), t.name.c_str(),
                        static_cast<unsigned long long>(row), LastOsError().c_str());
        }
        cur_ = &t;
        first_ = row;
        rows_ = want;
        return buf_.data();
    }

    ~RowReader() { SecureWipe::Do(buf_.data(), buf_.size()); }

private:
    GgufReaderAccess& acc_;
    size_t window_;
    const GgufTensorInfo* cur_ = nullptr;
    uint64_t first_ = 0;
    uint64_t rows_ = 0;
    std::vector<uint8_t> buf_;
};

static bool PermutationIsValid(const std::vector<uint32_t>& perm, uint32_t n) {
    if (perm.size() != n) return false;
    std::vector<uint8_t> seen(n, 0);
    for (uint32_t v : perm) {
        if (v >= n) return false;
        if (seen[v]) return false;
        seen[v] = 1;
    }
    return true;
}

static void ColumnAxisElementMap(const AxisPlan& ax, uint32_t length, bool head_axis, uint32_t head_units,
                                 const std::vector<uint32_t>& perm, bool with_signs, std::vector<uint32_t>& idx,
                                 std::vector<int8_t>& sign) {
    idx.assign(length, 0);
    sign.assign(length, 1);
    if (!ax.enabled || ax.granularity == 0) {
        for (uint32_t i = 0; i < length; i++) idx[i] = i;
        return;
    }
    uint32_t G = ax.granularity;
    if (length % G != 0) {
        for (uint32_t i = 0; i < length; i++) idx[i] = i;
        return;
    }
    uint32_t groups = length / G;
    (void)head_units;
    for (uint32_t g = 0; g < groups; g++) {
        uint32_t sg = (g < perm.size()) ? perm[g] : g;
        if (sg >= groups) sg = g;
        for (uint32_t k = 0; k < G; k++) {
            idx[g * G + k] = sg * G + k;
            if (with_signs && g < ax.signs.size()) sign[g * G + k] = ax.signs[g];
        }
    }
    (void)head_axis;
}

static void FoldColumnMap(std::vector<uint32_t>& idx, std::vector<int8_t>& sign, const std::vector<uint32_t>& outer_idx,
                          const std::vector<int8_t>& outer_sign) {
    size_t n = idx.size();
    if (outer_idx.size() != n || outer_sign.size() != n) return;
    std::vector<uint32_t> ni(n);
    std::vector<int8_t> ns(n);
    for (size_t q = 0; q < n; q++) {
        uint32_t inner = idx[q];
        if (inner >= n) inner = static_cast<uint32_t>(q);
        ni[q] = outer_idx[inner];
        ns[q] = static_cast<int8_t>(outer_sign[inner] * sign[q]);
    }
    idx.swap(ni);
    sign.swap(ns);
}

static void BuildColumnMap(const TensorSlot& s, const TransformPlan& plan, std::vector<uint32_t>& idx,
                           std::vector<int8_t>& sign) {
    uint32_t len = static_cast<uint32_t>(s.row_elems);
    idx.assign(len, 0);
    sign.assign(len, 1);
    for (uint32_t i = 0; i < len; i++) idx[i] = i;
    std::vector<uint32_t> ai;
    std::vector<int8_t> as;
    if (s.transform_mask & kTfResidualCol) {
        ColumnAxisElementMap(plan.residual, len, false, 0, plan.residual.perm, true, ai, as);
        FoldColumnMap(idx, sign, ai, as);
    }
    if (s.transform_mask & kTfResidualColUnsigned) {
        ColumnAxisElementMap(plan.residual, len, false, 0, plan.residual.perm, false, ai, as);
        FoldColumnMap(idx, sign, ai, as);
    }
    if (s.transform_mask & kTfFfnCol) {
        ColumnAxisElementMap(plan.ffn, len, false, 0, plan.ffn.perm, false, ai, as);
        FoldColumnMap(idx, sign, ai, as);
    }
    if (s.transform_mask & kTfHeadColQ) {
        ColumnAxisElementMap(plan.head, len, true, plan.head.length, plan.head.perm, false, ai, as);
        FoldColumnMap(idx, sign, ai, as);
    }
    if (s.transform_mask & kTfHeadColKv) {
        ColumnAxisElementMap(plan.head, len, true, plan.head.kv_groups, plan.head.kv_perm, false, ai, as);
        FoldColumnMap(idx, sign, ai, as);
    }
}

static const TensorSlot* FirstSlotWithRole(const WeightLayout& layout, TensorRole::Kind role) {
    for (const auto& s : layout.slots) {
        if (s.role == role && s.present) return &s;
    }
    return nullptr;
}

bool WeightTransformEngine::VerifyEquivalence(const ModelSpec& spec, const WeightLayout& layout,
                                              const TransformPlan& plan, GgufReaderAccess& src, std::string& err) {
    err.clear();
    if (!plan.enabled) return true;
    if (plan.residual.enabled && !PermutationIsValid(plan.residual.perm, plan.residual.group_count)) {
        err = "the residual axis permutation is not a bijection";
        return false;
    }
    if (plan.residual.enabled && plan.residual.signs.size() != plan.residual.group_count) {
        err = "the residual axis sign vector does not match its group count";
        return false;
    }
    if (plan.ffn.enabled && !PermutationIsValid(plan.ffn.perm, plan.ffn.group_count)) {
        err = "the feed forward axis permutation is not a bijection";
        return false;
    }
    if (plan.vocab.enabled && !PermutationIsValid(plan.vocab.perm, plan.vocab.group_count)) {
        err = "the vocabulary axis permutation is not a bijection";
        return false;
    }
    if (plan.head.enabled) {
        if (!PermutationIsValid(plan.head.perm, plan.head.length)) {
            err = "the head axis permutation is not a bijection";
            return false;
        }
        if (!PermutationIsValid(plan.head.kv_perm, plan.head.kv_groups)) {
            err = "the key/value head permutation is not a bijection";
            return false;
        }
    }

    const TensorRole::Kind roles[] = {TensorRole::kTokenEmbd, TensorRole::kOutputWeight, TensorRole::kOutputNorm,
                                      TensorRole::kAttnNorm,  TensorRole::kAttnQ,        TensorRole::kAttnK,
                                      TensorRole::kAttnV,     TensorRole::kAttnQBias,    TensorRole::kAttnKBias,
                                      TensorRole::kAttnVBias, TensorRole::kAttnOut,      TensorRole::kFfnNorm,
                                      TensorRole::kFfnGate,   TensorRole::kFfnUp,        TensorRole::kFfnDown};
    std::mt19937_64 rng(random::Uniform64() | 1ull);
    size_t tensors_checked = 0;
    size_t rows_checked = 0;
    for (TensorRole::Kind role : roles) {
        const TensorSlot* s = FirstSlotWithRole(layout, role);
        if (!s || s->transform_mask == 0) continue;
        const GgufTensorInfo* t = src.Info().FindTensor(s->name);
        if (!t) {
            err = "tensor " + s->name + " disappeared from the source model during verification";
            return false;
        }
        if (t->n_rows != s->n_rows || t->row_elems != s->row_elems) {
            err = "tensor " + s->name + " changed shape during verification";
            return false;
        }
        std::vector<uint32_t> idx;
        std::vector<int8_t> csign;
        BuildColumnMap(*s, plan, idx, csign);
        std::vector<uint8_t> raw(static_cast<size_t>(s->row_bytes));
        std::vector<uint8_t> stored(static_cast<size_t>(s->row_bytes));
        std::vector<float> a(static_cast<size_t>(s->row_elems));
        std::vector<float> b(static_cast<size_t>(s->row_elems));
        std::vector<float> x(static_cast<size_t>(s->row_elems));
        std::vector<float> xm(static_cast<size_t>(s->row_elems));
        uint32_t samples = (s->n_rows > 4) ? 3 : 1;
        for (uint32_t q = 0; q < samples; q++) {
            uint64_t dst_row = 0;
            if (q == 1) dst_row = s->n_rows - 1;
            if (q >= 2) dst_row = std::uniform_int_distribution<uint64_t>(0, s->n_rows - 1)(rng);
            uint64_t src_row = MapRow(*s, plan, dst_row);
            if (src_row >= s->n_rows) {
                err = FormatErrorF("the transform maps row %llu of %s to the out of range row %llu",
                                   static_cast<unsigned long long>(dst_row), s->name.c_str(),
                                   static_cast<unsigned long long>(src_row));
                return false;
            }
            if (!src.ReadTensorRows(*t, src_row, 1, raw.data())) {
                err = "failed to read the source row of " + s->name + " during verification";
                return false;
            }
            TransformRowBytes(*s, plan, dst_row, raw.data(), stored.data());
            if (!quant::DequantizeRowChecked(s->type_id, raw.data(), raw.size(), a.data(), s->row_elems) ||
                !quant::DequantizeRowChecked(s->type_id, stored.data(), stored.size(), b.data(), s->row_elems)) {
                err = "tensor " + s->name + " could not be dequantized during verification";
                return false;
            }
            int8_t rs = RowSign(*s, plan, dst_row);
            for (uint64_t j = 0; j < s->row_elems; j++) {
                double expect = static_cast<double>(rs) * static_cast<double>(csign[j]) *
                                static_cast<double>(a[idx[j]]);
                double got = static_cast<double>(b[j]);
                double scale = std::max(1.0, std::fabs(expect));
                if (std::fabs(expect - got) > 1e-5 * scale) {
                    err = FormatErrorF(
                        "the transform of %s row %llu is not reversible: element %llu became %.9g instead of %.9g",
                        s->name.c_str(), static_cast<unsigned long long>(dst_row),
                        static_cast<unsigned long long>(j), got, expect);
                    return false;
                }
            }
            for (uint64_t j = 0; j < s->row_elems; j++) {
                uint32_t v = static_cast<uint32_t>(rng() & 0xFFFFFFFFull);
                x[j] = (static_cast<float>(v) / 2147483648.0f) - 1.0f;
            }
            for (uint64_t j = 0; j < s->row_elems; j++) {
                xm[j] = static_cast<float>(csign[j]) * x[idx[j]];
            }
            double y1 = 0.0, y2 = 0.0;
            for (uint64_t j = 0; j < s->row_elems; j++) {
                y1 += static_cast<double>(a[j]) * static_cast<double>(x[j]);
                y2 += static_cast<double>(b[j]) * static_cast<double>(xm[j]);
            }
            double y1_expect = static_cast<double>(rs) * y1;
            double tol = 1e-4 * std::max(1.0, std::fabs(y1_expect));
            if (std::fabs(y1_expect - y2) > tol) {
                err = FormatErrorF(
                    "the transform of %s row %llu changes the matrix vector product: %.9g became %.9g where %.9g "
                    "was expected",
                    s->name.c_str(), static_cast<unsigned long long>(dst_row), y1, y2, y1_expect);
                return false;
            }
            rows_checked++;
        }
        tensors_checked++;
    }
    if (tensors_checked == 0) {
        err = "the transform plan is enabled but no stored tensor carries a transform mask";
        return false;
    }
    (void)spec;
    (void)rows_checked;
    return true;
}

std::vector<uint8_t> RmpRecord::Serialize() const {
    ByteWriter w;
    w.U32(kRmpRecordMagic);
    w.U32(kRmpRecordVersion);
    w.U8(policy.enabled ? 1 : 0);
    w.U8(policy.anti_debug ? 1 : 0);
    w.U8(policy.periodic_integrity ? 1 : 0);
    w.U8(policy.verify_blocks ? 1 : 0);
    w.U8(policy.env_scan ? 1 : 0);
    w.U32(policy.probe_interval_tokens);
    w.U32(policy.max_violations);
    w.U8(policy.allow_ptrace_self ? 1 : 0);
    w.U32(anti_debug_available);
    w.Str(platform_name);
    w.Raw(header_core_digest, 32);
    w.Raw(manifest_digest, 32);
    w.U32(bytecode_present);
    w.Raw(bytecode_digest, 32);
    w.Raw(weights_digest, 32);
    w.U64(weights_plain_bytes);
    w.U64(weights_chunk_count);
    w.Raw(container_id.data(), 16);
    return w.Take();
}

bool RmpRecord::Deserialize(std::span<const uint8_t> data, RmpRecord& out, std::string& err) {
    ByteReader r(data);
    uint32_t magic = 0, version = 0;
    if (!r.U32(magic) || magic != kRmpRecordMagic) {
        err = "the runtime protection record does not carry the AIProtect magic";
        return false;
    }
    if (!r.U32(version) || version != kRmpRecordVersion) {
        err = FormatErrorF("runtime protection record version %u is not supported by this build (%u)", version,
                           kRmpRecordVersion);
        return false;
    }
    uint8_t b = 0;
    if (!r.U8(b)) return false;
    out.policy.enabled = b != 0;
    if (!r.U8(b)) return false;
    out.policy.anti_debug = b != 0;
    if (!r.U8(b)) return false;
    out.policy.periodic_integrity = b != 0;
    if (!r.U8(b)) return false;
    out.policy.verify_blocks = b != 0;
    if (!r.U8(b)) return false;
    out.policy.env_scan = b != 0;
    if (!r.U32(out.policy.probe_interval_tokens)) return false;
    if (!r.U32(out.policy.max_violations)) return false;
    if (!r.U8(b)) return false;
    out.policy.allow_ptrace_self = b != 0;
    if (!r.U32(out.anti_debug_available)) return false;
    if (!r.Str(out.platform_name, 128)) return false;
    if (!r.Raw(out.header_core_digest, 32)) return false;
    if (!r.Raw(out.manifest_digest, 32)) return false;
    if (!r.U32(out.bytecode_present)) return false;
    if (!r.Raw(out.bytecode_digest, 32)) return false;
    if (!r.Raw(out.weights_digest, 32)) return false;
    if (!r.U64(out.weights_plain_bytes)) return false;
    if (!r.U64(out.weights_chunk_count)) return false;
    if (!r.Raw(out.container_id.data(), 16)) return false;
    if (!r.Ok() || r.Remaining() != 0) {
        err = FormatErrorF("the runtime protection record carries %zu trailing bytes", r.Remaining());
        return false;
    }
    return true;
}


static std::string JoinStrings(const std::vector<std::string>& v, const std::string& sep) {
    std::string out;
    for (size_t i = 0; i < v.size(); i++) {
        if (i) out += sep;
        out += v[i];
    }
    return out;
}

static std::string JoinDims(const std::vector<uint64_t>& d) {
    std::string out;
    for (size_t i = 0; i < d.size(); i++) {
        if (i) out += ", ";
        out += std::to_string(d[i]);
    }
    return out;
}

static void VerifyWrittenContainer(const std::string& path, const std::string& password,
                                   std::span<const uint8_t, 16> cid, const std::vector<SectionEntry>& table,
                                   const Manifest& man, const WeightLayout& layout, const TransformPlan& plan,
                                   FileReader& src_fr, const GgufInfo& g,
                                   const std::vector<const GgufTensorInfo*>& sources, bool have_program,
                                   const std::vector<uint8_t>& program_blob) {
    std::string err;
    FileReader fr;
    if (!fr.Open(path, err)) {
        ThrowErrorF(ErrClass::kIoOutput, "the container that was just written cannot be re-opened: %s", err.c_str());
    }
    ContainerReader::OpenResult opened = ContainerReader::OpenHeader(path, fr, err);
    if (!opened.header_ok) {
        ThrowErrorF(ErrClass::kFormat, "the container that was just written cannot be re-opened: %s", err.c_str());
    }
    KdfParams kp;
    kp.alg = opened.header.kdf_alg;
    kp.opslimit = opened.header.kdf_opslimit;
    kp.memlimit_kib = opened.header.kdf_memlimit;
    memcpy(kp.salt.data(), opened.header.kdf_salt, 16);
    DerivedKey master = KdfDerive(password, kp);
    KeyRing keys = KeyRing::Derive(master.key, cid);
    master.Clear();

    if (memcmp(opened.header.container_id, cid.data(), 16) != 0) {
        ThrowError(ErrClass::kIntegrity, "the container id read back does not match the one that was written");
    }
    if (!ContainerReader::VerifyHeaderMac(opened.header, opened.sections, keys.integrity.Span())) {
        keys.Clear();
        ThrowError(ErrClass::kIntegrity, "the freshly written container fails its own header authentication");
    }
    if (opened.sections.size() != table.size()) {
        keys.Clear();
        ThrowErrorF(ErrClass::kFormat, "the written container holds %zu sections instead of %zu",
                    opened.sections.size(), table.size());
    }
    for (size_t i = 0; i < table.size(); i++) {
        if (memcmp(&opened.sections[i], &table[i], sizeof(SectionEntry)) != 0) {
            keys.Clear();
            ThrowErrorF(ErrClass::kIntegrity, "section table entry %zu read back differently from what was written",
                        i);
        }
    }

    const SectionEntry* mse = ContainerReader::FindSection(opened.sections, SectionPurpose::kManifest);
    if (!mse) {
        keys.Clear();
        ThrowError(ErrClass::kFormat, "the written container has no manifest section");
    }
    SecureBytes mblob;
    if (!ContainerReader::ReadSection(fr, opened.header, *mse, keys.manifest.Span(), cid, mblob, err)) {
        keys.Clear();
        ThrowErrorF(ErrClass::kAuth, "the manifest of the freshly written container cannot be decrypted: %s",
                    err.c_str());
    }
    Manifest back;
    if (!Manifest::Deserialize(mblob.Span(), back, err)) {
        keys.Clear();
        ThrowErrorF(ErrClass::kFormat, "the manifest of the freshly written container cannot be parsed: %s",
                    err.c_str());
    }
    mblob.Clear();
    if (back.weights_plain_bytes != man.weights_plain_bytes || back.tensors.size() != man.tensors.size()) {
        keys.Clear();
        ThrowError(ErrClass::kIntegrity, "the manifest read back describes a different weight stream");
    }
    for (size_t i = 0; i < back.tensors.size(); i++) {
        if (back.tensors[i].name != man.tensors[i].name ||
            back.tensors[i].stream_offset != man.tensors[i].stream_offset ||
            back.tensors[i].total_bytes != man.tensors[i].total_bytes ||
            back.tensors[i].transform_mask != man.tensors[i].transform_mask ||
            memcmp(back.tensors[i].digest, man.tensors[i].digest, 32) != 0) {
            keys.Clear();
            ThrowErrorF(ErrClass::kIntegrity, "tensor %zu read back differently from what was written", i);
        }
    }
    if (back.transform.enabled != man.transform.enabled ||
        back.transform.residual.perm != man.transform.residual.perm ||
        back.transform.residual.signs != man.transform.residual.signs ||
        back.transform.ffn.perm != man.transform.ffn.perm || back.transform.head.perm != man.transform.head.perm ||
        back.transform.head.kv_perm != man.transform.head.kv_perm ||
        back.transform.vocab.perm != man.transform.vocab.perm) {
        keys.Clear();
        ThrowError(ErrClass::kIntegrity, "the weight transform read back differs from the one that was applied");
    }

    if (have_program) {
        const SectionEntry* bse = ContainerReader::FindSection(opened.sections, SectionPurpose::kBytecode);
        if (!bse) {
            keys.Clear();
            ThrowError(ErrClass::kFormat, "the written container has no bytecode section");
        }
        SecureBytes bblob;
        if (!ContainerReader::ReadSection(fr, opened.header, *bse, keys.bytecode.Span(), cid, bblob, err)) {
            keys.Clear();
            ThrowErrorF(ErrClass::kAuth, "the bytecode of the freshly written container cannot be decrypted: %s",
                        err.c_str());
        }
        if (bblob.size() != program_blob.size() ||
            memcmp(bblob.data(), program_blob.data(), program_blob.size()) != 0) {
            keys.Clear();
            ThrowError(ErrClass::kIntegrity, "the bytecode read back differs from what was compiled");
        }
        VmProgram back_prog = VmProgram::FromBlob(bblob.Span());
        if (!back_prog.Verify(err)) {
            keys.Clear();
            ThrowErrorF(ErrClass::kIntegrity, "the bytecode read back fails verification: %s", err.c_str());
        }
        bblob.Clear();
    }

    const SectionEntry* rse = ContainerReader::FindSection(opened.sections, SectionPurpose::kRmp);
    if (rse) {
        SecureBytes rblob;
        if (!ContainerReader::ReadSection(fr, opened.header, *rse, keys.rmp.Span(), cid, rblob, err)) {
            keys.Clear();
            ThrowErrorF(ErrClass::kAuth, "the runtime protection record cannot be decrypted: %s", err.c_str());
        }
        RmpRecord rec;
        if (!RmpRecord::Deserialize(rblob.Span(), rec, err)) {
            keys.Clear();
            ThrowErrorF(ErrClass::kFormat, "the runtime protection record cannot be parsed: %s", err.c_str());
        }
        rblob.Clear();
        const SectionEntry* wse = ContainerReader::FindSection(opened.sections, SectionPurpose::kWeights);
        if (!wse || memcmp(rec.weights_digest, wse->digest, 32) != 0 ||
            memcmp(rec.manifest_digest, mse->digest, 32) != 0 ||
            rec.weights_plain_bytes != wse->plain_size || rec.weights_chunk_count != wse->chunk_count) {
            keys.Clear();
            ThrowError(ErrClass::kIntegrity,
                       "the runtime protection record does not describe the sections that were written");
        }
    } else if (man.rmp.policy.enabled) {
        keys.Clear();
        ThrowError(ErrClass::kInternal, "runtime protection was requested but no record was written");
    }

    const SectionEntry* wse = ContainerReader::FindSection(opened.sections, SectionPurpose::kWeights);
    if (!wse) {
        keys.Clear();
        ThrowError(ErrClass::kFormat, "the written container has no weights section");
    }
    {
        WeightLayout back_layout = back.ToLayout();
        SecureBytes wkey;
        wkey.Assign(keys.weights.data(), keys.weights.size());
        std::array<uint8_t, 16> cida{};
        memcpy(cida.data(), cid.data(), 16);
        StreamingWeightProvider prov(fr, opened.header, *wse, std::move(back), std::move(wkey), cida, 8ull << 20,
                                     nullptr);
        GgufReaderAccess acc(src_fr, g);
        RowReader rows(acc, 256u * 1024u);
        uint64_t max_row = 1;
        uint64_t max_elems = 1;
        for (const auto& s : back_layout.slots) {
            max_row = std::max(max_row, s.row_bytes);
            max_elems = std::max(max_elems, s.row_elems);
        }
        std::vector<uint8_t> expect(static_cast<size_t>(max_row));
        std::vector<uint8_t> got(static_cast<size_t>(max_row));
        std::vector<float> expect_f(static_cast<size_t>(max_elems));
        std::vector<float> got_f(static_cast<size_t>(max_elems));
        std::mt19937_64 rng(random::Uniform64() | 3ull);

        std::vector<size_t> picks;
        if (!back_layout.slots.empty()) {
            picks.push_back(0);
            picks.push_back(back_layout.slots.size() - 1);
            size_t biggest = 0;
            for (size_t i = 1; i < back_layout.slots.size(); i++) {
                if (back_layout.slots[i].total_bytes > back_layout.slots[biggest].total_bytes) biggest = i;
            }
            picks.push_back(biggest);
            for (size_t i = 0; i < back_layout.slots.size(); i++) {
                if (back_layout.slots[i].transform_mask != 0) {
                    picks.push_back(i);
                    break;
                }
            }
        }
        std::sort(picks.begin(), picks.end());
        picks.erase(std::unique(picks.begin(), picks.end()), picks.end());

        for (size_t pi : picks) {
            const TensorSlot& bs = back_layout.slots[pi];
            const TensorSlot& os = layout.slots[pi];
            const GgufTensorInfo& t = *sources[pi];
            if (bs.total_bytes <= (4ull << 20)) {
                Blake2Stream h;
                std::vector<uint8_t> buf(static_cast<size_t>(bs.row_bytes));
                for (uint64_t r = 0; r < bs.n_rows; r++) {
                    prov.ReadRowRaw(bs.slot_id, r, buf.data());
                    h.Update(buf.data(), static_cast<size_t>(bs.row_bytes));
                }
                uint8_t d[32];
                h.Final(d);
                if (memcmp(d, bs.digest, 32) != 0) {
                    keys.Clear();
                    ThrowErrorF(ErrClass::kIntegrity,
                                "tensor %s decrypted from the new container does not match its recorded digest",
                                bs.name.c_str());
                }
            }
            uint32_t samples = (bs.n_rows > 3) ? 3 : 1;
            for (uint32_t q = 0; q < samples; q++) {
                uint64_t r = 0;
                if (q == 1) r = bs.n_rows - 1;
                if (q == 2) r = std::uniform_int_distribution<uint64_t>(0, bs.n_rows - 1)(rng);
                uint64_t src_row = WeightTransformEngine::MapRow(os, plan, r);
                const uint8_t* p = rows.Row(t, src_row);
                if (os.transform_mask != 0) {
                    WeightTransformEngine::TransformRowBytes(os, plan, r, p, expect.data());
                } else {
                    memcpy(expect.data(), p, static_cast<size_t>(os.row_bytes));
                }
                prov.ReadRowRaw(bs.slot_id, r, got.data());
                if (memcmp(expect.data(), got.data(), static_cast<size_t>(os.row_bytes)) != 0) {
                    keys.Clear();
                    ThrowErrorF(ErrClass::kIntegrity,
                                "row %llu of tensor %s read back from the new container differs from the bytes "
                                "that were written",
                                static_cast<unsigned long long>(r), bs.name.c_str());
                }
                prov.ReadRow(bs.slot_id, r, got_f.data());
                if (!quant::DequantizeRowChecked(os.type_id, expect.data(), static_cast<size_t>(os.row_bytes),
                                                 expect_f.data(), os.row_elems)) {
                    keys.Clear();
                    ThrowErrorF(ErrClass::kInternal, "tensor %s cannot be dequantized during verification",
                                os.name.c_str());
                }
                for (uint64_t j = 0; j < os.row_elems; j++) {
                    if (expect_f[j] != got_f[j]) {
                        keys.Clear();
                        ThrowErrorF(ErrClass::kIntegrity,
                                    "element %llu of row %llu of tensor %s dequantized differently after the "
                                    "round trip (%.9g vs %.9g)",
                                    static_cast<unsigned long long>(j), static_cast<unsigned long long>(r),
                                    bs.name.c_str(), static_cast<double>(expect_f[j]),
                                    static_cast<double>(got_f[j]));
                    }
                }
            }
        }
        SecureWipe::Do(expect.data(), expect.size());
        SecureWipe::Do(got.data(), got.size());
    }
    keys.Clear();
}

static TransformRecord MakeTransformRecord(const TransformPlan& plan) {
    TransformRecord rec;
    rec.enabled = plan.enabled ? 1u : 0u;
    rec.key_space_bits = plan.key_space_bits;
    rec.notes = plan.notes;
    auto axis = [](TransformRecord::Axis& a, const AxisPlan& p, TransformAxis kind) {
        a.kind = static_cast<uint32_t>(kind);
        a.enabled = p.enabled ? 1u : 0u;
        a.length = p.length;
        a.granularity = p.granularity;
        a.group_count = p.group_count;
        a.signed_perm = p.signed_perm ? 1u : 0u;
        a.perm = p.perm;
        a.kv_perm = p.kv_perm;
        a.signs = p.signs;
    };
    axis(rec.residual, plan.residual, TransformAxis::kResidual);
    axis(rec.ffn, plan.ffn, TransformAxis::kFfn);
    axis(rec.head, plan.head, TransformAxis::kHead);
    axis(rec.vocab, plan.vocab, TransformAxis::kVocab);
    const char* names[4] = {"residual axis", "feed forward axis", "head axis", "vocabulary axis"};
    const AxisPlan* plans[4] = {&plan.residual, &plan.ffn, &plan.head, &plan.vocab};
    for (int i = 0; i < 4; i++) {
        if (!plans[i]->reject_reason.empty()) {
            rec.notes.push_back(std::string(names[i]) + " not applied: " + plans[i]->reject_reason);
        }
    }
    return rec;
}

static ManifestModel MakeManifestModel(const ModelSpec& spec) {
    ManifestModel m;
    m.arch = static_cast<uint32_t>(spec.arch);
    m.arch_name = spec.arch_name;
    m.general_name = spec.general_name;
    m.n_layer = spec.n_layer;
    m.n_vocab = spec.n_vocab;
    m.n_embd = spec.n_embd;
    m.n_ff = spec.n_ff;
    m.n_head = spec.n_head;
    m.n_head_kv = spec.n_head_kv;
    m.n_ctx_train = spec.n_ctx_train;
    m.head_dim = spec.head_dim;
    m.n_rot = spec.n_rot;
    m.n_embd_gqa = spec.n_embd_gqa;
    m.n_embd_v_gqa = spec.n_embd_v_gqa;
    m.rope_theta = spec.rope_theta;
    m.rope_scale = spec.rope_scale;
    m.norm_eps = spec.norm_eps;
    m.norm_kind = static_cast<uint32_t>(spec.norm);
    m.ffn_kind = static_cast<uint32_t>(spec.ffn);
    m.tied_output = spec.tied_output ? 1u : 0u;
    m.has_qkv_bias = spec.has_qkv_bias ? 1u : 0u;
    m.has_output_bias = spec.has_output_bias ? 1u : 0u;
    m.embd_scale = spec.embd_scale;
    m.attn_logit_scale = spec.attn_logit_scale;
    m.attn_softcap = spec.attn_softcap;
    m.final_softcap = spec.final_softcap;
    m.rope_scaling_type = spec.rope_scaling_type;
    return m;
}

WeightLayout BuildLayoutFromGguf(const ModelSpec& spec, const GgufInfo& g,
                                 std::vector<const GgufTensorInfo*>& sources, std::vector<std::string>& warnings) {
    sources.clear();
    warnings.clear();
    WeightLayout layout;
    layout.storage_type = 1;
    std::set<std::string> consumed;
    for (const auto& req : spec.required_tensors) {
        const GgufTensorInfo* t = g.FindTensor(req.name);
        if (!t) {
            if (req.required) {
                ThrowErrorF(ErrClass::kFormat,
                            "the %s model is missing the tensor '%s' which this architecture requires",
                            spec.arch_name.c_str(), req.name.c_str());
            }
            continue;
        }
        if (!quant::IsSupported(t->type_id)) {
            const quant::TypeInfo* ti = quant::InfoOrNull(t->type_id);
            std::string what = ti ? std::string("the ") + ti->name + " format"
                                  : FormatErrorF("storage format id %u", t->type_id);
            ThrowErrorF(ErrClass::kUnsupported,
                        "tensor '%s' uses %s, which AIProtect cannot dequantize at runtime. Supported formats: %s",
                        t->name.c_str(), what.c_str(), JoinStrings(quant::SupportedNames(), ", ").c_str());
        }
        if (t->n_dims != req.expect_dims.size()) {
            ThrowErrorF(ErrClass::kFormat,
                        "tensor '%s' has %u dimensions but the %s architecture expects %zu", t->name.c_str(),
                        t->n_dims, spec.arch_name.c_str(), req.expect_dims.size());
        }
        for (size_t d = 0; d < req.expect_dims.size(); d++) {
            if (t->dims[d] != req.expect_dims[d]) {
                ThrowErrorF(ErrClass::kFormat,
                            "tensor '%s' has shape [%s] but the %s architecture expects [%s]", t->name.c_str(),
                            t->ShapeText().c_str(), spec.arch_name.c_str(),
                            JoinDims(req.expect_dims).c_str());
            }
        }
        TensorSlot s;
        s.slot_id = static_cast<uint32_t>(layout.slots.size());
        s.name = t->name;
        s.role = req.role;
        s.layer = req.layer;
        s.type_id = t->type_id;
        s.dims = t->dims;
        s.n_dims = t->n_dims;
        s.n_elems = t->n_elems;
        s.n_rows = t->n_rows;
        s.row_elems = t->row_elems;
        s.block_size = t->block_size;
        s.type_size = t->type_size;
        s.row_bytes = quant::RowBytes(t->type_id, t->row_elems);
        s.total_bytes = quant::TotalBytes(t->type_id, t->n_elems);
        s.src_offset = t->abs_offset;
        s.present = true;
        if (s.row_bytes == 0 || s.total_bytes == 0) {
            ThrowErrorF(ErrClass::kFormat, "tensor '%s' has an empty payload", t->name.c_str());
        }
        if (s.total_bytes != t->n_bytes) {
            ThrowErrorF(ErrClass::kFormat,
                        "tensor '%s' occupies %llu bytes in the file but its %s geometry needs %llu",
                        t->name.c_str(), static_cast<unsigned long long>(t->n_bytes),
                        quant::NameOf(t->type_id).c_str(), static_cast<unsigned long long>(s.total_bytes));
        }
        if (s.row_bytes * s.n_rows != s.total_bytes) {
            ThrowErrorF(ErrClass::kFormat, "tensor '%s' has an inconsistent row layout", t->name.c_str());
        }
        layout.index.emplace(s.name, s.slot_id);
        sources.push_back(t);
        consumed.insert(s.name);
        layout.slots.push_back(std::move(s));

}
if (layout.slots.empty()) {
    ThrowError(ErrClass::kFormat, "the model exposes no tensors that this architecture can use");
}
uint64_t stream_off = 0;
for (auto& s : layout.slots) {
    s.dst_offset = stream_off;
    s.dst_size = s.total_bytes;
    if (stream_off + s.total_bytes < stream_off) {
        ThrowError(ErrClass::kFormat, "the weight stream exceeds 64 bit addressing");
    }
    stream_off += s.total_bytes;
}
layout.total_plain_bytes = stream_off;

for (const auto& t : g.tensors) {
    if (consumed.find(t.name) == consumed.end()) {
        warnings.push_back(FormatErrorF(
            "tensor '%s' (%s, %s) is not used by the %s compute graph and is not stored in the container",
            t.name.c_str(), quant::NameOf(t.type_id).c_str(), t.ShapeText().c_str(), spec.arch_name.c_str()));
    }
}
    return layout;
}

ProtectReport ContainerWriter::Protect(const ProtectOptions& opt, const std::string& password,
                                       std::function<void(const std::string&)> stage_cb) {
    auto started = std::chrono::steady_clock::now();
    auto stage = [&stage_cb](const char* text) {
        if (stage_cb) stage_cb(text);
    };
    SodiumStartup();
    ProtectReport report;

    stage("validating the request");
    if (opt.input.empty()) ThrowError(ErrClass::kUsage, "no input model was given");
    if (opt.output.empty()) ThrowError(ErrClass::kUsage, "no output path was given");
    if (password.empty()) {
        ThrowError(ErrClass::kAuth, "a password is required; AIProtect never stores a model without one");
    }
    if (password.size() < 8) {
        ThrowError(ErrClass::kAuth,
                   "the password is shorter than 8 characters, which is too weak to key an Argon2id derivation");
    }
    uint32_t chunk_kb = opt.chunk_kb;
    if (chunk_kb == 0) chunk_kb = 1024;
    if (chunk_kb < 4 || chunk_kb > 65536 || (chunk_kb & (chunk_kb - 1)) != 0) {
        ThrowErrorF(ErrClass::kUsage, "--chunk-kb must be a power of two between 4 and 65536 (got %u)", chunk_kb);
    }
    uint32_t chunk_plain = chunk_kb * 1024u;

    if (!fsx::Exists(opt.input)) {
        ThrowErrorF(ErrClass::kIoInput, "the input model '%s' does not exist", opt.input.c_str());
    }
    if (!fsx::IsRegularFile(opt.input)) {
        ThrowErrorF(ErrClass::kIoInput, "the input path '%s' is not a regular file", opt.input.c_str());
    }
    if (fsx::IsDirectory(opt.output)) {
        ThrowErrorF(ErrClass::kIoOutput, "the output path '%s' is a directory", opt.output.c_str());
    }
    if (fsx::Exists(opt.output)) {
        if (fsx::SameFile(opt.input, opt.output)) {
            ThrowError(ErrClass::kUsage,
                       "the output path is the same file as the input; refusing to overwrite the source model");
        }
        if (!fsx::IsRegularFile(opt.output)) {
            ThrowErrorF(ErrClass::kIoOutput, "the output path '%s' exists and is not a regular file",
                        opt.output.c_str());
        }
        if (!opt.force) {
            ThrowErrorF(ErrClass::kIoOutput,
                        "the output file '%s' already exists; pass --force to replace it", opt.output.c_str());
        }
    } else if (fsx::SameFile(opt.input, opt.output)) {
        ThrowError(ErrClass::kUsage, "the output path is the same file as the input");
    }
    {
        size_t dot = opt.output.find_last_of('.');
        size_t slash = opt.output.find_last_of("/\\");
        if (dot != std::string::npos && (slash == std::string::npos || dot > slash)) {
            std::string ext = opt.output.substr(dot);
            for (auto& c : ext) c = static_cast<char>(tolower(static_cast<unsigned char>(c)));
            if (ext == ".gguf") {
                ThrowErrorF(ErrClass::kUsage,
                            "refusing to write an AIProtect container to '%s'; a .gguf extension would make the "
                            "protected file look like a plain GGUF model",
                            opt.output.c_str());
            }
        }
    }

    stage("opening the source model");
    FileReader fr;
    std::string err;
    std::vector<const GgufTensorInfo*> sources;
    std::vector<std::string> warnings;
    if (!fr.Open(opt.input, err)) {
        ThrowErrorF(ErrClass::kIoInput, "cannot open '%s': %s", opt.input.c_str(), err.c_str());
    }
    uint64_t source_bytes = fr.Size();
    if (source_bytes < 64) {
        ThrowErrorF(ErrClass::kIoInput, "'%s' is only %llu bytes and cannot be a GGUF model", opt.input.c_str(),
                    static_cast<unsigned long long>(source_bytes));
    }
    {
        bool space_ok = false;
        uint64_t free_bytes = fsx::FreeSpaceFor(opt.output, space_ok);
        if (space_ok) {
            uint64_t need = source_bytes + source_bytes / 16 + (8ull << 20);
            if (free_bytes < need) {
                ThrowErrorF(ErrClass::kIoOutput,
                            "the destination volume has %s free but protecting this model needs about %s",
                            HumanBytes(free_bytes).c_str(), HumanBytes(need).c_str());
            }
        }
    }

    stage("hashing the source model");
    uint8_t source_digest[32]{};
    HashFileDigest(fr, source_bytes, source_digest, !opt.quiet);

    stage("parsing the GGUF structure");
    GgufInfo g = GgufReader::Parse(opt.input, fr, true);
    GgufReader::ValidateLayout(g);

    stage("analysing the architecture");
    ModelSpec spec = ModelSpec::FromGguf(g);
    spec.Validate();
    spec.BuildRequirements();
    VocabData vocab = VocabData::FromGguf(g);
    if (!vocab.Valid()) {
        ThrowError(ErrClass::kFormat,
                   "the model carries no tokenizer vocabulary, so AIProtect cannot store a usable container");
    }
    if (vocab.tokens.size() != spec.n_vocab) {
        ThrowErrorF(ErrClass::kFormat,
                    "the tokenizer holds %zu entries but the model declares a vocabulary of %u",
                    vocab.tokens.size(), spec.n_vocab);
    }

    stage("building the weight layout");
    WeightLayout layout = BuildLayoutFromGguf(spec, g, sources, warnings);

    stage("planning the weight representation transform");
    TransformPlan plan = WeightTransformEngine::Plan(spec, layout, opt.transform);
    for (auto& s : layout.slots) {
        s.transform_mask = static_cast<uint32_t>(WeightTransformEngine::TransformMaskFor(s, plan));
    }
    size_t transformed_tensors = 0;
    uint64_t transformed_bytes = 0;
    for (const auto& s : layout.slots) {
        if (s.transform_mask != 0) {
            transformed_tensors++;
            transformed_bytes += s.total_bytes;
        }
    }
    if (plan.enabled && transformed_tensors == 0) {
        plan.enabled = false;
        plan.notes.push_back("no tensor qualified for the transform, so it was dropped");
    }

    if (plan.enabled) {
        stage("verifying that the transform is reversible");
        GgufReaderAccess acc(fr, g);
        std::string verr;
        if (!WeightTransformEngine::VerifyEquivalence(spec, layout, plan, acc, verr)) {
            ThrowErrorF(ErrClass::kInternal,
                        "the weight transform failed its own reversibility check (%s); no container was written",
                        verr.c_str());
        }
    }

    uint32_t effective_max_ctx = opt.max_ctx;
    if (effective_max_ctx == 0) {
        effective_max_ctx = std::min<uint32_t>(spec.n_ctx_train > 0 ? spec.n_ctx_train : 2048u, 8192u);
    }
    if (effective_max_ctx < 8) effective_max_ctx = 8;

    VmProgram program;
    bool have_program = false;
    std::vector<uint8_t> program_blob;
    uint8_t program_digest[32]{};
    if (opt.vm) {
        stage("compiling the compute graph to bytecode");
        ModelGraph graph = ModelGraph::BuildForArch(spec, layout);
        if (!graph.Validate(err)) {
            ThrowErrorF(ErrClass::kUnsupported,
                        "the %s compute graph cannot be virtualized: %s", spec.arch_name.c_str(), err.c_str());
        }
        err.clear();
        program = BytecodeCompiler::Compile(graph, spec, layout, effective_max_ctx, opt.rmp, err);
        if (!err.empty() || program.code.empty()) {
            ThrowErrorF(ErrClass::kUnsupported,
                        "the %s compute graph contains an operation AIProtect cannot virtualize: %s",
                        spec.arch_name.c_str(), err.empty() ? "the compiler produced no instructions" : err.c_str());
        }
        if (!BytecodeVerifier::Verify(program, err)) {
            ThrowErrorF(ErrClass::kInternal,
                        "the compiler emitted bytecode that fails its own verifier (%s); no container was written",
                        err.c_str());
        }
        program_blob = program.Serialize();
        program.ComputeDigest(program_digest);
        have_program = true;
    }

    Manifest man;
    man.model = MakeManifestModel(spec);
    man.prov.source_file_name = fsx::FileName(opt.input);
    man.prov.source_file_size = source_bytes;
    man.prov.source_gguf_version = g.version;
    memcpy(man.prov.source_digest, source_digest, 32);
    man.prov.created_unix = static_cast<int64_t>(std::time(nullptr));
    man.prov.created_by = FormatErrorF("%s %u.%u.%u", kProductName, kVersionMajor, kVersionMinor, kVersionPatch);
    man.transform = MakeTransformRecord(plan);
    man.rmp.policy.enabled = opt.rmp;
    man.rmp.policy.anti_debug = opt.rmp;
    man.rmp.policy.periodic_integrity = opt.rmp;
    man.rmp.policy.verify_blocks = opt.rmp;
    man.rmp.policy.env_scan = opt.rmp;
    man.rmp.policy.probe_interval_tokens = 8;
    man.rmp.policy.max_violations = 1;
    man.rmp.policy.allow_ptrace_self = false;
    man.rmp.anti_debug_available = platform::AntiDebugAvailable() ? 1u : 0u;
    man.rmp.platform = platform::Name();
    man.storage_type = 1;
    man.weights_plain_bytes = layout.total_plain_bytes;
    man.bytecode_present = have_program ? 1u : 0u;
    man.bytecode_size = program_blob.size();
    memcpy(man.bytecode_digest, program_digest, 32);
    man.vocab = opt.keep_vocab ? vocab : VocabData();
    man.warnings = warnings;
    for (const auto& s : layout.slots) {
        ManifestTensor mt;
        mt.name = s.name;
        mt.slot_id = s.slot_id;
        mt.role = static_cast<uint32_t>(s.role);
        mt.layer = s.layer;
        mt.type_id = s.type_id;
        mt.dims = s.dims;
        mt.n_dims = s.n_dims;
        mt.n_elems = s.n_elems;
        mt.n_rows = s.n_rows;
        mt.row_elems = s.row_elems;
        mt.block_size = s.block_size;
        mt.type_size = s.type_size;
        mt.row_bytes = s.row_bytes;
        mt.total_bytes = s.total_bytes;
        mt.stream_offset = s.dst_offset;
        mt.transform_mask = s.transform_mask;
        man.tensors.push_back(std::move(mt));
    }
    if (!opt.keep_vocab) {
        man.warnings.push_back(
            "the tokenizer vocabulary was stripped at request; run the container with explicit token ids");
    }
    if (!opt.vm) {
        man.warnings.push_back(
            "the container carries no bytecode; the runtime recompiles the compute graph from the manifest, "
            "which removes bytecode level integrity protection");
    }
    if (!opt.rmp) {
        man.warnings.push_back(
            "runtime model protection was disabled at request; the container carries no tamper detection policy");
    }
    if (!plan.enabled) {
        man.warnings.push_back(
            "weights are stored in their original quantized representation; only encryption protects them");
    }

    stage("deriving the container key");
    KdfParams kdf = KdfParams::Generate(opt.kdf_opslimit, opt.kdf_memlimit_kib);
    kdf.ClampToLibraryLimits();
    DerivedKey master = KdfDerive(password, kdf);
    std::array<uint8_t, 16> cid{};
    random::Bytes(cid.data(), cid.size());
    KeyRing keys = KeyRing::Derive(master.key, std::span<const uint8_t, 16>(cid.data(), 16));
    master.Clear();

    uint64_t flags = kFlagStreamedWeights;
    if (have_program) flags |= kFlagVirtualized;
    if (opt.rmp) flags |= kFlagRmpEnabled;
    if (plan.enabled) flags |= kFlagWeightTransform;

    std::vector<SectionEntry> entries;
    entries.reserve(5);
    SectionEntry weights_entry{};
    SectionEntry bytecode_entry{};
    SectionEntry manifest_entry{};
    SectionEntry rmp_entry{};
    SectionEntry vocab_entry{};
    bool have_rmp_section = opt.rmp;
    bool have_vocab_section = opt.keep_vocab && !vocab.tokens.empty();
    size_t section_count =
        2 + (have_program ? 1u : 0u) + (have_rmp_section ? 1u : 0u) + (have_vocab_section ? 1u : 0u);

    ContainerHeader hdr{};
    hdr.magic_a = kContainerMagicA;
    hdr.magic_b = kContainerMagicB;
    hdr.format_version = kContainerVersion;
    hdr.header_size = kHeaderSize;
    hdr.flags = flags;
    memcpy(hdr.container_id, cid.data(), 16);
    hdr.kdf_alg = kdf.alg;
    hdr.kdf_reserved = 0;
    hdr.kdf_opslimit = kdf.opslimit;
    hdr.kdf_memlimit = kdf.memlimit_kib;
    memcpy(hdr.kdf_salt, kdf.salt.data(), 16);
    hdr.cipher_alg = 1;
    hdr.chunk_plain = chunk_plain;
    hdr.section_count = section_count;
    hdr.section_table_offset = kHeaderSize;
    hdr.section_table_size = static_cast<uint64_t>(section_count) * kSectionEntrySize;
    hdr.file_size = 0;
    hdr.created_unix = man.prov.created_unix;
    hdr.product_major = kVersionMajor;
    hdr.product_minor = kVersionMinor;
    hdr.product_patch = kVersionPatch;
    hdr.abi_flags = 0;

    AtomicFileWriter out;
    if (!out.Begin(opt.output, err)) ThrowErrorF(ErrClass::kIoOutput, "%s", err.c_str());
    try {
        std::vector<uint8_t> zeros(kHeaderSize + hdr.section_table_size, 0);
        if (!out.Write(zeros.data(), zeros.size())) {
            ThrowErrorF(ErrClass::kIoOutput, "cannot reserve the container header: %s", LastOsError().c_str());
        }
        uint64_t cursor = zeros.size();

        std::array<uint8_t, 8> weights_nonce{};
        std::array<uint8_t, 8> bytecode_nonce{};
        std::array<uint8_t, 8> manifest_nonce{};
        std::array<uint8_t, 8> rmp_nonce{};
        std::array<uint8_t, 8> vocab_nonce{};
        random::Bytes(weights_nonce.data(), 8);
        random::Bytes(bytecode_nonce.data(), 8);
        random::Bytes(manifest_nonce.data(), 8);
        random::Bytes(rmp_nonce.data(), 8);
        random::Bytes(vocab_nonce.data(), 8);

        stage("encrypting the weights");
        uint64_t weights_offset = cursor;
        {
            SectionSink sink(out, kSectionIdWeights, static_cast<uint32_t>(SectionPurpose::kWeights), chunk_plain,
                             std::span<const uint8_t, 8>(weights_nonce.data(), 8), keys.weights.Span(),
                             std::span<const uint8_t, 16>(cid.data(), 16), "weight");
            GgufReaderAccess acc(fr, g);
            RowReader rows(acc, 512u * 1024u);
            uint64_t max_row = 1;
            for (const auto& s : layout.slots) max_row = std::max(max_row, s.row_bytes);
            std::vector<uint8_t> dst(static_cast<size_t>(max_row));
            Progress prog("encrypting weights", layout.total_plain_bytes, !opt.quiet);
            for (size_t i = 0; i < layout.slots.size(); i++) {
                const TensorSlot& s = layout.slots[i];
                const GgufTensorInfo& t = *sources[i];
                Blake2Stream td;
                for (uint64_t r = 0; r < s.n_rows; r++) {
                    uint64_t src_row = WeightTransformEngine::MapRow(s, plan, r);
                    const uint8_t* p = rows.Row(t, src_row);
                    if (s.transform_mask != 0) {
                        WeightTransformEngine::TransformRowBytes(s, plan, r, p, dst.data());
                    } else {
                        memcpy(dst.data(), p, static_cast<size_t>(s.row_bytes));
                    }
                    td.Update(dst.data(), static_cast<size_t>(s.row_bytes));
                    sink.Write(dst.data(), static_cast<size_t>(s.row_bytes));
                }
                td.Final(man.tensors[i].digest);
                memcpy(layout.slots[i].digest, man.tensors[i].digest, 32);
                prog.Bump(s.total_bytes);
            }
            prog.Finish();
            sink.Finish(weights_entry, weights_offset);
            SecureWipe::Do(dst.data(), dst.size());
        }
        cursor += weights_entry.stored_size;
        if (weights_entry.plain_size != layout.total_plain_bytes) {
            ThrowError(ErrClass::kInternal, "the weight stream length does not match the layout");
        }

        if (have_program) {
            stage("writing the bytecode section");
            uint64_t off = cursor;
            SectionSink sink(out, kSectionIdBytecode, static_cast<uint32_t>(SectionPurpose::kBytecode), chunk_plain,
                             std::span<const uint8_t, 8>(bytecode_nonce.data(), 8), keys.bytecode.Span(),
                             std::span<const uint8_t, 16>(cid.data(), 16), "bytecode");
            sink.Write(program_blob.data(), program_blob.size());
            sink.Finish(bytecode_entry, off);
            cursor += bytecode_entry.stored_size;
        }

        if (have_vocab_section) {
            stage("writing the vocabulary section");
            std::vector<uint8_t> blob = vocabcodec::Serialize(vocab);
            uint64_t off = cursor;
            SectionSink sink(out, kSectionIdVocab, static_cast<uint32_t>(SectionPurpose::kVocab), 256u * 1024u,
                             std::span<const uint8_t, 8>(vocab_nonce.data(), 8), keys.vocab.Span(),
                             std::span<const uint8_t, 16>(cid.data(), 16), "vocabulary");
            sink.Write(blob.data(), blob.size());
            sink.Finish(vocab_entry, off);
            cursor += vocab_entry.stored_size;
            SecureWipe::Do(blob.data(), blob.size());
        }

        stage("writing the manifest");
        {
            std::vector<uint8_t> blob = man.Serialize();
            uint64_t off = cursor;
            SectionSink sink(out, kSectionIdManifest, static_cast<uint32_t>(SectionPurpose::kManifest), 64u * 1024u,
                             std::span<const uint8_t, 8>(manifest_nonce.data(), 8), keys.manifest.Span(),
                             std::span<const uint8_t, 16>(cid.data(), 16), "manifest");
            sink.Write(blob.data(), blob.size());
            sink.Finish(manifest_entry, off);
            cursor += manifest_entry.stored_size;
        }

        if (have_rmp_section) {
            stage("writing the runtime protection record");
            RmpRecord rec;
            rec.policy = man.rmp.policy;
            rec.anti_debug_available = man.rmp.anti_debug_available;
            rec.platform_name = man.rmp.platform;
            std::vector<uint8_t> core = CanonicalHeaderCore(hdr);
            KeyedHash::Plain(std::span<const uint8_t>(core.data(), core.size()), rec.header_core_digest);
            memcpy(rec.manifest_digest, manifest_entry.digest, 32);
            rec.bytecode_present = have_program ? 1u : 0u;
            memcpy(rec.bytecode_digest, have_program ? bytecode_entry.digest : program_digest, 32);
            memcpy(rec.weights_digest, weights_entry.digest, 32);
            rec.weights_plain_bytes = weights_entry.plain_size;
            rec.weights_chunk_count = weights_entry.chunk_count;
            rec.container_id = cid;
            std::vector<uint8_t> blob = rec.Serialize();
            uint64_t off = cursor;
            SectionSink sink(out, kSectionIdRmp, static_cast<uint32_t>(SectionPurpose::kRmp), 64u * 1024u,
                             std::span<const uint8_t, 8>(rmp_nonce.data(), 8), keys.rmp.Span(),
                             std::span<const uint8_t, 16>(cid.data(), 16), "runtime protection");
            sink.Write(blob.data(), blob.size());
            sink.Finish(rmp_entry, off);
            cursor += rmp_entry.stored_size;
        }

        stage("finalising the container");
        std::vector<SectionEntry> table;
        table.push_back(manifest_entry);
        if (have_program) table.push_back(bytecode_entry);
        table.push_back(weights_entry);
        if (have_rmp_section) table.push_back(rmp_entry);
        if (have_vocab_section) table.push_back(vocab_entry);
        std::sort(table.begin(), table.end(),
                  [](const SectionEntry& a, const SectionEntry& b) { return a.section_id < b.section_id; });
        if (table.size() != section_count) ThrowError(ErrClass::kInternal, "section count mismatch");

        hdr.file_size = cursor;
        KeyedHash mac(keys.integrity.Span());
        mac.Update(&hdr, offsetof(ContainerHeader, header_mac));
        mac.Update(table.data(), table.size() * sizeof(SectionEntry));
        mac.Final(hdr.header_mac);

        if (!out.WriteAt(0, &hdr, sizeof(ContainerHeader))) {
            ThrowErrorF(ErrClass::kIoOutput, "cannot write the container header: %s", LastOsError().c_str());
        }
        if (!out.WriteAt(kHeaderSize, table.data(), table.size() * sizeof(SectionEntry))) {
            ThrowErrorF(ErrClass::kIoOutput, "cannot write the section table: %s", LastOsError().c_str());
        }
        entries = table;
        if (!out.Commit(err)) ThrowErrorF(ErrClass::kIoOutput, "%s", err.c_str());
    } catch (...) {
        out.Abort();
        keys.Clear();
        throw;
    }
    keys.Clear();

    if (opt.verify_after_write) {
        stage("verifying the written container");
        VerifyWrittenContainer(opt.output, password, std::span<const uint8_t, 16>(cid.data(), 16), entries, man,
                               layout, plan, fr, g, sources, have_program, program_blob);
    }

    auto ended = std::chrono::steady_clock::now();
    bool out_ok = false;
    report.source_bytes = source_bytes;
    report.weights_plain_bytes = layout.total_plain_bytes;
    report.output_bytes = fsx::FileSize(opt.output, out_ok);
    if (!out_ok) report.output_bytes = 0;
    report.chunks = weights_entry.chunk_count;
    report.tensors = layout.slots.size();
    report.instr_count = have_program ? program.header.instr_count : 0;
    report.seconds = std::chrono::duration<double>(ended - started).count();
    report.transform = plan;
    report.manifest = std::move(man);
    (void)transformed_bytes;
    (void)effective_max_ctx;
    return report;
}

}
namespace aip {

ContainerHandle::~ContainerHandle() {
    weights.reset();
    rmp.reset();
    manifest_blob.Clear();
    bytecode_blob.Clear();
    keys.Clear();
    reader.reset();
}

static ModelSpec SpecFromManifest(const ManifestModel& m) {
    ModelSpec s;
    s.arch = static_cast<ArchId>(m.arch);
    s.arch_name = m.arch_name;
    s.general_name = m.general_name;
    s.n_layer = m.n_layer;
    s.n_vocab = m.n_vocab;
    s.n_embd = m.n_embd;
    s.n_ff = m.n_ff;
    s.n_head = m.n_head;
    s.n_head_kv = m.n_head_kv;
    s.n_ctx_train = m.n_ctx_train;
    s.head_dim = m.head_dim;
    s.n_rot = m.n_rot;
    s.n_embd_gqa = m.n_embd_gqa;
    s.n_embd_v_gqa = m.n_embd_v_gqa;
    s.rope_theta = m.rope_theta;
    s.rope_scale = m.rope_scale;
    s.rope_scaling_type = m.rope_scaling_type;
    s.norm_eps = m.norm_eps;
    s.norm = static_cast<NormKind>(m.norm_kind);
    s.ffn = static_cast<FfnKind>(m.ffn_kind);
    s.tied_output = m.tied_output != 0;
    s.has_qkv_bias = m.has_qkv_bias != 0;
    s.has_output_bias = m.has_output_bias != 0;
    s.embd_scale = m.embd_scale;
    s.attn_logit_scale = m.attn_logit_scale;
    s.attn_softcap = m.attn_softcap;
    s.final_softcap = m.final_softcap;
    s.alignment = 32;
    s.BuildRequirements();
    return s;
}

static AxisPlan AxisFromRecord(const TransformRecord::Axis& a) {
    AxisPlan p;
    p.axis = static_cast<TransformAxis>(a.kind);
    p.enabled = a.enabled != 0;
    p.length = a.length;
    p.granularity = a.granularity ? a.granularity : 1;
    p.group_count = a.group_count;
    p.kv_groups = static_cast<uint32_t>(a.kv_perm.size());
    p.signed_perm = a.signed_perm != 0;
    p.perm = a.perm;
    p.kv_perm = a.kv_perm;
    p.signs = a.signs;
    return p;
}

static TransformPlan PlanFromRecord(const TransformRecord& r) {
    TransformPlan p;
    p.enabled = r.enabled != 0;
    p.residual = AxisFromRecord(r.residual);
    p.ffn = AxisFromRecord(r.ffn);
    p.head = AxisFromRecord(r.head);
    p.vocab = AxisFromRecord(r.vocab);
    p.notes = r.notes;
    p.key_space_bits = r.key_space_bits;
    return p;
}

static KdfParams KdfFromHeader(const ContainerHeader& h) {
    KdfParams p;
    p.alg = h.kdf_alg;
    p.opslimit = h.kdf_opslimit;
    p.memlimit_kib = h.kdf_memlimit;
    memcpy(p.salt.data(), h.kdf_salt, 16);
    return p;
}

static void CheckFindings(const std::vector<RmpFinding>& findings, bool strict) {
    for (const auto& f : findings) {
        if (f.fatal) {
            ThrowErrorF(ErrClass::kIntegrity, "runtime protection abort: %s reported %s", f.source.c_str(),
                        f.detail.c_str());
        }
        if (strict) {
            ThrowErrorF(ErrClass::kIntegrity, "runtime protection abort in strict mode: %s reported %s",
                        f.source.c_str(), f.detail.c_str());
        }
    }
}

std::unique_ptr<ContainerHandle> ProtectedRuntime::Open(const std::string& path, const std::string& password,
                                                        const RunOptions& opt) {
    SodiumStartup();
    if (path.empty()) ThrowError(ErrClass::kUsage, "no container path was given");
    if (password.empty()) ThrowError(ErrClass::kAuth, "a password is required to open a protected container");
    if (!fsx::Exists(path)) ThrowErrorF(ErrClass::kIoInput, "the container '%s' does not exist", path.c_str());
    if (!fsx::IsRegularFile(path)) {
        ThrowErrorF(ErrClass::kIoInput, "the path '%s' is not a regular file", path.c_str());
    }

    auto h = std::make_unique<ContainerHandle>();
    h->path = path;
    h->reader = std::make_unique<FileReader>();
    std::string err;
    if (!h->reader->Open(path, err)) {
        ThrowErrorF(ErrClass::kIoInput, "cannot open '%s': %s", path.c_str(), err.c_str());
    }
    ContainerReader::OpenResult opened = ContainerReader::OpenHeader(path, *h->reader, err);
    if (!opened.header_ok) ThrowErrorF(ErrClass::kFormat, "%s", err.c_str());
    h->header = opened.header;
    h->sections = std::move(opened.sections);
    memcpy(h->header_mac_expected, h->header.header_mac, 32);

    bool header_rmp = (h->header.flags & kFlagRmpEnabled) != 0;
    if (header_rmp) {
        RmpPolicy early;
        RmpReport rep = RmpMonitor::DetectEnvironment(early);
        if (rep.AnyViolation()) {
            ThrowErrorF(ErrClass::kAborted,
                        "refusing to derive any key material for '%s': %s", path.c_str(), rep.Summary().c_str());
        }
    }

    std::array<uint8_t, 16> cid{};
    memcpy(cid.data(), h->header.container_id, 16);
    std::span<const uint8_t, 16> cids(cid.data(), 16);

    DerivedKey master = KdfDerive(password, KdfFromHeader(h->header));
    h->keys = KeyRing::Derive(master.key, cids);
    master.Clear();

    if (!ContainerReader::VerifyHeaderMac(h->header, h->sections, h->keys.integrity.Span())) {
        h->keys.Clear();
        ThrowError(ErrClass::kAuth,
                   "the container header failed authentication: the password is wrong or the file has been "
                   "modified");
    }

    const SectionEntry* mse = ContainerReader::FindSection(h->sections, SectionPurpose::kManifest);
    if (!mse) {
        h->keys.Clear();
        ThrowError(ErrClass::kFormat, "the container has no manifest section");
    }
    if (!ContainerReader::ReadSection(*h->reader, h->header, *mse, h->keys.manifest.Span(), cids, h->manifest_blob,
                                      err)) {
        h->keys.Clear();
        ThrowErrorF(ErrClass::kAuth, "the manifest section cannot be decrypted: %s", err.c_str());
    }
    if (!Manifest::Deserialize(h->manifest_blob.Span(), h->manifest, err)) {
        h->keys.Clear();
        ThrowErrorF(ErrClass::kFormat, "the manifest section cannot be parsed: %s", err.c_str());
    }

    h->spec = SpecFromManifest(h->manifest.model);
    h->spec.Validate();
    h->transform = PlanFromRecord(h->manifest.transform);
    h->vm_enabled = h->manifest.bytecode_present != 0;
    h->rmp_enabled = h->manifest.rmp.policy.enabled && header_rmp;

    const SectionEntry* vse = ContainerReader::FindSection(h->sections, SectionPurpose::kVocab);
    if (vse) {
        SecureBytes vblob;
        if (!ContainerReader::ReadSection(*h->reader, h->header, *vse, h->keys.vocab.Span(), cids, vblob, err)) {
            h->keys.Clear();
            ThrowErrorF(ErrClass::kAuth, "the vocabulary section cannot be decrypted: %s", err.c_str());
        }
        if (!vocabcodec::Deserialize(vblob.Span(), h->manifest.vocab, err)) {
            h->keys.Clear();
            ThrowErrorF(ErrClass::kFormat, "the vocabulary section cannot be parsed: %s", err.c_str());
        }
        vblob.Clear();
    }

    if (h->rmp_enabled) {
        RmpPolicy pol = h->manifest.rmp.policy;
        pol.enabled = true;
        if (opt.strict_rmp) pol.max_violations = 1;
        h->rmp = std::make_unique<RmpMonitor>(pol);
        h->rmp->Bind(cids, h->keys.integrity.Span());
        h->rmp->RegisterRegion("container-header",
                               std::span<const uint8_t>(reinterpret_cast<const uint8_t*>(&h->header),
                                                        sizeof(ContainerHeader)));
        h->rmp->RegisterRegion(
            "section-table",
            std::span<const uint8_t>(reinterpret_cast<const uint8_t*>(h->sections.data()),
                                     h->sections.size() * sizeof(SectionEntry)));
        h->rmp->RegisterRegion("manifest", h->manifest_blob.Span());
    }

    const SectionEntry* bse = ContainerReader::FindSection(h->sections, SectionPurpose::kBytecode);
    if (bse) {
        if (!ContainerReader::ReadSection(*h->reader, h->header, *bse, h->keys.bytecode.Span(), cids,
                                          h->bytecode_blob, err)) {
            h->keys.Clear();
            ThrowErrorF(ErrClass::kAuth, "the bytecode section cannot be decrypted: %s", err.c_str());
        }
        h->program = VmProgram::FromBlob(h->bytecode_blob.Span());
        if (!h->program.Verify(err)) {
            h->keys.Clear();
            ThrowErrorF(ErrClass::kIntegrity, "the stored bytecode failed verification: %s", err.c_str());
        }
        uint8_t d[32];
        h->program.ComputeDigest(d);
        if (memcmp(d, h->manifest.bytecode_digest, 32) != 0) {
            h->keys.Clear();
            ThrowError(ErrClass::kIntegrity,
                       "the stored bytecode does not match the digest recorded in the manifest");
        }
        if (h->rmp) h->rmp->RegisterRegion("bytecode", h->bytecode_blob.Span());
    } else {
        if (h->manifest.bytecode_present) {
            h->keys.Clear();
            ThrowError(ErrClass::kFormat, "the manifest declares bytecode but the container has no bytecode section");
        }
        uint32_t want = opt.n_ctx;
        if (want == 0) {
            want = h->spec.n_ctx_train > 0 ? h->spec.n_ctx_train : 2048u;
            want = std::min<uint32_t>(want, 4096u);
        }
        want = std::max<uint32_t>(want, 64u);
        WeightLayout layout = h->manifest.ToLayout();
        ModelGraph graph = ModelGraph::BuildForArch(h->spec, layout);
        if (!graph.Validate(err)) {
            h->keys.Clear();
            ThrowErrorF(ErrClass::kUnsupported,
                        "this container carries no bytecode and its %s compute graph cannot be rebuilt: %s",
                        h->spec.arch_name.c_str(), err.c_str());
        }
        err.clear();
        h->program = BytecodeCompiler::Compile(graph, h->spec, layout, want, h->rmp_enabled, err);
        if (!err.empty() || h->program.code.empty()) {
            h->keys.Clear();
            ThrowErrorF(ErrClass::kUnsupported,
                        "this container carries no bytecode and its compute graph cannot be compiled: %s",
                        err.empty() ? "the compiler produced no instructions" : err.c_str());
        }
        if (!BytecodeVerifier::Verify(h->program, err)) {
            h->keys.Clear();
            ThrowErrorF(ErrClass::kInternal, "the freshly compiled bytecode fails verification: %s", err.c_str());
        }
    }

    const SectionEntry* wse = ContainerReader::FindSection(h->sections, SectionPurpose::kWeights);
    if (!wse) {
        h->keys.Clear();
        ThrowError(ErrClass::kFormat, "the container has no weights section");
    }
    const SectionEntry* rse = ContainerReader::FindSection(h->sections, SectionPurpose::kRmp);
    if (rse) {
        SecureBytes rblob;
        if (!ContainerReader::ReadSection(*h->reader, h->header, *rse, h->keys.rmp.Span(), cids, rblob, err)) {
            h->keys.Clear();
            ThrowErrorF(ErrClass::kAuth, "the runtime protection record cannot be decrypted: %s", err.c_str());
        }
        RmpRecord rec;
        bool ok = RmpRecord::Deserialize(rblob.Span(), rec, err);
        rblob.Clear();
        if (!ok) {
            h->keys.Clear();
            ThrowErrorF(ErrClass::kFormat, "the runtime protection record cannot be parsed: %s", err.c_str());
        }
        if (memcmp(rec.container_id.data(), cid.data(), 16) != 0) {
            h->keys.Clear();
            ThrowError(ErrClass::kIntegrity, "the runtime protection record belongs to a different container");
        }
        if (memcmp(rec.weights_digest, wse->digest, 32) != 0 ||
            memcmp(rec.manifest_digest, mse->digest, 32) != 0 || rec.weights_plain_bytes != wse->plain_size ||
            rec.weights_chunk_count != wse->chunk_count) {
            h->keys.Clear();
            ThrowError(ErrClass::kIntegrity,
                       "the runtime protection record does not describe the sections in this container");
        }
        if (rec.bytecode_present && bse && memcmp(rec.bytecode_digest, bse->digest, 32) != 0) {
            h->keys.Clear();
            ThrowError(ErrClass::kIntegrity, "the runtime protection record disagrees about the bytecode section");
        }
        std::vector<uint8_t> core = CanonicalHeaderCore(h->header);
        uint8_t cd[32];
        KeyedHash::Plain(std::span<const uint8_t>(core.data(), core.size()), cd);
        if (memcmp(cd, rec.header_core_digest, 32) != 0) {
            h->keys.Clear();
            ThrowError(ErrClass::kIntegrity,
                       "the header fields bound into the runtime protection record do not match this container");
        }
        if (rec.policy.enabled != h->manifest.rmp.policy.enabled ||
            rec.policy.probe_interval_tokens != h->manifest.rmp.policy.probe_interval_tokens ||
            rec.policy.max_violations != h->manifest.rmp.policy.max_violations) {
            h->keys.Clear();
            ThrowError(ErrClass::kIntegrity,
                       "the runtime protection policy in the manifest differs from the protected record");
        }
        if (h->rmp) h->rmp->RecordBlockDigest("rmp-record", std::span<const uint8_t, 32>(rec.weights_digest, 32));
    } else if (h->rmp_enabled) {
        h->keys.Clear();
        ThrowError(ErrClass::kFormat,
                   "the container declares runtime model protection but carries no protection record");
    }

    uint64_t cache_bytes = static_cast<uint64_t>(opt.cache_mb) << 20;
    if (cache_bytes == 0) cache_bytes = 64ull << 20;
    SecureBytes wkey;
    wkey.Assign(h->keys.weights.data(), h->keys.weights.size());
    h->weights = std::make_unique<StreamingWeightProvider>(*h->reader, h->header, *wse, h->manifest, std::move(wkey),
                                                           cid, cache_bytes, h->rmp.get());

    uint32_t n_vocab = h->manifest.model.n_vocab;
    if (n_vocab == 0) {
        h->keys.Clear();
        ThrowError(ErrClass::kFormat, "the manifest declares an empty vocabulary");
    }
    h->token_of_vocab_row.assign(n_vocab, 0);
    h->vocab_row_of_token.assign(n_vocab, 0);
    bool vocab_permuted = h->transform.vocab.enabled && h->transform.vocab.perm.size() == n_vocab;
    std::vector<uint8_t> seen(n_vocab, 0);
    for (uint32_t i = 0; i < n_vocab; i++) {
        uint32_t t = vocab_permuted ? h->transform.vocab.perm[i] : i;
        if (t >= n_vocab || seen[t]) {
            h->keys.Clear();
            ThrowErrorF(ErrClass::kIntegrity,
                        "the vocabulary permutation stored in the manifest is not a bijection (row %u maps to %u)", i,
                        t);
        }
        seen[t] = 1;
        h->token_of_vocab_row[i] = t;
        h->vocab_row_of_token[t] = i;
    }

    if (h->rmp) {
        h->rmp->RegisterRegion(
            "program-code",
            std::span<const uint8_t>(reinterpret_cast<const uint8_t*>(h->program.code.data()),
                                     h->program.code.size() * sizeof(VmInstr)));
        h->rmp->RegisterRegion(
            "vocab-map",
            std::span<const uint8_t>(reinterpret_cast<const uint8_t*>(h->vocab_row_of_token.data()),
                                     h->vocab_row_of_token.size() * sizeof(uint32_t)));
        h->rmp->Seal();
        RmpReport rep = h->rmp->ScanEnvironment();
        if (rep.debugger_detected || rep.injection_suspected) {
            h->keys.Clear();
            ThrowErrorF(ErrClass::kAborted, "refusing to run '%s': %s", path.c_str(), rep.Summary().c_str());
        }
    }
    return h;
}

void ProtectedRuntime::PrintInfo(const ContainerHandle& h) {
    bool ok = false;
    uint64_t size = fsx::FileSize(h.path, ok);
    Console::OutF("container          : %s\n", h.path.c_str());
    if (ok) Console::OutF("size               : %s\n", HumanBytes(size).c_str());
    Console::OutF("format             : AIProtect v%u (product %u.%u.%u)\n", h.header.format_version,
                  h.header.product_major, h.header.product_minor, h.header.product_patch);
    Console::OutF("container id       : %s\n", HexEncode(h.header.container_id, 16).c_str());
    Console::OutF("flags              :%s%s%s%s\n", (h.header.flags & kFlagVirtualized) ? " virtualized" : "",
                  (h.header.flags & kFlagRmpEnabled) ? " rmp" : "",
                  (h.header.flags & kFlagWeightTransform) ? " weight-transform" : "",
                  (h.header.flags & kFlagStreamedWeights) ? " streamed" : "");
    KdfParams kp = KdfFromHeader(h.header);
    Console::OutF("key derivation     : %s\n", kp.Describe().c_str());
    Console::OutF("cipher             : XChaCha20-Poly1305 IETF, %u byte chunks\n", h.header.chunk_plain);
    Console::OutF("created            : %lld\n", static_cast<long long>(h.header.created_unix));
    Console::OutF("created by         : %s\n", h.manifest.prov.created_by.c_str());
    Console::OutF("source model       : %s (%s, GGUF v%u)\n", h.manifest.prov.source_file_name.c_str(),
                  HumanBytes(h.manifest.prov.source_file_size).c_str(), h.manifest.prov.source_gguf_version);
    Console::OutF("source digest      : %s\n", HexEncode(h.manifest.prov.source_digest, 32).c_str());
    Console::Out("sections           :\n");
    for (const auto& s : h.sections) {
        Console::OutF("  %-9s id=%u  plain=%-12s stored=%-12s chunks=%llu  digest=%s\n",
                      SectionPurposeName(static_cast<SectionPurpose>(s.purpose)), s.section_id,
                      HumanBytes(s.plain_size).c_str(), HumanBytes(s.stored_size).c_str(),
                      static_cast<unsigned long long>(s.chunk_count), HexEncode(s.digest, 32).c_str());
    }
    Console::Out("\n");
    Console::Out(h.spec.Describe());
    Console::OutF("weights            : %llu tensors, %s of plaintext, streamed in %u byte chunks\n",
                  static_cast<unsigned long long>(h.manifest.tensors.size()),
                  HumanBytes(h.manifest.weights_plain_bytes).c_str(), h.header.chunk_plain);
    Console::OutF("bytecode           : %s\n",
                  h.vm_enabled ? FormatErrorF("%u instructions, %u registers, %u weight slots, max ctx %u",
                                              h.program.header.instr_count, h.program.header.reg_count,
                                              h.program.header.slot_count, h.program.header.max_ctx)
                                      .c_str()
                               : "absent; the runtime recompiles the graph from the manifest");
    Console::OutF("program digest     : %s\n", HexEncode(h.program.header.program_digest, 32).c_str());
    Console::OutF("weight transform   : %s\n", h.transform.enabled ? "enabled" : "disabled");
    if (h.transform.enabled) {
        Console::OutF("  residual axis    : %s\n",
                      h.transform.residual.enabled
                          ? FormatErrorF("signed permutation of %u groups of %u channels",
                                         h.transform.residual.group_count, h.transform.residual.granularity)
                                .c_str()
                          : "not applied");
        Console::OutF("  feed forward axis: %s\n",
                      h.transform.ffn.enabled ? FormatErrorF("permutation of %u groups of %u units",
                                                             h.transform.ffn.group_count,
                                                             h.transform.ffn.granularity)
                                                     .c_str()
                                              : "not applied");
        Console::OutF("  head axis        : %s\n",
                      h.transform.head.enabled
                          ? FormatErrorF("permutation of %u heads and %u key/value groups of %u channels",
                                         h.transform.head.length, h.transform.head.kv_groups,
                                         h.transform.head.granularity)
                                .c_str()
                          : "not applied");
        Console::OutF("  vocabulary axis  : %s\n",
                      h.transform.vocab.enabled
                          ? FormatErrorF("permutation of %u vocabulary rows", h.transform.vocab.length).c_str()
                          : "not applied");
        Console::OutF("  added key space  : ~%llu bits\n",
                      static_cast<unsigned long long>(h.transform.key_space_bits));
    }
    for (const auto& n : h.transform.notes) {
        bool duplicate = (h.transform.residual.enabled && n.rfind("residual axis:", 0) == 0) ||
                         (h.transform.ffn.enabled && n.rfind("feed forward axis:", 0) == 0) ||
                         (h.transform.head.enabled && n.rfind("attention heads:", 0) == 0) ||
                         (h.transform.vocab.enabled && n.rfind("vocabulary axis:", 0) == 0);
        if (!duplicate) Console::OutF("  note: %s\n", n.c_str());
    }
    Console::OutF("runtime protection : %s on %s\n", h.rmp_enabled ? "enabled" : "disabled", platform::Name());
    if (h.rmp_enabled) {
        const RmpPolicy& p = h.manifest.rmp.policy;
        Console::OutF("  anti-debug       : %s (%s)\n", p.anti_debug ? "on" : "off",
                      h.manifest.rmp.anti_debug_available ? "implemented for this platform"
                                                          : "not available on this platform");
        Console::OutF("  block auth       : %s\n", p.verify_blocks ? "on" : "off");
        Console::OutF("  periodic checks  : %s (every %u tokens)\n", p.periodic_integrity ? "on" : "off",
                      p.probe_interval_tokens);
        Console::OutF("  environment scan : %s\n", p.env_scan ? "on" : "off");
    }
    Console::OutF("vocabulary         : %s\n",
                  h.manifest.vocab.Valid() ? FormatErrorF("%zu tokens, model '%s'", h.manifest.vocab.tokens.size(),
                                                          h.manifest.vocab.model.c_str())
                                                 .c_str()
                                           : "stripped from this container");
    if (!h.manifest.warnings.empty()) {
        Console::Out("warnings           :\n");
        for (const auto& w : h.manifest.warnings) Console::OutF("  - %s\n", w.c_str());
    }
}

void ProtectedRuntime::Audit(ContainerHandle& h, RmpReport& report) {
    report = RmpReport();
    report.platform = platform::Name();
    if (!ContainerReader::VerifyHeaderMac(h.header, h.sections, h.keys.integrity.Span())) {
        report.integrity_failed = true;
        RmpFinding f;
        f.source = "header";
        f.detail = "the container header no longer authenticates under the derived integrity key";
        f.fatal = true;
        report.findings.push_back(f);
    }
    if (memcmp(h.header.header_mac, h.header_mac_expected, 32) != 0) {
        report.integrity_failed = true;
        RmpFinding f;
        f.source = "header";
        f.detail = "the header authentication tag changed in memory since the container was opened";
        f.fatal = true;
        report.findings.push_back(f);
    }
    uint8_t d[32];
    h.program.ComputeDigest(d);
    if (memcmp(d, h.program.header.program_digest, 32) != 0) {
        report.integrity_failed = true;
        RmpFinding f;
        f.source = "bytecode";
        f.detail = "the loaded bytecode no longer matches the digest recorded in its header";
        f.fatal = true;
        report.findings.push_back(f);
    }
    if (!h.rmp) return;
    RmpReport env = h.rmp->ScanEnvironment();
    report.debugger_detected = env.debugger_detected;
    report.injection_suspected = env.injection_suspected;
    report.env_anomaly = env.env_anomaly;
    for (auto& f : env.findings) report.findings.push_back(std::move(f));
    std::vector<RmpFinding> region_findings;
    if (!h.rmp->VerifyRegions(region_findings)) {
        report.integrity_failed = true;
        for (auto& f : region_findings) report.findings.push_back(std::move(f));
    }
    h.weights->IntegrityTick();
}

void ProtectedRuntime::Generate(ContainerHandle& h, const std::vector<int32_t>& prompt_ids, const RunOptions& opt,
                                std::vector<int32_t>& out_ids, GenerationStats& stats) {
    stats = GenerationStats();
    out_ids.clear();
    if (prompt_ids.empty()) ThrowError(ErrClass::kUsage, "no prompt tokens were supplied");
    if (opt.n_predict == 0) ThrowError(ErrClass::kUsage, "the generation length must be at least one token");
    uint32_t cap = h.program.header.max_ctx;
    if (cap == 0) ThrowError(ErrClass::kFormat, "the bytecode declares a zero context length");
    uint64_t need = static_cast<uint64_t>(prompt_ids.size()) + opt.n_predict + 1;
    if (need > cap) {
        ThrowErrorF(ErrClass::kRuntime,
                    "this container supports a context of %u tokens but the request needs %llu (%zu prompt plus %u "
                    "generated); protect the model again with a larger --max-ctx",
                    cap, static_cast<unsigned long long>(need), prompt_ids.size(), opt.n_predict);
    }
    uint32_t ctx = static_cast<uint32_t>(need);
    uint32_t n_vocab = h.program.header.n_vocab;
    if (n_vocab != h.token_of_vocab_row.size()) {
        ThrowErrorF(ErrClass::kFormat, "the bytecode declares %u vocabulary entries but the manifest holds %zu",
                    n_vocab, h.token_of_vocab_row.size());
    }

    VirtualMachine::Limits limits;
    VirtualMachine vm(h.program, *h.weights, limits);
    vm.SetRmp(h.rmp.get());
    vm.Configure(ctx, opt.threads);
    std::string err;
    if (!vm.Prepare(err)) {
        ThrowErrorF(ErrClass::kRuntime, "the virtual machine could not be prepared: %s", err.c_str());
    }

    Sampler sampler(opt.sampler);
    std::vector<float> token_logits(static_cast<size_t>(n_vocab), 0.0f);
    std::vector<int32_t> history;
    history.reserve(prompt_ids.size() + opt.n_predict + 8);
    std::vector<RmpFinding> findings;
    uint32_t probe_every = h.rmp_enabled ? std::max<uint32_t>(1, h.manifest.rmp.policy.probe_interval_tokens) : 0;
    int32_t eos = h.manifest.vocab.Valid() ? h.manifest.vocab.eos : -1;

    auto step = [&](int32_t token, int32_t position) -> const float* {
        if (token < 0 || static_cast<uint32_t>(token) >= n_vocab) {
            ThrowErrorF(ErrClass::kUsage, "token id %d is outside the vocabulary of %u entries", token, n_vocab);
        }
        findings.clear();
        const float* lg = vm.Forward(static_cast<int32_t>(h.vocab_row_of_token[token]), position,
                                     h.rmp_enabled ? &findings : nullptr);
        if (!lg) ThrowError(ErrClass::kRuntime, "the virtual machine produced no logits");
        for (uint32_t i = 0; i < n_vocab; i++) token_logits[h.token_of_vocab_row[i]] = lg[i];
        if (h.rmp_enabled) {
            h.rmp->OnToken(static_cast<uint64_t>(position), findings);
            if (probe_every && (static_cast<uint32_t>(position) % probe_every) == 0) h.weights->IntegrityTick();
        }
        for (const auto& f : findings) stats.findings.push_back(f);
        CheckFindings(findings, opt.strict_rmp);
        return token_logits.data();
    };

    auto prompt_start = std::chrono::steady_clock::now();
    const float* logits = nullptr;
    for (size_t i = 0; i < prompt_ids.size(); i++) {
        history.push_back(prompt_ids[i]);
        logits = step(prompt_ids[i], static_cast<int32_t>(i));
    }
    auto prompt_end = std::chrono::steady_clock::now();
    stats.prompt_tokens = static_cast<uint32_t>(prompt_ids.size());
    stats.prompt_seconds = std::chrono::duration<double>(prompt_end - prompt_start).count();

    auto gen_start = std::chrono::steady_clock::now();
    int32_t next = sampler.Sample(logits, n_vocab, history);
    int32_t position = static_cast<int32_t>(prompt_ids.size());
    for (uint32_t k = 0; k < opt.n_predict; k++) {
        out_ids.push_back(next);
        stats.generated++;
        if (eos >= 0 && next == eos) break;
        history.push_back(next);
        logits = step(next, position);
        position++;
        next = sampler.Sample(logits, n_vocab, history);
    }
    auto gen_end = std::chrono::steady_clock::now();
    stats.generate_seconds = std::chrono::duration<double>(gen_end - gen_start).count();
    stats.instructions = vm.InstructionsExecuted();
    stats.bytes_decrypted = h.weights->BytesDecrypted();
    stats.rmp_checks = h.rmp ? h.rmp->ChecksPerformed() : 0;
}

}
namespace aip {

bool RmpReport::AnyViolation() const {
    return debugger_detected || injection_suspected || integrity_failed || env_anomaly;
}

std::string RmpReport::Summary() const {
    if (!AnyViolation()) return "no runtime protection violations were observed";
    std::string s;
    if (debugger_detected) s += "a debugger is attached; ";
    if (injection_suspected) s += "suspicious code injection was observed; ";
    if (integrity_failed) s += "protected data failed its integrity check; ";
    if (env_anomaly) s += "the process environment looks instrumented; ";
    if (!findings.empty()) {
        s += "first report: ";
        s += findings.front().source;
        s += ": ";
        s += findings.front().detail;
    } else {
        while (!s.empty() && (s.back() == ';' || s.back() == ' ')) s.pop_back();
    }
    return s;
}

namespace platform {

const char* Name() {
#if defined(AIP_PLATFORM_WINDOWS)
    return "windows";
#elif defined(AIP_PLATFORM_MACOS)
    return "macos";
#elif defined(AIP_PLATFORM_LINUX)
    return "linux";
#else
    return "unknown";
#endif
}

bool AntiDebugAvailable() {
#if defined(AIP_PLATFORM_WINDOWS) || defined(AIP_PLATFORM_MACOS) || defined(AIP_PLATFORM_LINUX)
    return true;
#else
    return false;
#endif
}

static std::string Lower(std::string s) {
    for (auto& c : s) c = static_cast<char>(tolower(static_cast<unsigned char>(c)));
    return s;
}

static bool ContainsAny(const std::string& haystack, const char* const* needles, size_t count) {
    std::string h = Lower(haystack);
    for (size_t i = 0; i < count; i++) {
        if (h.find(Lower(std::string(needles[i]))) != std::string::npos) return true;
    }
    return false;
}

#if defined(AIP_PLATFORM_WINDOWS)

static const char* const kWinModuleNeedles[] = {"frida",      "x64dbg",    "x32dbg",   "ollydbg",  "idaq",
                                                "ida64",      "ida32",     "cheatengine", "dbgeng", "scylla",
                                                "titanengine", "gdbserver", "windbg",   "dnspy",    "httpdebugger"};
static const char* const kWinProcessNeedles[] = {"x64dbg.exe",       "x32dbg.exe",     "ollydbg.exe",
                                                 "ida.exe",          "ida64.exe",      "idaq.exe",
                                                 "idaq64.exe",       "windbg.exe",     "kd.exe",
                                                 "cdb.exe",          "ntsd.exe",       "gdb.exe",
                                                 "lldb.exe",         "frida-server.exe", "frida-trace.exe",
                                                 "processhacker.exe", "cheatengine-x86_64.exe", "dnspy.exe",
                                                 "httpdebugger.exe", "wireshark.exe"};

typedef LONG(WINAPI* NtQueryInformationProcessFn)(HANDLE, ULONG, PVOID, ULONG, PULONG);
typedef LONG(WINAPI* NtQuerySystemInformationFn)(ULONG, PVOID, ULONG, PULONG);

static NtQueryInformationProcessFn GetNtQueryInformationProcess() {
    HMODULE nt = GetModuleHandleW(L"ntdll.dll");
    if (!nt) return nullptr;
    return reinterpret_cast<NtQueryInformationProcessFn>(
        reinterpret_cast<void*>(GetProcAddress(nt, "NtQueryInformationProcess")));
}

static bool NtReportsDebugger(std::string& detail) {
    NtQueryInformationProcessFn fn = GetNtQueryInformationProcess();
    if (!fn) return false;
    HANDLE proc = GetCurrentProcess();
    ULONG_PTR debug_port = 0;
    if (fn(proc, 7, &debug_port, sizeof(debug_port), nullptr) == 0 && debug_port != 0) {
        detail = "NtQueryInformationProcess reports a non zero ProcessDebugPort";
        return true;
    }
    DWORD no_debug_inherit = 0;
    if (fn(proc, 31, &no_debug_inherit, sizeof(no_debug_inherit), nullptr) == 0 && no_debug_inherit == 0) {
        detail = "NtQueryInformationProcess reports ProcessDebugFlags cleared, which only happens under a debugger";
        return true;
    }
    HANDLE debug_object = nullptr;
    if (fn(proc, 30, &debug_object, sizeof(debug_object), nullptr) == 0 && debug_object != nullptr) {
        CloseHandle(debug_object);
        detail = "NtQueryInformationProcess returned a ProcessDebugObjectHandle";
        return true;
    }
    return false;
}

static bool KernelDebuggerAttached(std::string& detail) {
    HMODULE nt = GetModuleHandleW(L"ntdll.dll");
    if (!nt) return false;
    NtQuerySystemInformationFn fn = reinterpret_cast<NtQuerySystemInformationFn>(
        reinterpret_cast<void*>(GetProcAddress(nt, "NtQuerySystemInformation")));
    if (!fn) return false;
    struct SysKernelDebugInfo {
        BOOLEAN debugger_enabled;
        BOOLEAN debugger_not_present;
    } info{};
    if (fn(35, &info, sizeof(info), nullptr) != 0) return false;
    if (info.debugger_enabled && info.debugger_not_present) {
        detail = "NtQuerySystemInformation reports a kernel debugger attached";
        return true;
    }
    return false;
}

void Harden() {
    HMODULE nt = GetModuleHandleW(L"ntdll.dll");
    if (!nt) return;
    typedef LONG(WINAPI * NtSetInformationThreadFn)(HANDLE, ULONG, PVOID, ULONG);
    NtSetInformationThreadFn fn = reinterpret_cast<NtSetInformationThreadFn>(
        reinterpret_cast<void*>(GetProcAddress(nt, "NtSetInformationThread")));
    if (!fn) return;
    fn(GetCurrentThread(), 0x11, nullptr, 0);
}

bool DetectDebugger(std::string& detail) {
    if (IsDebuggerPresent()) {
        detail = "IsDebuggerPresent reports a user mode debugger attached to this process";
        return true;
    }
    BOOL remote = FALSE;
    if (CheckRemoteDebuggerPresent(GetCurrentProcess(), &remote) && remote) {
        detail = "CheckRemoteDebuggerPresent reports a debugger attached from another process";
        return true;
    }
    if (NtReportsDebugger(detail)) return true;
    if (KernelDebuggerAttached(detail)) return true;
#if defined(_M_X64) || defined(_M_IX86)
    CONTEXT ctx{};
    ctx.ContextFlags = CONTEXT_DEBUG_REGISTERS;
    if (GetThreadContext(GetCurrentThread(), &ctx) &&
        ((ctx.Dr0 | ctx.Dr1 | ctx.Dr2 | ctx.Dr3) != 0 || (ctx.Dr6 & 0xFF) != 0)) {
        detail = "the hardware debug registers of this thread are programmed";
        return true;
    }
#endif
    return false;
}

bool ScanModules(std::vector<std::string>& detail) {
    bool found = false;
    HANDLE snap = CreateToolhelp32Snapshot(TH32CS_SNAPMODULE | TH32CS_SNAPMODULE32, GetCurrentProcessId());
    if (snap == INVALID_HANDLE_VALUE) return false;
    MODULEENTRY32W me{};
    me.dwSize = sizeof(me);
    wchar_t temp_dir[MAX_PATH * 2] = {0};
    DWORD tl = GetTempPathW(MAX_PATH * 2, temp_dir);
    std::string temp_prefix;
    if (tl > 0) {
        int n = WideCharToMultiByte(CP_UTF8, 0, temp_dir, -1, nullptr, 0, nullptr, nullptr);
        if (n > 0) {
            temp_prefix.resize(static_cast<size_t>(n));
            WideCharToMultiByte(CP_UTF8, 0, temp_dir, -1, &temp_prefix[0], n, nullptr, nullptr);
            while (!temp_prefix.empty() && temp_prefix.back() == '\0') temp_prefix.pop_back();
            temp_prefix = Lower(temp_prefix);
        }
    }
    if (Module32FirstW(snap, &me)) {
        do {
            int n = WideCharToMultiByte(CP_UTF8, 0, me.szExePath, -1, nullptr, 0, nullptr, nullptr);
            if (n <= 0) continue;
            std::string path(static_cast<size_t>(n), '\0');
            WideCharToMultiByte(CP_UTF8, 0, me.szExePath, -1, &path[0], n, nullptr, nullptr);
            while (!path.empty() && path.back() == '\0') path.pop_back();
            std::string lp = Lower(path);
            if (ContainsAny(lp, kWinModuleNeedles, sizeof(kWinModuleNeedles) / sizeof(kWinModuleNeedles[0]))) {
                detail.push_back("loaded module '" + path + "' belongs to a known debugging or injection tool");
                found = true;
            } else if (!temp_prefix.empty() && lp.compare(0, temp_prefix.size(), temp_prefix) == 0 &&
                       lp.find("\\system32\\") == std::string::npos) {
                detail.push_back("loaded module '" + path + "' was read from a temporary directory");
                found = true;
            }
        } while (Module32NextW(snap, &me));
    }
    CloseHandle(snap);
    return found;
}

bool ScanEnvironment(std::vector<std::string>& detail) {
    bool found = false;
    HANDLE snap = CreateToolhelp32Snapshot(TH32CS_SNAPPROCESS, 0);
    if (snap == INVALID_HANDLE_VALUE) return false;
    PROCESSENTRY32W pe{};
    pe.dwSize = sizeof(pe);
    DWORD self = GetCurrentProcessId();
    if (Process32FirstW(snap, &pe)) {
        do {
            if (pe.th32ProcessID == self) continue;
            int n = WideCharToMultiByte(CP_UTF8, 0, pe.szExeFile, -1, nullptr, 0, nullptr, nullptr);
            if (n <= 0) continue;
            std::string name(static_cast<size_t>(n), '\0');
            WideCharToMultiByte(CP_UTF8, 0, pe.szExeFile, -1, &name[0], n, nullptr, nullptr);
            while (!name.empty() && name.back() == '\0') name.pop_back();
            if (ContainsAny(name, kWinProcessNeedles, sizeof(kWinProcessNeedles) / sizeof(kWinProcessNeedles[0]))) {
                detail.push_back("process '" + name + "' is running on this machine (pid " +
                                 std::to_string(pe.th32ProcessID) + ")");
                found = true;
            }
        } while (Process32NextW(snap, &pe));
    }
    CloseHandle(snap);
    return found;
}

#elif defined(AIP_PLATFORM_MACOS)

#ifndef P_TRACED
#define P_TRACED 0x00000800
#endif

static const char* const kMacNeedles[] = {"frida",     "gdb",        "lldb",       "debugserver", "substrate",
                                          "substitute", "libcycript", "inject",     "shadow",      "choicy",
                                          "strace",    "dtrace"};

static bool ProcIsTraced(std::string& detail) {
    int mib[4] = {CTL_KERN, KERN_PROC, KERN_PROC_PID, getpid()};
    kinfo_proc info{};
    size_t size = sizeof(info);
    if (sysctl(mib, 4, &info, &size, nullptr, 0) != 0) return false;
    if ((info.kp_proc.p_flag & P_TRACED) != 0) {
        detail = "sysctl reports the P_TRACED flag set on this process";
        return true;
    }
    return false;
}

void Harden() {
    void* handle = dlopen(nullptr, RTLD_GLOBAL | RTLD_NOW);
    if (!handle) return;
    typedef int (*PtraceFn)(int, pid_t, caddr_t, int);
    PtraceFn fn = reinterpret_cast<PtraceFn>(reinterpret_cast<void*>(dlsym(handle, "ptrace")));
    if (!fn) return;
    fn(31, 0, nullptr, 0);
}

static std::string ParentProcessName() {
    int mib[4] = {CTL_KERN, KERN_PROC, KERN_PROC_PID, getppid()};
    kinfo_proc info{};
    size_t size = sizeof(info);
    if (sysctl(mib, 4, &info, &size, nullptr, 0) != 0) return std::string();
    int nmib[3] = {CTL_KERN, KERN_PROCARGS2, getppid()};
    char args[4096];
    size_t alen = sizeof(args);
    if (sysctl(nmib, 3, args, &alen, nullptr, 0) == 0 && alen > sizeof(int)) {
        size_t off = sizeof(int);
        while (off < alen && args[off] != '\0') off++;
        while (off < alen && args[off] == '\0') off++;
        if (off < alen) {
            std::string p(args + off, alen - off);
            size_t nul = p.find('\0');
            if (nul != std::string::npos) p.resize(nul);
            return p;
        }
    }
    return std::string(info.kp_proc.p_comm);
}

bool DetectDebugger(std::string& detail) {
    if (ProcIsTraced(detail)) return true;
    const char* dyld_insert = getenv("DYLD_INSERT_LIBRARIES");
    if (dyld_insert && *dyld_insert) {
        detail = std::string("DYLD_INSERT_LIBRARIES is set to '") + dyld_insert + "'";
        return true;
    }
    std::string parent = ParentProcessName();
    if (!parent.empty() && ContainsAny(parent, kMacNeedles, sizeof(kMacNeedles) / sizeof(kMacNeedles[0]))) {
        detail = "this process was started by '" + parent + "'";
        return true;
    }
    return false;
}

bool ScanModules(std::vector<std::string>& detail) {
    bool found = false;
    uint32_t count = _dyld_image_count();
    for (uint32_t i = 0; i < count; i++) {
        const char* name = _dyld_get_image_name(i);
        if (!name) continue;
        std::string path(name);
        if (ContainsAny(path, kMacNeedles, sizeof(kMacNeedles) / sizeof(kMacNeedles[0]))) {
            detail.push_back("loaded image '" + path + "' belongs to a known debugging or injection tool");
            found = true;
        }
    }
    return found;
}

bool ScanEnvironment(std::vector<std::string>& detail) {
    bool found = false;
    const char* names[] = {"DYLD_INSERT_LIBRARIES", "DYLD_FORCE_FLAT_NAMESPACE", "DYLD_LIBRARY_PATH",
                           "DYLD_FRAMEWORK_PATH",   "DYLD_PRINT_LIBRARIES",       "DYLD_PRINT_APIS"};
    for (const char* n : names) {
        const char* v = getenv(n);
        if (v && *v) {
            detail.push_back(std::string("the dynamic loader variable ") + n + " is set to '" + v + "'");
            found = true;
        }
    }
    return found;
}

#elif defined(AIP_PLATFORM_LINUX)

static const char* const kLinuxNeedles[] = {"frida",   "gdb",      "gdbserver", "lldb",     "ida",
                                            "inject",  "substrate", "strace",    "ltrace",   "radare",
                                            "r2",      "ghidra",   "ptrace-sandbox", "xposed"};

static long ReadTracerPid(std::string& detail) {
    std::ifstream in("/proc/self/status");
    if (!in) return -1;
    std::string line;
    while (std::getline(in, line)) {
        if (line.compare(0, 9, "TracerPid") == 0) {
            size_t colon = line.find(':');
            if (colon == std::string::npos) return -1;
            long v = strtol(line.c_str() + colon + 1, nullptr, 10);
            if (v != 0) {
                detail = FormatErrorF("/proc/self/status reports TracerPid %ld, so another process is tracing this one",
                                      v);
            }
            return v;
        }
    }
    return 0;
}

static std::string ProcessName(pid_t pid) {
    char path[64];
    snprintf(path, sizeof(path), "/proc/%d/comm", static_cast<int>(pid));
    std::ifstream in(path);
    if (!in) return std::string();
    std::string name;
    std::getline(in, name);
    while (!name.empty() && (name.back() == '\n' || name.back() == '\r')) name.pop_back();
    return name;
}

void Harden() {
    prctl(PR_SET_DUMPABLE, 0, 0, 0, 0);
}

bool DetectDebugger(std::string& detail) {
    long tracer = ReadTracerPid(detail);
    if (tracer > 0) return true;
    char state = 0;
    {
        std::ifstream in("/proc/self/stat");
        if (in) {
            std::string content;
            std::getline(in, content);
            size_t close = content.find_last_of(')');
            if (close != std::string::npos && close + 2 < content.size()) state = content[close + 2];
        }
    }
    if (state == 't' || state == 'T') {
        detail = "/proc/self/stat reports this process is stopped or traced";
        return true;
    }
    std::string parent = ProcessName(getppid());
    if (!parent.empty() && ContainsAny(parent, kLinuxNeedles, sizeof(kLinuxNeedles) / sizeof(kLinuxNeedles[0]))) {
        detail = "this process was started by '" + parent + "'";
        return true;
    }
    return false;
}

bool ScanModules(std::vector<std::string>& detail) {
    bool found = false;
    std::ifstream in("/proc/self/maps");
    if (!in) return false;
    std::set<std::string> seen;
    std::string line;
    while (std::getline(in, line)) {
        size_t sp = line.find('/');
        if (sp == std::string::npos) continue;
        std::string path = line.substr(sp);
        size_t nl = path.find(" (deleted)");
        if (nl != std::string::npos) path = path.substr(0, nl) + " (deleted)";
        if (!seen.insert(path).second) continue;
        if (ContainsAny(path, kLinuxNeedles, sizeof(kLinuxNeedles) / sizeof(kLinuxNeedles[0]))) {
            detail.push_back("mapped object '" + path + "' belongs to a known debugging or injection tool");
            found = true;
        } else if (path.find(" (deleted)") != std::string::npos && path.find("/dev/zero") == std::string::npos) {
            detail.push_back("mapped object '" + path + "' has been deleted from disk while still mapped");
            found = true;
        }
    }
    return found;
}

bool ScanEnvironment(std::vector<std::string>& detail) {
    bool found = false;
    const char* names[] = {"LD_PRELOAD", "LD_AUDIT", "LD_DEBUG", "LD_LIBRARY_PATH", "LD_PROFILE"};
    for (const char* n : names) {
        const char* v = getenv(n);
        if (v && *v) {
            detail.push_back(std::string("the dynamic loader variable ") + n + " is set to '" + v + "'");
            found = true;
        }
    }
    return found;
}

#else

void Harden() {}

bool DetectDebugger(std::string& detail) {
    detail = "this platform has no anti-debug implementation";
    return false;
}

bool ScanModules(std::vector<std::string>& detail) {
    (void)detail;
    return false;
}

bool ScanEnvironment(std::vector<std::string>& detail) {
    (void)detail;
    return false;
}

#endif

}

RmpMonitor::RmpMonitor(RmpPolicy policy) : policy_(policy) {
    if (policy_.probe_interval_tokens == 0) policy_.probe_interval_tokens = 8;
    if (policy_.max_violations == 0) policy_.max_violations = 1;
    static std::once_flag harden_once;
    if (policy_.enabled && policy_.anti_debug) {
        std::call_once(harden_once, [] { platform::Harden(); });
    }
}

void RmpMonitor::Bind(std::span<const uint8_t> container_id, std::span<const uint8_t> integrity_key) {
    memset(container_id_.data(), 0, container_id_.size());
    size_t n = std::min<size_t>(container_id.size(), container_id_.size());
    memcpy(container_id_.data(), container_id.data(), n);
    integrity_key_.Assign(integrity_key.data(), integrity_key.size());
}

void RmpMonitor::RegisterRegion(const std::string& name, std::span<const uint8_t> data) {
    if (data.empty()) return;
    Region r;
    r.name = name;
    r.data = data.data();
    r.size = data.size();
    regions_.push_back(std::move(r));
}

void RmpMonitor::DigestAll() {
    for (auto& r : regions_) {
        if (integrity_key_.size() >= 16) {
            KeyedHash::Once(integrity_key_.Span(), std::span<const uint8_t>(r.data, r.size), r.digest.data());
        } else {
            KeyedHash::Plain(std::span<const uint8_t>(r.data, r.size), r.digest.data());
        }
    }
}

void RmpMonitor::Seal() {
    DigestAll();
    sealed_ = true;
}

static RmpFinding MakeFinding(const std::string& source, const std::string& detail, bool fatal) {
    RmpFinding f;
    f.source = source;
    f.detail = detail;
    f.fatal = fatal;
    return f;
}

bool RmpMonitor::VerifyRegions(std::vector<RmpFinding>& out) {
    if (!policy_.enabled) return true;
    checks_++;
    if (!sealed_) return true;
    bool ok = true;
    for (const auto& r : regions_) {
        std::array<uint8_t, 32> now{};
        if (integrity_key_.size() >= 16) {
            KeyedHash::Once(integrity_key_.Span(), std::span<const uint8_t>(r.data, r.size), now.data());
        } else {
            KeyedHash::Plain(std::span<const uint8_t>(r.data, r.size), now.data());
        }
        if (sodium_memcmp(now.data(), r.digest.data(), 32) != 0) {
            violations_++;
            ok = false;
            out.push_back(MakeFinding(
                "memory-region",
                FormatErrorF("the protected region '%s' (%zu bytes) changed after the container was sealed",
                             r.name.c_str(), r.size),
                violations_ >= policy_.max_violations));
        }
    }
    return ok;
}

RmpReport RmpMonitor::ScanEnvironment() {
    RmpReport report;
    report.platform = platform::Name();
    if (!policy_.enabled) return report;
    checks_++;
    if (policy_.anti_debug) {
        std::string detail;
        if (platform::AntiDebugAvailable() && platform::DetectDebugger(detail)) {
            report.debugger_detected = true;
            violations_++;
            report.findings.push_back(MakeFinding("anti-debug", detail, violations_ >= policy_.max_violations));
        }
    }
    if (policy_.env_scan) {
        std::vector<std::string> details;
        if (platform::ScanModules(details)) {
            report.injection_suspected = true;
            for (auto& d : details) {
                violations_++;
                report.findings.push_back(
                    MakeFinding("module-scan", d, violations_ >= policy_.max_violations));
            }
        }
        details.clear();
        if (platform::ScanEnvironment(details)) {
            report.env_anomaly = true;
            for (auto& d : details) {
                violations_++;
                report.findings.push_back(
                    MakeFinding("environment-scan", d, violations_ >= policy_.max_violations));
            }
        }
    }
    return report;
}

void RmpMonitor::OnToken(uint64_t token_index, std::vector<RmpFinding>& out) {
    if (!policy_.enabled) return;
    if (!policy_.periodic_integrity && !policy_.anti_debug) return;
    uint64_t interval = policy_.probe_interval_tokens ? policy_.probe_interval_tokens : 8;
    if (token_index < last_probe_token_ || token_index - last_probe_token_ < interval) return;
    last_probe_token_ = token_index;
    checks_++;
    if (policy_.anti_debug && platform::AntiDebugAvailable()) {
        std::string detail;
        if (platform::DetectDebugger(detail)) {
            violations_++;
            out.push_back(MakeFinding("anti-debug", detail, violations_ >= policy_.max_violations));
        }
    }
    if (policy_.periodic_integrity) {
        std::vector<RmpFinding> local;
        if (!VerifyRegions(local)) {
            for (auto& f : local) out.push_back(std::move(f));
        }
    }
}

void RmpMonitor::RecordBlockDigest(const std::string& name, std::span<const uint8_t, 32> digest) {
    if (!policy_.enabled || !policy_.verify_blocks) return;
    std::array<uint8_t, 32> value{};
    memcpy(value.data(), digest.data(), 32);
    block_digests_[name] = value;
}

bool RmpMonitor::VerifyBlockDigest(const std::string& name, std::span<const uint8_t, 32> digest) {
    if (!policy_.enabled || !policy_.verify_blocks) return true;
    checks_++;
    auto it = block_digests_.find(name);
    if (it == block_digests_.end()) {
        std::array<uint8_t, 32> value{};
        memcpy(value.data(), digest.data(), 32);
        block_digests_[name] = value;
        return true;
    }
    if (sodium_memcmp(it->second.data(), digest.data(), 32) == 0) return true;
    violations_++;
    return false;
}

void RmpMonitor::SecureErase() {
    for (auto& r : regions_) {
        sodium_memzero(r.digest.data(), r.digest.size());
        r.name.clear();
    }
    regions_.clear();
    for (auto& kv : block_digests_) sodium_memzero(kv.second.data(), kv.second.size());
    block_digests_.clear();
    integrity_key_.Clear();
    memset(container_id_.data(), 0, container_id_.size());
}

RmpReport RmpMonitor::DetectEnvironment(const RmpPolicy& policy) {
    RmpMonitor m(policy);
    return m.ScanEnvironment();
}

}
namespace aip {

std::string ProductBanner() {
    return FormatErrorF("%s %u.%u.%u%s - GGUF model container protection\n", kProductName, kVersionMajor,
                        kVersionMinor, kVersionPatch, kVersionSuffix);
}

std::string Cli::VersionText() {
    return FormatErrorF("%s %u.%u.%u%s\ncontainer format v%u\nlibsodium %s\nplatform %s\nanti-debug %s\n",
                        kProductName, kVersionMajor, kVersionMinor, kVersionPatch, kVersionSuffix, kContainerVersion,
                        SodiumVersion().c_str(), platform::Name(),
                        platform::AntiDebugAvailable() ? "implemented" : "not implemented");
}

std::string Cli::HelpText() {
    std::ostringstream os;
    os << ProductBanner() << "\n";
    os << "usage:\n";
    os << "  aiprotect \"model.gguf\" -output \"model_p.aip\"   protect a model with the short form\n";
    os << "  aiprotect protect \"model.gguf\" --output \"model_p.aip\"\n";
    os << "  aiprotect run \"model_p.aip\" --prompt \"hello\"\n";
    os << "  aiprotect inspect \"model_p.aip\"\n";
    os << "  aiprotect self-test [--filter name] [-v]\n";
    os << "  aiprotect version | --help\n";
    os << "\nprotect options:\n";
    os << "  -o, --output PATH      container to write (required)\n";
    os << "  -f, --force            replace an existing output file\n";
    os << "  -y, --yes              answer yes to the overwrite prompt\n";
    os << "      --no-vm            do not store compiled bytecode in the container\n";
    os << "      --no-rmp           do not store a runtime protection record\n";
    os << "      --no-transform     store weights in their original quantized form\n";
    os << "      --no-vocab         strip the tokenizer vocabulary from the container\n";
    os << "      --no-verify        skip the read back verification pass\n";
    os << "      --chunk-kb N       plaintext chunk size in KiB, power of two, 4..65536 (default 1024)\n";
    os << "      --kdf-ops N        Argon2id opslimit (default 3)\n";
    os << "      --kdf-mem N        Argon2id memory limit in KiB (default 262144)\n";
    os << "      --max-ctx N        context length to compile into the bytecode\n";
    os << "      --password-stdin   read the password from standard input instead of the terminal\n";
    os << "\nrun options:\n";
    os << "  -p, --prompt TEXT      prompt to tokenize and feed to the model\n";
    os << "      --tokens LIST      comma separated token ids, used instead of --prompt\n";
    os << "  -n, --predict N        tokens to generate (default 32)\n";
    os << "      --ctx N            key/value cache length (default: what the request needs)\n";
    os << "  -t, --threads N        worker threads for matrix vector products (default: auto)\n";
    os << "      --cache-mb N       decrypted weight cache in MiB (default 96)\n";
    os << "      --temp F           sampling temperature, 0 selects greedy decoding\n";
    os << "      --top-k N          keep the N most likely tokens (default 1)\n";
    os << "      --top-p F          nucleus sampling threshold (default 1.0)\n";
    os << "      --min-p F          minimum probability relative to the best token\n";
    os << "      --repeat-penalty F penalty applied to recent tokens (default 1.0)\n";
    os << "      --repeat-last-n N  window for the repeat penalty (default 64)\n";
    os << "      --seed N           sampler seed, 0 derives one from the system rng\n";
    os << "  -i, --interactive      read prompts from standard input until end of file\n";
    os << "      --ids              print token ids instead of text\n";
    os << "      --logits           print the leading logits of the last step\n";
    os << "      --audit            run a runtime protection audit before generating\n";
    os << "      --strict-rmp       treat any runtime protection finding as fatal\n";
    os << "      --password-stdin   read the password from standard input\n";
    os << "\nglobal options:\n";
    os << "  -v, --verbose          more detailed output\n";
    os << "  -q, --quiet            suppress progress output\n";
    os << "      --self-test        run the built in verification suite\n";
    os << "      --filter NAME      with --self-test, run only the tests whose name contains NAME\n";
    os << "  -h, --help             show this text\n";
    os << "      --version          show version information\n";
    os << "\nthe password is never accepted on the command line; it is always read from the\n";
    os << "terminal with echo disabled, or from standard input with --password-stdin.\n";
    os << "\nexit codes:\n";
    os << "  0 ok, 1 generic, 2 usage, 3 input file, 4 output file, 5 container format,\n";
    os << "  6 unsupported model, 7 crypto, 8 authentication or wrong password,\n";
    os << "  9 integrity violation, 10 runtime, 11 out of memory, 12 aborted, 13 self test\n";
    return os.str();
}

void Cli::PrintUsageError(const std::string& msg) {
    Console::ErrF("error: %s\n", msg.c_str());
    Console::Err("run 'aiprotect --help' for the full option list\n");
}

static bool ParseUint(const std::string& v, uint64_t& out) {
    if (v.empty()) return false;
    for (char c : v) {
        if (c < '0' || c > '9') return false;
    }
    errno = 0;
    unsigned long long x = strtoull(v.c_str(), nullptr, 10);
    if (errno != 0) return false;
    out = static_cast<uint64_t>(x);
    return true;
}

static bool ParseFloat(const std::string& v, float& out) {
    if (v.empty()) return false;
    errno = 0;
    char* end = nullptr;
    double d = strtod(v.c_str(), &end);
    if (errno != 0 || end != v.c_str() + v.size()) return false;
    out = static_cast<float>(d);
    return true;
}

static bool NeedsValue(const std::string& flag, size_t i, size_t n, std::vector<std::string>& errors) {
    if (i + 1 >= n) {
        errors.push_back("option '" + flag + "' needs a value");
        return false;
    }
    return true;
}

static std::vector<int32_t> ParseTokenList(const std::string& v, std::vector<std::string>& errors) {
    std::vector<int32_t> out;
    size_t pos = 0;
    while (pos <= v.size()) {
        size_t comma = v.find(',', pos);
        std::string piece = v.substr(pos, comma == std::string::npos ? std::string::npos : comma - pos);
        size_t a = piece.find_first_not_of(" \t");
        if (a != std::string::npos) {
            size_t b = piece.find_last_not_of(" \t");
            std::string tok = piece.substr(a, b - a + 1);
            errno = 0;
            char* end = nullptr;
            long long y = strtoll(tok.c_str(), &end, 10);
            if (errno != 0 || end != tok.c_str() + tok.size() || y < 0 || y > 0x7FFFFFFFLL) {
                errors.push_back("'" + tok + "' is not a valid non negative token id");
                return out;
            }
            out.push_back(static_cast<int32_t>(y));
        }
        if (comma == std::string::npos) break;
        pos = comma + 1;
    }
    return out;
}

CliOptions Cli::Parse(const std::vector<std::string>& args) {
    CliOptions o = ParseInner(args);
    if (!o.errors.empty()) o.command = CliOptions::Command::kNone;
    return o;
}

CliOptions Cli::ParseInner(const std::vector<std::string>& args) {
    CliOptions o;
    std::vector<std::string> positional;
    bool self_test_flag = false;
    std::string filter;
    bool verbose = false;
    bool quiet = false;

    for (size_t i = 0; i < args.size(); i++) {
        const std::string& a = args[i];
        auto need = [&](const char* name) -> bool { return NeedsValue(name, i, args.size(), o.errors); };

        if (a == "--") {
            for (size_t j = i + 1; j < args.size(); j++) positional.push_back(args[j]);
            break;
        }
        if (a.size() > 1 && a[0] == '-') {
            std::string flag = a;
            std::string inline_value;
            bool has_inline = false;
            size_t eq = a.find('=');
            if (a[0] == '-' && a[1] == '-' && eq != std::string::npos) {
                flag = a.substr(0, eq);
                inline_value = a.substr(eq + 1);
                has_inline = true;
            }
            auto take = [&](const char* name) -> std::string {
                if (has_inline) return inline_value;
                if (!need(name)) return std::string();
                i++;
                return args[i];
            };
            uint64_t u = 0;
            float f = 0.0f;

            if (flag == "--help" || flag == "-h" || flag == "-?") {
                o.command = CliOptions::Command::kHelp;
                o.show_help = true;
            } else if (flag == "--version") {
                o.command = CliOptions::Command::kVersion;
            } else if (flag == "-v" || flag == "--verbose") {
                verbose = true;
            } else if (flag == "-q" || flag == "--quiet") {
                quiet = true;
            } else if (flag == "--self-test" || flag == "--selftest") {
                self_test_flag = true;
            } else if (flag == "--filter") {
                filter = take("--filter");
            } else if (flag == "-o" || flag == "-output" || flag == "--output") {
                o.protect.output = take(flag.c_str());
            } else if (flag == "-f" || flag == "--force") {
                o.protect.force = true;
            } else if (flag == "-y" || flag == "--yes") {
                o.protect.assume_yes = true;
                o.protect.force = true;
            } else if (flag == "--no-vm") {
                o.protect.vm = false;
            } else if (flag == "--no-rmp") {
                o.protect.rmp = false;
            } else if (flag == "--no-transform") {
                o.protect.transform = false;
            } else if (flag == "--no-vocab") {
                o.protect.keep_vocab = false;
            } else if (flag == "--no-verify") {
                o.protect.verify_after_write = false;
            } else if (flag == "--chunk-kb" || flag == "--chunk") {
                if (!ParseUint(take(flag.c_str()), u) || u == 0 || u > 0xFFFFFFFFull) {
                    o.errors.push_back("'" + flag + "' needs a positive integer");
                } else {
                    o.protect.chunk_kb = static_cast<uint32_t>(u);
                }
            } else if (flag == "--kdf-ops") {
                if (!ParseUint(take(flag.c_str()), u) || u < 1 || u > 1000000) {
                    o.errors.push_back("'" + flag + "' needs an integer between 1 and 1000000");
                } else {
                    o.protect.kdf_opslimit = u;
                }
            } else if (flag == "--kdf-mem") {
                if (!ParseUint(take(flag.c_str()), u) || u < 8192 || u > (32ull << 20)) {
                    o.errors.push_back("'" + flag + "' needs a KiB value between 8192 and 33554432");
                } else {
                    o.protect.kdf_memlimit_kib = u;
                }
            } else if (flag == "--max-ctx") {
                if (!ParseUint(take(flag.c_str()), u) || u < 8 || u > (1ull << 22)) {
                    o.errors.push_back("'" + flag + "' needs a value between 8 and 4194304");
                } else {
                    o.protect.max_ctx = static_cast<uint32_t>(u);
                }
            } else if (flag == "--password-stdin") {
                o.protect.password_stdin = true;
                o.run.password_stdin = true;
            } else if (flag == "-p" || flag == "--prompt") {
                o.run.prompt = take(flag.c_str());
            } else if (flag == "--tokens") {
                o.run.tokens = ParseTokenList(take("--tokens"), o.errors);
            } else if (flag == "-n" || flag == "--predict" || flag == "--n-predict") {
                if (!ParseUint(take(flag.c_str()), u) || u == 0 || u > 100000000ull) {
                    o.errors.push_back("'" + flag + "' needs a positive integer");
                } else {
                    o.run.n_predict = static_cast<uint32_t>(u);
                }
            } else if (flag == "--ctx" || flag == "-c") {
                if (!ParseUint(take(flag.c_str()), u) || u < 8 || u > (1ull << 22)) {
                    o.errors.push_back("'" + flag + "' needs a value between 8 and 4194304");
                } else {
                    o.run.n_ctx = static_cast<uint32_t>(u);
                }
            } else if (flag == "-t" || flag == "--threads") {
                if (!ParseUint(take(flag.c_str()), u) || u == 0 || u > 4096) {
                    o.errors.push_back("'" + flag + "' needs a value between 1 and 4096");
                } else {
                    o.run.threads = static_cast<uint32_t>(u);
                }
            } else if (flag == "--cache-mb") {
                if (!ParseUint(take(flag.c_str()), u) || u == 0 || u > (1ull << 20)) {
                    o.errors.push_back("'" + flag + "' needs a positive MiB value");
                } else {
                    o.run.cache_mb = static_cast<uint32_t>(u);
                }
            } else if (flag == "--temp" || flag == "--temperature") {
                if (!ParseFloat(take(flag.c_str()), f) || f < 0.0f || f > 100.0f) {
                    o.errors.push_back("'" + flag + "' needs a value between 0 and 100");
                } else {
                    o.run.sampler.temperature = f;
                    o.run.sampler.deterministic = false;
                }
            } else if (flag == "--top-k") {
                if (!ParseUint(take(flag.c_str()), u) || u > 10000000ull) {
                    o.errors.push_back("'" + flag + "' needs a non negative integer");
                } else {
                    o.run.sampler.top_k = static_cast<uint32_t>(u);
                    if (u > 1) o.run.sampler.deterministic = false;
                }
            } else if (flag == "--top-p") {
                if (!ParseFloat(take(flag.c_str()), f) || f <= 0.0f || f > 1.0f) {
                    o.errors.push_back("'" + flag + "' needs a value in (0, 1]");
                } else {
                    o.run.sampler.top_p = f;
                }
            } else if (flag == "--min-p") {
                if (!ParseFloat(take(flag.c_str()), f) || f < 0.0f || f > 1.0f) {
                    o.errors.push_back("'" + flag + "' needs a value between 0 and 1");
                } else {
                    o.run.sampler.min_p = f;
                }
            } else if (flag == "--repeat-penalty") {
                if (!ParseFloat(take(flag.c_str()), f) || f < 0.0f || f > 10.0f) {
                    o.errors.push_back("'" + flag + "' needs a value between 0 and 10");
                } else {
                    o.run.sampler.repeat_penalty = f;
                    if (f != 1.0f) o.run.sampler.deterministic = false;
                }
            } else if (flag == "--repeat-last-n") {
                if (!ParseUint(take(flag.c_str()), u) || u > 10000000ull) {
                    o.errors.push_back("'" + flag + "' needs a non negative integer");
                } else {
                    o.run.sampler.repeat_last_n = static_cast<uint32_t>(u);
                }
            } else if (flag == "--seed") {
                if (!ParseUint(take(flag.c_str()), u)) {
                    o.errors.push_back("'" + flag + "' needs a non negative integer");
                } else {
                    o.run.sampler.seed = u;
                    o.run.sampler.deterministic = false;
                }
            } else if (flag == "-i" || flag == "--interactive") {
                o.run.interactive = true;
            } else if (flag == "--ids") {
                o.run.print_ids = true;
            } else if (flag == "--logits") {
                o.run.show_logits = true;
            } else if (flag == "--audit") {
                o.run.audit = true;
            } else if (flag == "--strict-rmp") {
                o.run.strict_rmp = true;
            } else {
                o.errors.push_back("unknown option '" + a + "'");
            }
            continue;
        }
        positional.push_back(a);
    }

    o.self_test_verbose = verbose;
    o.protect.quiet = quiet;
    if (!filter.empty()) {
        self_test_flag = true;
        o.inspect_path = filter;
    }
    if (self_test_flag) {
        o.command = CliOptions::Command::kSelfTest;
        return o;
    }
    if (o.command == CliOptions::Command::kHelp || o.command == CliOptions::Command::kVersion) {
        if (!positional.empty()) o.errors.push_back("the " + std::string(
            o.command == CliOptions::Command::kHelp ? "--help" : "--version") + " option takes no arguments");
        return o;
    }

    if (positional.empty()) {
        if (o.errors.empty()) {
            o.command = CliOptions::Command::kHelp;
            o.show_help = true;
        } else {
            o.command = CliOptions::Command::kNone;
        }
        return o;
    }

    const std::string& first = positional[0];
    std::string verb;
    std::string lower = first;
    for (auto& c : lower) c = static_cast<char>(tolower(static_cast<unsigned char>(c)));
    if (lower == "protect" || lower == "run" || lower == "inspect" || lower == "info" || lower == "self-test" ||
        lower == "selftest" || lower == "version" || lower == "help") {
        verb = lower;
    }

    size_t path_index = 0;
    if (!verb.empty()) {
        if (verb == "help") {
            o.command = CliOptions::Command::kHelp;
            o.show_help = true;
            if (positional.size() > 1) o.errors.push_back("the help command takes no arguments");
            return o;
        }
        if (verb == "version") {
            o.command = CliOptions::Command::kVersion;
            if (positional.size() > 1) o.errors.push_back("the version command takes no arguments");
            return o;
        }
        if (verb == "self-test" || verb == "selftest") {
            o.command = CliOptions::Command::kSelfTest;
            if (positional.size() > 1) o.inspect_path = positional[1];
            return o;
        }
        path_index = 1;
        if (positional.size() < 2) {
            o.errors.push_back("the " + verb + " command needs a file path");
            return o;
        }
    }

    const std::string& path = positional[path_index];
    if (path.empty()) {
        o.errors.push_back("the file path is empty");
        return o;
    }
    for (size_t i = path_index + 1; i < positional.size(); i++) {
        o.errors.push_back("unexpected extra argument '" + positional[i] + "'");
    }

    if (!verb.empty()) {
        if (verb == "protect") {
            o.command = CliOptions::Command::kProtect;
            o.protect.input = path;
        } else if (verb == "run") {
            o.command = CliOptions::Command::kRun;
            o.run.input = path;
        } else {
            o.command = CliOptions::Command::kInspect;
            o.inspect_path = path;
        }
        return o;
    }

    if (!o.protect.output.empty()) {
        o.command = CliOptions::Command::kProtect;
        o.protect.input = path;
        return o;
    }
    if (!o.run.tokens.empty() || !o.run.prompt.empty() || o.run.interactive) {
        o.command = CliOptions::Command::kRun;
        o.run.input = path;
        return o;
    }
    std::string ext;
    size_t dot = path.find_last_of('.');
    size_t slash = path.find_last_of("/\\");
    if (dot != std::string::npos && (slash == std::string::npos || dot > slash)) ext = path.substr(dot);
    for (auto& c : ext) c = static_cast<char>(tolower(static_cast<unsigned char>(c)));
    if (ext == ".aip") {
        o.command = CliOptions::Command::kInspect;
        o.inspect_path = path;
        return o;
    }
    o.errors.push_back("cannot tell whether '" + path +
                       "' should be protected, run, or inspected; use the protect, run, or inspect command");
    o.command = CliOptions::Command::kNone;
    return o;
}

static std::string ReadPasswordFor(bool from_stdin, bool confirm, const std::string& prompt,
                                   const std::string& confirm_prompt) {
    std::string password;
    std::string err;
    if (from_stdin) {
        if (!PasswordInput::ReadHidden("", password, err)) {
            if (!err.empty()) ThrowErrorF(ErrClass::kAuth, "%s", err.c_str());
            ThrowError(ErrClass::kAuth, "no password arrived on standard input");
        }
        if (password.empty()) ThrowError(ErrClass::kAuth, "the password read from standard input was empty");
        return password;
    }
    if (!Console::StdinIsTty()) {
        if (!PasswordInput::ReadHidden("", password, err)) {
            ThrowError(ErrClass::kAuth,
                       "standard input is not a terminal and no password could be read from it; use "
                       "--password-stdin to pipe one in");
        }
        if (password.empty()) {
            ThrowError(ErrClass::kAuth, "standard input is not a terminal and no password was piped in");
        }
        return password;
    }
    if (confirm) {
        if (!PasswordInput::ReadWithConfirm(prompt, password, err)) {
            ThrowErrorF(ErrClass::kAuth, "%s", err.c_str());
        }
    } else {
        if (!PasswordInput::ReadHidden(prompt, password, err)) {
            ThrowErrorF(ErrClass::kAuth, "%s", err.c_str());
        }
    }
    (void)confirm_prompt;
    return password;
}

int MainProtect(const ProtectOptions& opt, std::function<std::string()> password_provider) {
    try {
        if (!opt.quiet) Console::Err(ProductBanner());
        std::string password = password_provider();
        if (password.empty()) {
            Console::Err("error: no password was supplied\n");
            return static_cast<int>(ExitCode::kAuthError);
        }
        if (!opt.quiet) {
            Console::ErrF("input   : %s\n", opt.input.c_str());
            Console::ErrF("output  : %s\n", opt.output.c_str());
            Console::ErrF("bytecode: %s\n", opt.vm ? "compiled and stored" : "omitted (--no-vm)");
            Console::ErrF("rmp     : %s\n", opt.rmp ? "enabled" : "disabled (--no-rmp)");
            Console::ErrF("transform: %s\n", opt.transform ? "requested where safe" : "disabled (--no-transform)");
        }
        auto stage = [&opt](const std::string& text) {
            if (!opt.quiet) Console::ErrF("[*] %s\n", text.c_str());
        };
        ProtectReport rep = ContainerWriter::Protect(opt, password, stage);
        WipeString(password);

        if (!opt.quiet) {
            Console::ErrF("[*] wrote %s (%s) from a %s source in %.2f seconds\n", opt.output.c_str(),
                          HumanBytes(rep.output_bytes).c_str(), HumanBytes(rep.source_bytes).c_str(), rep.seconds);
            Console::ErrF("    %llu tensors, %s of plaintext weights in %llu encrypted chunks\n",
                          static_cast<unsigned long long>(rep.tensors),
                          HumanBytes(rep.weights_plain_bytes).c_str(),
                          static_cast<unsigned long long>(rep.chunks));
            if (rep.instr_count > 0) {
                Console::ErrF("    bytecode: %u instructions\n", rep.instr_count);
            } else {
                Console::Err("    bytecode: not stored\n");
            }
            Console::ErrF("    weight transform: %s", rep.transform.enabled ? "enabled\n" : "not applied\n");
            if (rep.transform.enabled) {
                Console::ErrF("      residual %s, feed forward %s, heads %s, vocabulary %s (~%llu bits of key "
                              "space)\n",
                              rep.transform.residual.enabled ? "permuted" : "kept",
                              rep.transform.ffn.enabled ? "permuted" : "kept",
                              rep.transform.head.enabled ? "permuted" : "kept",
                              rep.transform.vocab.enabled ? "permuted" : "kept",
                              static_cast<unsigned long long>(rep.transform.key_space_bits));
            }
            for (const auto& n : rep.transform.notes) Console::ErrF("      %s\n", n.c_str());
            for (const auto& w : rep.manifest.warnings) Console::ErrF("    warning: %s\n", w.c_str());
            Console::Err("    the container was read back and verified against the source weights\n");
        }
        return static_cast<int>(ExitCode::kOk);
    } catch (const AiError& e) {
        Console::ErrF("error: %s\n", e.Message().c_str());
        return static_cast<int>(e.Code());
    } catch (const std::exception& e) {
        Console::ErrF("error: %s\n", e.what());
        return static_cast<int>(ExitCode::kGenericError);
    }
}

static void PrintGeneration(const ContainerHandle& h, const std::vector<int32_t>& prompt_ids,
                            const std::vector<int32_t>& out_ids, const RunOptions& opt,
                            const ProtectedRuntime::GenerationStats& stats) {
    Tokenizer tok;
    bool can_text = h.manifest.vocab.Valid();
    if (can_text) tok.Load(h.manifest.vocab);
    if (opt.print_ids || !can_text) {
        if (!can_text && !opt.print_ids) {
            Console::Err("note: this container carries no vocabulary, printing token ids instead of text\n");
        }
        std::string line;
        for (size_t i = 0; i < out_ids.size(); i++) {
            if (i) line += " ";
            line += std::to_string(out_ids[i]);
        }
        Console::Out(line + "\n");
    } else {
        std::string text = tok.Decode(out_ids);
        Console::Out(text);
        if (text.empty() || text.back() != '\n') Console::Out("\n");
    }
    if (opt.show_logits) {
        Console::Err("note: --logits prints the sampled continuation only; per token logits are not retained\n");
    }
    Console::ErrF("[*] %u prompt tokens in %.3f s, %u generated in %.3f s (%.1f tok/s)\n", stats.prompt_tokens,
                  stats.prompt_seconds, stats.generated, stats.generate_seconds,
                  stats.generate_seconds > 0.0 ? stats.generated / stats.generate_seconds : 0.0);
    Console::ErrF("    %llu bytecode instructions, %s of weight chunks decrypted",
                  static_cast<unsigned long long>(stats.instructions),
                  HumanBytes(stats.bytes_decrypted).c_str());
    if (h.rmp_enabled) {
        Console::ErrF(", %llu runtime protection checks", static_cast<unsigned long long>(stats.rmp_checks));
    }
    Console::Err("\n");
    if (!stats.findings.empty()) {
        Console::ErrF("    %zu runtime protection finding(s):\n", stats.findings.size());
        for (const auto& f : stats.findings) {
            Console::ErrF("      [%s] %s: %s\n", f.fatal ? "fatal" : "warning", f.source.c_str(), f.detail.c_str());
        }
    }
    (void)prompt_ids;
}

int MainRun(const RunOptions& opt, std::function<std::string()> password_provider) {
    try {
        std::string password = password_provider();
        if (password.empty()) ThrowError(ErrClass::kAuth, "no password was supplied");
        std::unique_ptr<ContainerHandle> handle = ProtectedRuntime::Open(opt.input, password, opt);
        WipeString(password);
        ContainerHandle& h = *handle;

        if (opt.audit) {
            RmpReport report;
            ProtectedRuntime::Audit(h, report);
            Console::ErrF("[*] runtime protection audit on %s\n", report.platform.c_str());
            Console::ErrF("    debugger      : %s\n", report.debugger_detected ? "DETECTED" : "not detected");
            Console::ErrF("    injection     : %s\n", report.injection_suspected ? "SUSPECTED" : "not detected");
            Console::ErrF("    integrity     : %s\n", report.integrity_failed ? "FAILED" : "verified");
            Console::ErrF("    environment   : %s\n", report.env_anomaly ? "anomalous" : "clean");
            for (const auto& f : report.findings) {
                Console::ErrF("      [%s] %s: %s\n", f.fatal ? "fatal" : "warning", f.source.c_str(),
                              f.detail.c_str());
            }
            if (report.AnyViolation()) {
                bool fatal = report.integrity_failed || report.debugger_detected || opt.strict_rmp;
                if (fatal) {
                    Console::ErrF("error: %s\n", report.Summary().c_str());
                    handle->rmp->SecureErase();
                    handle->keys.Clear();
                    return static_cast<int>(ExitCode::kIntegrityViolation);
                }
                Console::ErrF("warning: %s\n", report.Summary().c_str());
            }
        }

        Tokenizer tok;
        bool can_text = h.manifest.vocab.Valid();
        if (can_text) tok.Load(h.manifest.vocab);

        auto resolve_prompt = [&](const std::string& text, std::vector<int32_t>& ids) {
            ids.clear();
            if (!opt.tokens.empty()) {
                ids = opt.tokens;
                return;
            }
            if (!can_text) {
                ThrowError(ErrClass::kFormat,
                           "this container was written with --no-vocab, so text cannot be tokenized; pass "
                           "--tokens with explicit token ids");
            }
            ids = tok.Encode(text, h.manifest.vocab.add_bos);
            if (ids.empty()) {
                ThrowError(ErrClass::kUsage, "the prompt produced no tokens");
            }
        };

        if (opt.interactive) {
            Console::Err(ProductBanner());
            Console::ErrF("loaded %s (%s, %u layers, ctx %u)\n", h.spec.arch_name.c_str(), h.path.c_str(),
                          h.spec.n_layer, h.program.header.max_ctx);
            Console::Err("type a prompt and press enter; an empty line or end of file exits\n");
            std::vector<int32_t> history;
            std::string line;
            while (true) {
                Console::Err("> ");
                if (!PasswordInput::ReadLine("", line, password)) break;
                if (line.empty()) break;
                std::vector<int32_t> ids;
                if (can_text && opt.tokens.empty()) {
                    std::vector<int32_t> turn = tok.Encode(line, history.empty() && h.manifest.vocab.add_bos);
                    history.insert(history.end(), turn.begin(), turn.end());
                    ids = history;
                } else {
                    resolve_prompt(line, ids);
                }
                RunOptions turn_opt = opt;
                turn_opt.tokens.clear();
                turn_opt.interactive = false;
                std::vector<int32_t> out;
                ProtectedRuntime::GenerationStats stats;
                ProtectedRuntime::Generate(h, ids, turn_opt, out, stats);
                if (can_text && opt.tokens.empty()) history.insert(history.end(), out.begin(), out.end());
                PrintGeneration(h, ids, out, turn_opt, stats);
            }
            handle->keys.Clear();
            return static_cast<int>(ExitCode::kOk);
        }

        std::vector<int32_t> ids;
        resolve_prompt(opt.prompt, ids);
        std::vector<int32_t> out;
        ProtectedRuntime::GenerationStats stats;
        ProtectedRuntime::Generate(h, ids, opt, out, stats);
        PrintGeneration(h, ids, out, opt, stats);
        handle->rmp.reset();
        handle->keys.Clear();
        return static_cast<int>(ExitCode::kOk);
    } catch (const AiError& e) {
        Console::ErrF("error: %s\n", e.Message().c_str());
        return static_cast<int>(e.Code());
    } catch (const std::exception& e) {
        Console::ErrF("error: %s\n", e.what());
        return static_cast<int>(ExitCode::kGenericError);
    }
}

int MainInspect(const std::string& path, std::function<std::string()> password_provider, bool need_password) {
    try {
        if (!need_password) {
            FileReader fr;
            std::string err;
            if (!fr.Open(path, err)) ThrowErrorF(ErrClass::kIoInput, "cannot open '%s': %s", path.c_str(),
                                                 err.c_str());
            ContainerReader::OpenResult opened = ContainerReader::OpenHeader(path, fr, err);
            if (!opened.header_ok) ThrowErrorF(ErrClass::kFormat, "%s", err.c_str());
            Console::OutF("container      : %s\n", path.c_str());
            Console::OutF("format         : AIProtect v%u (product %u.%u.%u)\n", opened.header.format_version,
                          opened.header.product_major, opened.header.product_minor, opened.header.product_patch);
            Console::OutF("container id   : %s\n", HexEncode(opened.header.container_id, 16).c_str());
            Console::OutF("flags          :%s%s%s%s\n",
                          (opened.header.flags & kFlagVirtualized) ? " virtualized" : "",
                          (opened.header.flags & kFlagRmpEnabled) ? " rmp" : "",
                          (opened.header.flags & kFlagWeightTransform) ? " weight-transform" : "",
                          (opened.header.flags & kFlagStreamedWeights) ? " streamed" : "");
            Console::OutF("cipher         : XChaCha20-Poly1305 IETF, %u byte chunks\n", opened.header.chunk_plain);
            Console::OutF("sections       : %llu\n",
                          static_cast<unsigned long long>(opened.header.section_count));
            for (const auto& s : opened.sections) {
                Console::OutF("  %-9s id=%u plain=%-12s stored=%-12s chunks=%llu digest=%s\n",
                              SectionPurposeName(static_cast<SectionPurpose>(s.purpose)), s.section_id,
                              HumanBytes(s.plain_size).c_str(), HumanBytes(s.stored_size).c_str(),
                              static_cast<unsigned long long>(s.chunk_count), HexEncode(s.digest, 32).c_str());
            }
            Console::Out("\nthe manifest, weights, and protection record stay encrypted; pass a password to "
                         "inspect them\n");
            return static_cast<int>(ExitCode::kOk);
        }
        std::string password = password_provider();
        if (password.empty()) ThrowError(ErrClass::kAuth, "no password was supplied");
        RunOptions ro;
        std::unique_ptr<ContainerHandle> h = ProtectedRuntime::Open(path, password, ro);
        WipeString(password);
        ProtectedRuntime::PrintInfo(*h);
        h->keys.Clear();
        return static_cast<int>(ExitCode::kOk);
    } catch (const AiError& e) {
        Console::ErrF("error: %s\n", e.Message().c_str());
        return static_cast<int>(e.Code());
    } catch (const std::exception& e) {
        Console::ErrF("error: %s\n", e.what());
        return static_cast<int>(ExitCode::kGenericError);
    }
}

int MainSelfTest(bool verbose, const std::string& filter) {
    return SelfTest::Run(verbose, filter);
}

int MainVersion() {
    Console::Out(Cli::VersionText());
    return static_cast<int>(ExitCode::kOk);
}

int MainHelp() {
    Console::Out(Cli::HelpText());
    return static_cast<int>(ExitCode::kOk);
}

int RunCliStrings(const std::vector<std::string>& args) {
    CliOptions o;
    try {
        o = Cli::Parse(args);
    } catch (const std::exception& e) {
        Console::ErrF("error: %s\n", e.what());
        return static_cast<int>(ExitCode::kUsageError);
    }
    if (!o.errors.empty()) {
        for (const auto& e : o.errors) Cli::PrintUsageError(e);
        return static_cast<int>(ExitCode::kUsageError);
    }
    auto protect_password = [&o]() {
        return ReadPasswordFor(o.protect.password_stdin, true,
                               "enter a password for the protected container: ", "repeat the password: ");
    };
    auto run_password = [&o]() {
        return ReadPasswordFor(o.run.password_stdin, false, "enter the container password: ", "");
    };
    switch (o.command) {
        case CliOptions::Command::kProtect:
            return MainProtect(o.protect, protect_password);
        case CliOptions::Command::kRun:
            return MainRun(o.run, run_password);
        case CliOptions::Command::kInspect:
            return MainInspect(o.inspect_path, run_password, Console::StdinIsTty() || o.run.password_stdin);
        case CliOptions::Command::kSelfTest:
            return MainSelfTest(o.self_test_verbose, o.inspect_path);
        case CliOptions::Command::kVersion:
            return MainVersion();
        case CliOptions::Command::kHelp:
            return MainHelp();
        case CliOptions::Command::kNone:
            return static_cast<int>(ExitCode::kUsageError);
    }
    return static_cast<int>(ExitCode::kUsageError);
}

int RunCli(int argc, char** argv) {
    std::vector<std::string> args;
    args.reserve(static_cast<size_t>(std::max(0, argc - 1)));
    for (int i = 1; i < argc; i++) args.push_back(fsx::Utf8FromArgv(argv[i]));
    return RunCliStrings(args);
}

}

int main(int argc, char** argv) {
#if defined(AIP_PLATFORM_WINDOWS)
    int wargc = 0;
    LPWSTR* wargv = CommandLineToArgvW(GetCommandLineW(), &wargc);
    std::vector<std::string> args;
    if (wargv && wargc > 0) {
        for (int i = 1; i < wargc; i++) {
            int n = WideCharToMultiByte(CP_UTF8, 0, wargv[i], -1, nullptr, 0, nullptr, nullptr);
            if (n <= 0) continue;
            std::string s(static_cast<size_t>(n), '\0');
            WideCharToMultiByte(CP_UTF8, 0, wargv[i], -1, &s[0], n, nullptr, nullptr);
            while (!s.empty() && s.back() == '\0') s.pop_back();
            args.push_back(s);
        }
        LocalFree(wargv);
        return aip::RunCliStrings(args);
    }
    if (wargv) LocalFree(wargv);
#endif
    return aip::RunCli(argc, argv);
}
namespace aip {

class GgufBuilder {
public:
    void Kv(const std::string& key, GgufValueType t, const std::vector<uint8_t>& payload) {
        ByteWriter w;
        WriteStr(w, key);
        w.U32(static_cast<uint32_t>(t));
        w.Raw(payload.data(), payload.size());
        kvs_.push_back(w.Take());
    }
    void Str(const std::string& k, const std::string& v) {
        ByteWriter w;
        WriteStr(w, v);
        Kv(k, GgufValueType::kString, w.Take());
    }
    void U32(const std::string& k, uint32_t v) {
        ByteWriter w;
        w.U32(v);
        Kv(k, GgufValueType::kUint32, w.Take());
    }
    void I32(const std::string& k, int32_t v) {
        ByteWriter w;
        w.I32(v);
        Kv(k, GgufValueType::kInt32, w.Take());
    }
    void U64(const std::string& k, uint64_t v) {
        ByteWriter w;
        w.U64(v);
        Kv(k, GgufValueType::kUint64, w.Take());
    }
    void F32(const std::string& k, float v) {
        ByteWriter w;
        w.F32(v);
        Kv(k, GgufValueType::kFloat32, w.Take());
    }
    void Bool(const std::string& k, bool v) {
        ByteWriter w;
        w.U8(v ? 1 : 0);
        Kv(k, GgufValueType::kBool, w.Take());
    }
    void ArrStr(const std::string& k, const std::vector<std::string>& v) {
        ByteWriter w;
        w.U32(static_cast<uint32_t>(GgufValueType::kString));
        w.U64(v.size());
        for (const auto& s : v) WriteStr(w, s);
        Kv(k, GgufValueType::kArray, w.Take());
    }
    void ArrF32(const std::string& k, const std::vector<float>& v) {
        ByteWriter w;
        w.U32(static_cast<uint32_t>(GgufValueType::kFloat32));
        w.U64(v.size());
        for (float f : v) w.F32(f);
        Kv(k, GgufValueType::kArray, w.Take());
    }
    void ArrI32(const std::string& k, const std::vector<int32_t>& v) {
        ByteWriter w;
        w.U32(static_cast<uint32_t>(GgufValueType::kInt32));
        w.U64(v.size());
        for (int32_t i : v) w.I32(i);
        Kv(k, GgufValueType::kArray, w.Take());
    }
    void Tensor(std::string name, std::vector<uint64_t> dims, uint32_t type_id, std::vector<uint8_t> data) {
        TensorRec t;
        t.name = std::move(name);
        t.dims = std::move(dims);
        t.type_id = type_id;
        t.data = std::move(data);
        tensors_.push_back(std::move(t));
    }
    std::vector<uint8_t> Build(uint32_t alignment) const {
        std::vector<uint64_t> starts(tensors_.size(), 0);
        uint64_t off = 0;
        for (size_t i = 0; i < tensors_.size(); i++) {
            uint64_t ts = quant::TypeSize(tensors_[i].type_id);
            if (ts == 0) ts = 1;
            uint64_t rem = off % ts;
            if (rem != 0) off += ts - rem;
            starts[i] = off;
            off += tensors_[i].data.size();
        }
        ByteWriter w;
        w.Raw("GGUF", 4);
        w.U32(3);
        w.U64(tensors_.size());
        w.U64(kvs_.size());
        for (const auto& kv : kvs_) w.Raw(kv.data(), kv.size());
        for (size_t i = 0; i < tensors_.size(); i++) {
            const TensorRec& t = tensors_[i];
            WriteStr(w, t.name);
            w.U32(static_cast<uint32_t>(t.dims.size()));
            for (uint64_t d : t.dims) w.U64(d);
            w.U32(t.type_id);
            w.U64(starts[i]);
        }
        uint64_t end = w.Size();
        uint64_t rem = end % alignment;
        if (rem != 0) w.Pad(static_cast<size_t>(alignment - rem));
        uint64_t cur = 0;
        for (size_t i = 0; i < tensors_.size(); i++) {
            if (starts[i] > cur) w.Pad(static_cast<size_t>(starts[i] - cur));
            w.Raw(tensors_[i].data.data(), tensors_[i].data.size());
            cur = starts[i] + tensors_[i].data.size();
        }
        return w.Take();
    }

private:
    struct TensorRec {
        std::string name;
        std::vector<uint64_t> dims;
        uint32_t type_id = 0;
        std::vector<uint8_t> data;
    };
    static void WriteStr(ByteWriter& w, const std::string& s) {
        w.U64(s.size());
        w.Raw(s.data(), s.size());
    }
    std::vector<std::vector<uint8_t>> kvs_;
    std::vector<TensorRec> tensors_;
};

static uint64_t MixSeed(uint64_t seed, const std::string& name) {
    uint64_t h = seed ? seed : 0x9E3779B97F4A7C15ull;
    for (char c : name) {
        h ^= static_cast<uint8_t>(c);
        h *= 0x100000001B3ull;
        h ^= h >> 29;
    }
    return h ? h : 1;
}

static std::vector<uint8_t> F32Ones(uint64_t n, uint64_t seed) {
    std::vector<uint8_t> out(static_cast<size_t>(n) * 4);
    uint64_t st = seed;
    for (uint64_t i = 0; i < n; i++) {
        st = st * 6364136223846793005ull + 1442695040888963407ull;
        float v = 1.0f + static_cast<float>(static_cast<int32_t>((st >> 33) & 0xFFFF)) / 65536.0f * 0.1f;
        memcpy(out.data() + i * 4, &v, 4);
    }
    return out;
}

static std::vector<uint8_t> MakeTensorData(uint32_t type_id, uint64_t n_elems, uint64_t seed) {
    if (type_id == 0) return F32Ones(n_elems, seed);
    return quant::EncodeReferenceBlock(type_id, seed, n_elems);
}

static void BuildTinyVocab(GgufBuilder& b, uint32_t n_vocab, const std::string& model, bool with_merges) {
    std::vector<std::string> tokens;
    std::vector<float> scores;
    std::vector<int32_t> types;
    std::vector<std::string> merges;
    tokens.push_back("<unk>");
    scores.push_back(-1000.0f);
    types.push_back(2);
    tokens.push_back("<s>");
    scores.push_back(-1000.0f);
    types.push_back(3);
    tokens.push_back("</s>");
    scores.push_back(-1000.0f);
    types.push_back(3);
    static const char* alphabet =
        "abcdefghijklmnopqrstuvwxyzABCDEFGHIJKLMNOPQRSTUVWXYZ0123456789 .,!?";
    for (size_t i = 0; i < strlen(alphabet) && tokens.size() < n_vocab; i++) {
        tokens.push_back(std::string(1, alphabet[i]));
        scores.push_back(-1.0f);
        types.push_back(1);
    }
    if (model == "llama" && tokens.size() < n_vocab) {
        tokens.push_back("\xe2\x96\x81");
        scores.push_back(-0.5f);
        types.push_back(1);
    }
    while (tokens.size() < n_vocab) {
        tokens.push_back("<unused_" + std::to_string(tokens.size()) + ">");
        scores.push_back(-1000.0f);
        types.push_back(5);
    }
    if (with_merges) {
        merges.push_back("a b");
        merges.push_back("ab c");
        merges.push_back("h i");
    }
    b.Str("tokenizer.ggml.model", model);
    if (model == "gpt2") b.Str("tokenizer.ggml.pre", "qwen2");
    b.ArrStr("tokenizer.ggml.tokens", tokens);
    b.ArrF32("tokenizer.ggml.scores", scores);
    b.ArrI32("tokenizer.ggml.token_type", types);
    if (with_merges) b.ArrStr("tokenizer.ggml.merges", merges);
    b.I32("tokenizer.ggml.bos_token_id", 1);
    b.I32("tokenizer.ggml.eos_token_id", 2);
    b.I32("tokenizer.ggml.padding_token_id", 0);
    b.I32("tokenizer.ggml.unknown_token_id", 0);
    b.Bool("tokenizer.ggml.add_bos_token", false);
    b.Bool("tokenizer.ggml.add_eos_token", false);
}

std::vector<uint8_t> TinyModelFactory::BuildGguf(uint32_t n_layer, uint32_t n_embd, uint32_t n_ff, uint32_t n_head,
                                                 uint32_t n_head_kv, uint32_t n_vocab, uint32_t quant_type,
                                                 uint64_t seed, const std::string& arch) {
    if (n_layer == 0 || n_embd == 0 || n_ff == 0 || n_head == 0 || n_head_kv == 0 || n_vocab == 0) {
        ThrowError(ErrClass::kUsage, "TinyModelFactory needs non zero dimensions");
    }
    if (n_embd % n_head != 0) {
        ThrowError(ErrClass::kUsage, "TinyModelFactory needs n_embd to be a multiple of n_head");
    }
    const uint32_t head_dim = n_embd / n_head;
    if (n_embd % head_dim != 0) ThrowError(ErrClass::kUsage, "head geometry is inconsistent");
    if (n_head % n_head_kv != 0) {
        ThrowError(ErrClass::kUsage, "TinyModelFactory needs n_head to be a multiple of n_head_kv");
    }
    if (n_head_kv > n_head) ThrowError(ErrClass::kUsage, "n_head_kv cannot exceed n_head");
    const uint32_t qd = n_head * head_dim;
    const uint32_t kd = n_head_kv * head_dim;
    bool qwen = (arch == "qwen2");
    uint64_t s = seed ? seed : 0x5DEECE66Dull;

    GgufBuilder b;
    b.Str("general.architecture", arch);
    b.Str("general.name", "aiprotect-self-test");
    b.U32("general.alignment", 32);
    b.Str("general.quantization_version", "2");
    b.U32(arch + ".block_count", n_layer);
    b.U32(arch + ".embedding_length", n_embd);
    b.U32(arch + ".feed_forward_length", n_ff);
    b.U32(arch + ".attention.head_count", n_head);
    b.U32(arch + ".attention.head_count_kv", n_head_kv);
    b.U32(arch + ".context_length", 512);
    b.F32(arch + ".attention.layer_norm_rms_epsilon", 1e-5f);
    b.F32(arch + ".rope.freq_base", 10000.0f);
    b.U32(arch + ".vocab_size", n_vocab);
    BuildTinyVocab(b, n_vocab, "llama", false);

    auto add = [&](const std::string& name, std::vector<uint64_t> dims, uint32_t type) {
        uint64_t n = 1;
        for (uint64_t d : dims) n *= d;
        b.Tensor(name, std::move(dims), type, MakeTensorData(type, n, MixSeed(s, name)));
    };

    add("token_embd.weight", {n_embd, n_vocab}, quant_type);
    add("output_norm.weight", {n_embd}, 0);
    add("output.weight", {n_embd, n_vocab}, quant_type);
    for (uint32_t i = 0; i < n_layer; i++) {
        std::string p = "blk." + std::to_string(i) + ".";
        add(p + "attn_norm.weight", {n_embd}, 0);
        add(p + "attn_q.weight", {n_embd, qd}, quant_type);
        add(p + "attn_k.weight", {n_embd, kd}, quant_type);
        add(p + "attn_v.weight", {n_embd, kd}, quant_type);
        add(p + "attn_output.weight", {n_embd, qd}, quant_type);
        if (qwen) {
            add(p + "attn_q.bias", {qd}, 0);
            add(p + "attn_k.bias", {kd}, 0);
            add(p + "attn_v.bias", {kd}, 0);
        }
        add(p + "ffn_norm.weight", {n_embd}, 0);
        add(p + "ffn_gate.weight", {n_embd, n_ff}, quant_type);
        add(p + "ffn_up.weight", {n_embd, n_ff}, quant_type);
        add(p + "ffn_down.weight", {n_ff, n_embd}, quant_type);
    }
    return b.Build(32);
}

ModelSpec TinyModelFactory::SpecFor(uint32_t n_layer, uint32_t n_embd, uint32_t n_ff, uint32_t n_head,
                                    uint32_t n_head_kv, uint32_t n_vocab, const std::string& arch) {
    ModelSpec s;
    s.arch = ArchFromName(arch);
    s.arch_name = arch;
    s.general_name = "aiprotect-self-test";
    s.n_layer = n_layer;
    s.n_vocab = n_vocab;
    s.n_embd = n_embd;
    s.n_ff = n_ff;
    s.n_head = n_head;
    s.n_head_kv = n_head_kv;
    s.n_ctx_train = 512;
    s.head_dim = n_head ? n_embd / n_head : 0;
    s.n_rot = s.head_dim;
    s.n_embd_gqa = s.head_dim * n_head;
    s.n_embd_v_gqa = s.head_dim * n_head_kv;
    s.rope_theta = 10000.0f;
    s.rope_scale = 1.0f;
    s.norm_eps = 1e-5f;
    s.norm = NormKind::kRms;
    s.ffn = (s.arch == ArchId::kGemma) ? FfnKind::kGeGlu : FfnKind::kSwiGlu;
    s.tied_output = false;
    s.has_qkv_bias = (s.arch == ArchId::kQwen2);
    s.embd_scale = (s.arch == ArchId::kGemma) ? std::sqrt(static_cast<float>(n_embd)) : 0.0f;
    s.alignment = 32;
    s.BuildRequirements();
    return s;
}

static std::string TempDirBase() {
#if defined(AIP_PLATFORM_WINDOWS)
    wchar_t buf[MAX_PATH + 2];
    DWORD n = GetTempPathW(MAX_PATH + 2, buf);
    if (n == 0 || n > MAX_PATH + 1) return std::string("C:\\Temp");
    int len = WideCharToMultiByte(CP_UTF8, 0, buf, -1, nullptr, 0, nullptr, nullptr);
    if (len <= 0) return std::string("C:\\Temp");
    std::string s(static_cast<size_t>(len), '\0');
    WideCharToMultiByte(CP_UTF8, 0, buf, -1, &s[0], len, nullptr, nullptr);
    while (!s.empty() && s.back() == '\0') s.pop_back();
    if (!s.empty() && s.back() != '\\') s += '\\';
    return s;
#else
    const char* t = getenv("TMPDIR");
    if (t && *t) {
        std::string s(t);
        if (!s.empty() && s.back() != '/') s += '/';
        return s;
    }
    return std::string("/tmp/");
#endif
}

static std::string MakeTempPath(const std::string& tag, const std::string& ext) {
    uint8_t r[8];
    random::Bytes(r, sizeof(r));
    return TempDirBase() + "aiprotect-selftest-" + tag + "-" + HexEncode(r, sizeof(r)) + ext;
}

static void WriteFileAll(const std::string& path, std::span<const uint8_t> data) {
    AtomicFileWriter w;
    std::string err;
    if (!w.Begin(path, err)) ThrowErrorF(ErrClass::kIoOutput, "%s", err.c_str());
    if (!w.Write(data.data(), data.size())) {
        w.Abort();
        ThrowErrorF(ErrClass::kIoOutput, "cannot write '%s': %s", path.c_str(), LastOsError().c_str());
    }
    if (!w.Commit(err)) ThrowErrorF(ErrClass::kIoOutput, "%s", err.c_str());
}

static std::vector<uint8_t> ReadFileAll(const std::string& path) {
    FileReader fr;
    std::string err;
    if (!fr.Open(path, err)) ThrowErrorF(ErrClass::kIoInput, "%s", err.c_str());
    std::vector<uint8_t> out(static_cast<size_t>(fr.Size()));
    if (!out.empty() && !fr.ReadAt(0, out.data(), out.size())) {
        ThrowErrorF(ErrClass::kIoInput, "cannot read '%s'", path.c_str());
    }
    return out;
}

struct TempFiles {
    std::vector<std::string> paths;
    ~TempFiles() {
        for (const auto& p : paths) AtomicFileWriter::RemoveFile(p);
    }
    std::string Add(const std::string& tag, const std::string& ext) {
        std::string p = MakeTempPath(tag, ext);
        paths.push_back(p);
        return p;
    }
};

static ProtectOptions TinyProtectOptions(const std::string& in, const std::string& out) {
    ProtectOptions o;
    o.input = in;
    o.output = out;
    o.quiet = true;
    o.chunk_kb = 16;
    o.kdf_opslimit = 1;
    o.kdf_memlimit_kib = 65536;
    o.max_ctx = 64;
    return o;
}

static RunOptions TinyRunOptions(const std::string& in) {
    RunOptions o;
    o.input = in;
    o.n_predict = 6;
    o.cache_mb = 4;
    o.threads = 1;
    o.sampler.temperature = 0.0f;
    o.sampler.top_k = 1;
    o.sampler.top_p = 1.0f;
    o.sampler.min_p = 0.0f;
    o.sampler.repeat_penalty = 1.0f;
    o.sampler.deterministic = true;
    return o;
}

static SelfTestResult Fail(const std::string& name, const std::string& detail,
                           std::chrono::steady_clock::time_point t0) {
    SelfTestResult r;
    r.name = name;
    r.passed = false;
    r.detail = detail;
    r.seconds = std::chrono::duration<double>(std::chrono::steady_clock::now() - t0).count();
    return r;
}

static SelfTestResult Pass(const std::string& name, const std::string& detail,
                           std::chrono::steady_clock::time_point t0) {
    SelfTestResult r;
    r.name = name;
    r.passed = true;
    r.detail = detail;
    r.seconds = std::chrono::duration<double>(std::chrono::steady_clock::now() - t0).count();
    return r;
}

SelfTestResult SelfTest::CryptoRoundTrip(bool verbose) {
    const std::string name = "crypto-round-trip";
    auto t0 = std::chrono::steady_clock::now();
    try {
        SodiumStartup();
        uint8_t key[BlockCipher::kKeyBytes];
        random::Bytes(key, sizeof(key));
        std::array<uint8_t, 8> prefix{};
        random::Bytes(prefix.data(), prefix.size());
        std::array<uint8_t, BlockCipher::kNonceBytes> nonce{};
        BlockCipher::BuildNonce(nonce, std::span<const uint8_t, 8>(prefix.data(), 8), 3, 17);
        std::array<uint8_t, BlockCipher::kNonceBytes> nonce2{};
        BlockCipher::BuildNonce(nonce2, std::span<const uint8_t, 8>(prefix.data(), 8), 3, 18);
        if (nonce == nonce2) return Fail(name, "chunk nonces are not unique per index", t0);
        std::array<uint8_t, 16> cid{};
        random::Bytes(cid.data(), cid.size());
        std::array<uint8_t, 40> aad{};
        BuildChunkAad(std::span<const uint8_t, 16>(cid.data(), 16), 3, 3, 17, 4096, aad);
        std::vector<uint8_t> plain(4096);
        for (size_t i = 0; i < plain.size(); i++) plain[i] = static_cast<uint8_t>(i * 31 + 7);
        std::vector<uint8_t> cipher(plain.size() + BlockCipher::kTagBytes);
        size_t out_len = 0;
        if (!BlockCipher::Encrypt(std::span<const uint8_t>(key, sizeof(key)), nonce,
                                  std::span<const uint8_t>(aad.data(), aad.size()),
                                  std::span<const uint8_t>(plain.data(), plain.size()), cipher.data(),
                                  cipher.size(), out_len)) {
            return Fail(name, "encryption failed", t0);
        }
        if (out_len != cipher.size()) return Fail(name, "ciphertext length is wrong", t0);
        if (memcmp(cipher.data(), plain.data(), 64) == 0) {
            return Fail(name, "ciphertext shares a prefix with the plaintext", t0);
        }
        std::vector<uint8_t> back(plain.size());
        size_t got = 0;
        if (!BlockCipher::Decrypt(std::span<const uint8_t>(key, sizeof(key)), nonce,
                                  std::span<const uint8_t>(aad.data(), aad.size()),
                                  std::span<const uint8_t>(cipher.data(), cipher.size()), back.data(), back.size(),
                                  got)) {
            return Fail(name, "decryption of a valid ciphertext failed", t0);
        }
        if (got != plain.size() || memcmp(back.data(), plain.data(), plain.size()) != 0) {
            return Fail(name, "the decrypted bytes differ from the plaintext", t0);
        }
        std::vector<uint8_t> tampered = cipher;
        tampered[100] ^= 0x80;
        if (BlockCipher::Decrypt(std::span<const uint8_t>(key, sizeof(key)), nonce,
                                 std::span<const uint8_t>(aad.data(), aad.size()),
                                 std::span<const uint8_t>(tampered.data(), tampered.size()), back.data(),
                                 back.size(), got)) {
            return Fail(name, "a flipped ciphertext byte still authenticated", t0);
        }
        std::array<uint8_t, 40> bad_aad = aad;
        bad_aad[39] ^= 0x01;
        if (BlockCipher::Decrypt(std::span<const uint8_t>(key, sizeof(key)), nonce,
                                 std::span<const uint8_t>(bad_aad.data(), bad_aad.size()),
                                 std::span<const uint8_t>(cipher.data(), cipher.size()), back.data(), back.size(),
                                 got)) {
            return Fail(name, "a modified chunk index in the additional data still authenticated", t0);
        }
        uint8_t other[BlockCipher::kKeyBytes];
        memcpy(other, key, sizeof(key));
        other[0] ^= 0xFF;
        if (BlockCipher::Decrypt(std::span<const uint8_t>(other, sizeof(other)), nonce,
                                 std::span<const uint8_t>(aad.data(), aad.size()),
                                 std::span<const uint8_t>(cipher.data(), cipher.size()), back.data(), back.size(),
                                 got)) {
            return Fail(name, "a different key still authenticated the chunk", t0);
        }
        sodium_memzero(key, sizeof(key));
        sodium_memzero(other, sizeof(other));
        (void)verbose;
        return Pass(name, FormatErrorF("XChaCha20-Poly1305 round trip, %zu byte chunk, tag %zu bytes, tamper / "
                                       "aad / key rejection",
                                       plain.size(), BlockCipher::kTagBytes),
                    t0);
    } catch (const AiError& e) {
        return Fail(name, e.Message(), t0);
    } catch (const std::exception& e) {
        return Fail(name, e.what(), t0);
    }
}

SelfTestResult SelfTest::KdfAndKeys(bool verbose) {
    const std::string name = "kdf-and-keyring";
    auto t0 = std::chrono::steady_clock::now();
    try {
        SodiumStartup();
        KdfParams p = KdfParams::Generate(1, 65536);
        p.ClampToLibraryLimits();
        DerivedKey a = KdfDerive("self-test-passphrase", p);
        DerivedKey b = KdfDerive("self-test-passphrase", p);
        if (a.key.size() != kMasterKeyBytes) return Fail(name, "the derived master key has the wrong length", t0);
        if (memcmp(a.key.data(), b.key.data(), a.key.size()) != 0) {
            return Fail(name, "the same password and salt derived different keys", t0);
        }
        if (!KdfVerify("self-test-passphrase", p, a.key.Span())) {
            return Fail(name, "KdfVerify rejected the correct password", t0);
        }
        if (KdfVerify("self-test-passphrasf", p, a.key.Span())) {
            return Fail(name, "KdfVerify accepted the wrong password", t0);
        }
        KdfParams q = p;
        q.salt[0] ^= 0x5A;
        DerivedKey c = KdfDerive("self-test-passphrase", q);
        if (memcmp(a.key.data(), c.key.data(), a.key.size()) == 0) {
            return Fail(name, "a different salt derived the same key", t0);
        }
        std::array<uint8_t, 16> id1{}, id2{};
        random::Bytes(id1.data(), 16);
        memcpy(id2.data(), id1.data(), 16);
        id2[3] ^= 0x11;
        KeyRing r1 = KeyRing::Derive(a.key, std::span<const uint8_t, 16>(id1.data(), 16));
        KeyRing r2 = KeyRing::Derive(a.key, std::span<const uint8_t, 16>(id2.data(), 16));
        KeyRing r3 = KeyRing::Derive(a.key, std::span<const uint8_t, 16>(id1.data(), 16));
        if (memcmp(r1.weights.data(), r3.weights.data(), r1.weights.size()) != 0) {
            return Fail(name, "the keyring is not deterministic", t0);
        }
        if (memcmp(r1.weights.data(), r2.weights.data(), r1.weights.size()) == 0) {
            return Fail(name, "a different container id derived the same weight key", t0);
        }
        const SecureBytes* subs[6] = {&r1.weights, &r1.manifest, &r1.bytecode,
                                      &r1.integrity, &r1.rmp,       &r1.vocab};
        for (int i = 0; i < 6; i++) {
            if (subs[i]->size() != BlockCipher::kKeyBytes) {
                return Fail(name, "a subkey has the wrong length", t0);
            }
            for (int j = i + 1; j < 6; j++) {
                if (memcmp(subs[i]->data(), subs[j]->data(), subs[i]->size()) == 0) {
                    return Fail(name, "two subkeys are identical", t0);
                }
            }
        }
        if (memcmp(r1.master.data(), r1.weights.data(), r1.master.size()) == 0) {
            return Fail(name, "the master key is reused directly as a subkey", t0);
        }
        r1.Clear();
        r2.Clear();
        r3.Clear();
        a.Clear();
        b.Clear();
        c.Clear();
        (void)verbose;
        return Pass(name, "Argon2id determinism, salt sensitivity, password verification, and six separated "
                          "HMAC-SHA-512/256 subkeys",
                    t0);
    } catch (const AiError& e) {
        return Fail(name, e.Message(), t0);
    } catch (const std::exception& e) {
        return Fail(name, e.what(), t0);
    }
}

}
namespace aip {

SelfTestResult SelfTest::GgufSynthetic(bool verbose) {
    const std::string name = "gguf-synthetic";
    auto t0 = std::chrono::steady_clock::now();
    TempFiles tf;
    try {
        std::vector<uint8_t> blob = TinyModelFactory::BuildGguf(2, 128, 256, 4, 2, 80, 2, 0x1234ull, "llama");
        std::string path = tf.Add("gguf", ".gguf");
        WriteFileAll(path, std::span<const uint8_t>(blob.data(), blob.size()));
        FileReader fr;
        std::string err;
        if (!fr.Open(path, err)) return Fail(name, "cannot reopen the synthetic model: " + err, t0);
        GgufInfo g = GgufReader::Parse(path, fr, true);
        GgufReader::ValidateLayout(g);
        if (g.version != 3) return Fail(name, FormatErrorF("version %u instead of 3", g.version), t0);
        if (g.tensors.size() != 21) {
            return Fail(name, FormatErrorF("%zu tensors instead of 21", g.tensors.size()), t0);
        }
        if (g.alignment != 32) return Fail(name, "alignment was not read", t0);
        if (g.data_start % 32 != 0) return Fail(name, "the data section is not aligned", t0);
        if (!g.Has("llama.embedding_length")) return Fail(name, "metadata key missing", t0);
        ModelSpec spec = ModelSpec::FromGguf(g);
        spec.Validate();
        if (spec.arch != ArchId::kLlama || spec.n_layer != 2 || spec.n_embd != 128 || spec.n_ff != 256 ||
            spec.n_head != 4 || spec.n_head_kv != 2 || spec.head_dim != 32 || spec.n_vocab != 80 ||
            spec.tied_output) {
            return Fail(name, "the parsed model spec does not match what was written", t0);
        }
        VocabData v = VocabData::FromGguf(g);
        if (v.tokens.size() != 80 || v.eos != 2) return Fail(name, "the vocabulary was not parsed", t0);
        const GgufTensorInfo* tq = g.FindTensor("blk.1.attn_q.weight");
        if (!tq || tq->n_rows != 128 || tq->row_elems != 128 || tq->type_id != 2) {
            return Fail(name, "tensor geometry was not derived correctly", t0);
        }
        uint64_t last_end = 0;
        uint64_t total = 0;
        for (const auto& t : g.tensors) {
            total += t.n_bytes;
            if (t.rel_offset + t.n_bytes > last_end) last_end = t.rel_offset + t.n_bytes;
            if (t.rel_offset % t.type_size != 0) {
                return Fail(name, "a tensor offset is not aligned to its storage type", t0);
            }
        }
        if (g.data_start + last_end != g.file_size) {
            return Fail(name, FormatErrorF("the last tensor ends at %llu but the file is %llu bytes",
                                          static_cast<unsigned long long>(g.data_start + last_end),
                                          static_cast<unsigned long long>(g.file_size)),
                        t0);
        }
        if (g.data_start + total > g.file_size) {
            return Fail(name, "the tensor payloads do not fit in the file", t0);
        }
        (void)verbose;
        return Pass(name, FormatErrorF("wrote and re-parsed a %s GGUF v3 model with %zu tensors and %llu metadata "
                                       "entries",
                                       HumanBytes(blob.size()).c_str(), g.tensors.size(),
                                       static_cast<unsigned long long>(g.n_kv)),
                    t0);
    } catch (const AiError& e) {
        return Fail(name, e.Message(), t0);
    } catch (const std::exception& e) {
        return Fail(name, e.what(), t0);
    }
}

SelfTestResult SelfTest::GgufMalformed(bool verbose) {
    const std::string name = "gguf-malformed";
    auto t0 = std::chrono::steady_clock::now();
    TempFiles tf;
    try {
        std::vector<uint8_t> blob = TinyModelFactory::BuildGguf(1, 128, 256, 4, 2, 80, 2, 0x99ull, "llama");
        std::string base = tf.Add("base", ".gguf");
        WriteFileAll(base, std::span<const uint8_t>(blob.data(), blob.size()));

        struct Case {
            const char* label;
            std::vector<uint8_t> data;
        };
        std::vector<Case> cases;
        {
            Case c;
            c.label = "bad magic";
            c.data = blob;
            c.data[0] = 'X';
            cases.push_back(std::move(c));
        }
        {
            Case c;
            c.label = "version 1";
            c.data = blob;
            uint32_t one = 1;
            memcpy(c.data.data() + 4, &one, 4);
            cases.push_back(std::move(c));
        }
        {
            Case c;
            c.label = "version 99";
            c.data = blob;
            uint32_t v = 99;
            memcpy(c.data.data() + 4, &v, 4);
            cases.push_back(std::move(c));
        }
        {
            Case c;
            c.label = "truncated header";
            c.data.assign(blob.begin(), blob.begin() + 12);
            cases.push_back(std::move(c));
        }
        {
            Case c;
            c.label = "truncated payload";
            c.data.assign(blob.begin(), blob.begin() + static_cast<long>(blob.size() / 2));
            cases.push_back(std::move(c));
        }
        {
            Case c;
            c.label = "absurd tensor count";
            c.data = blob;
            uint64_t huge = 0xFFFFFFFFFFFFull;
            memcpy(c.data.data() + 8, &huge, 8);
            cases.push_back(std::move(c));
        }
        {
            Case c;
            c.label = "absurd kv count";
            c.data = blob;
            uint64_t huge = 0xFFFFFFFFFFFFull;
            memcpy(c.data.data() + 16, &huge, 8);
            cases.push_back(std::move(c));
        }
        {
            Case c;
            c.label = "zero alignment";
            c.data = blob;
            size_t at = 0;
            const char* key = "general.alignment";
            for (size_t i = 24; i + strlen(key) < c.data.size(); i++) {
                if (memcmp(c.data.data() + i, key, strlen(key)) == 0) {
                    at = i;
                    break;
                }
            }
            if (at == 0) return Fail(name, "the fixture does not carry general.alignment", t0);
            uint32_t zero = 0;
            memcpy(c.data.data() + at + strlen(key) + 4, &zero, 4);
            cases.push_back(std::move(c));
        }
        size_t rejected = 0;
        for (auto& c : cases) {
            std::string path = tf.Add("bad", ".gguf");
            WriteFileAll(path, std::span<const uint8_t>(c.data.data(), c.data.size()));
            FileReader fr;
            std::string err;
            bool threw = false;
            std::string message;
            try {
                if (!fr.Open(path, err)) ThrowErrorF(ErrClass::kIoInput, "%s", err.c_str());
                GgufInfo g = GgufReader::Parse(path, fr, true);
                GgufReader::ValidateLayout(g);
                ModelSpec spec = ModelSpec::FromGguf(g);
                spec.Validate();
            } catch (const AiError& e) {
                threw = true;
                message = e.Message();
            }
            if (!threw) {
                return Fail(name, std::string("the '") + c.label + "' fixture was accepted", t0);
            }
            if (message.empty()) return Fail(name, "a malformed file raised an empty error", t0);
            rejected++;
            if (verbose) Console::OutF("      rejected %-20s : %s\n", c.label, message.c_str());
            AtomicFileWriter::RemoveFile(path);
            tf.paths.pop_back();
        }
        {
            std::string path = tf.Add("arch", ".gguf");
            std::vector<uint8_t> data = blob;
            const char* from = "llama";
            const char* to = "grok4x";
            size_t at = 0;
            for (size_t i = 24; i + 5 < data.size(); i++) {
                if (memcmp(data.data() + i, from, 5) == 0) {
                    at = i;
                    break;
                }
            }
            if (at == 0) return Fail(name, "the fixture does not carry the architecture name", t0);
            memcpy(data.data() + at, to, 5);
            WriteFileAll(path, std::span<const uint8_t>(data.data(), data.size()));
            FileReader fr;
            std::string err;
            ExitCode code = ExitCode::kOk;
            bool threw = false;
            try {
                if (!fr.Open(path, err)) ThrowErrorF(ErrClass::kIoInput, "%s", err.c_str());
                GgufInfo g = GgufReader::Parse(path, fr, true);
                ModelSpec spec = ModelSpec::FromGguf(g);
                spec.Validate();
            } catch (const AiError& e) {
                threw = true;
                code = e.Code();
                if (verbose) Console::OutF("      unsupported architecture : %s\n", e.Message().c_str());
            }
            if (!threw) return Fail(name, "an unknown architecture was accepted", t0);
            if (code != ExitCode::kUnsupportedModel) {
                return Fail(name, "an unknown architecture did not map to exit code 6", t0);
            }
            rejected++;
        }
        (void)verbose;
        return Pass(name, FormatErrorF("%zu malformed or unsupported inputs were rejected with concrete errors",
                                       rejected),
                    t0);
    } catch (const AiError& e) {
        return Fail(name, e.Message(), t0);
    } catch (const std::exception& e) {
        return Fail(name, e.what(), t0);
    }
}

SelfTestResult SelfTest::DequantReference(bool verbose) {
    const std::string name = "dequant-reference";
    auto t0 = std::chrono::steady_clock::now();
    try {
        const uint32_t types[] = {0, 1, 2, 3, 6, 7, 8, 12, 14, 20};
        size_t checked = 0;
        size_t kat_checked = 0;
        for (uint32_t type : types) {
            if (!quant::IsSupported(type)) {
                return Fail(name, FormatErrorF("type %u should be supported", type), t0);
            }
            uint64_t k = 512;
            std::vector<uint8_t> a = quant::EncodeReferenceBlock(type, 12345 + type, k);
            std::vector<uint8_t> b = quant::EncodeReferenceBlock(type, 12345 + type, k);
            if (a != b) return Fail(name, FormatErrorF("type %u encoding is not deterministic", type), t0);
            if (a.size() != quant::TotalBytes(type, k)) {
                return Fail(name, FormatErrorF("type %u produced %zu bytes instead of %llu", type, a.size(),
                                               static_cast<unsigned long long>(quant::TotalBytes(type, k))),
                            t0);
            }
            std::vector<float> x(static_cast<size_t>(k));
            std::vector<float> y(static_cast<size_t>(k));
            quant::DequantizeRow(type, a.data(), x.data(), k);
            if (!quant::DequantizeRowChecked(type, a.data(), a.size(), y.data(), k)) {
                return Fail(name, FormatErrorF("type %u rejected a valid buffer", type), t0);
            }
            for (uint64_t i = 0; i < k; i++) {
                if (!std::isfinite(x[i])) {
                    return Fail(name, FormatErrorF("type %u produced a non finite value at %llu", type,
                                                   static_cast<unsigned long long>(i)),
                                t0);
                }
                if (x[i] != y[i]) {
                    return Fail(name, FormatErrorF("type %u dequantization is not reproducible", type), t0);
                }
            }
            if (quant::DequantizeRowChecked(type, a.data(), a.size() - 1, y.data(), k)) {
                return Fail(name, FormatErrorF("type %u accepted a truncated buffer", type), t0);
            }
            checked++;
        }
        {
            std::vector<float> src = {0.0f, 1.0f, -1.0f, 0.5f, -0.25f, 3.0f, -7.5f, 0.125f};
            for (float v : src) {
                uint16_t h = quant::FloatToHalf(v);
                float back = quant::HalfToFloat(h);
                if (back != v) {
                    return Fail(name, FormatErrorF("half round trip changed %.9g to %.9g",
                                                   static_cast<double>(v), static_cast<double>(back)),
                                t0);
                }
            }
        }
        {
            uint8_t block[18];
            uint16_t d = quant::FloatToHalf(0.5f);
            memcpy(block, &d, 2);
            for (int i = 0; i < 16; i++) block[2 + i] = static_cast<uint8_t>((i << 4) | (15 - i));
            float out[32];
            quant::DequantizeRow(2, block, out, 32);
            for (int i = 0; i < 32; i++) {
                int lo = (i % 16);
                int q = (i < 16) ? (block[2 + lo] & 0x0F) : ((block[2 + lo] >> 4) & 0x0F);
                float expect = 0.5f * static_cast<float>(q - 8);
                if (std::fabs(out[i] - expect) > 1e-6f) {
                    return Fail(name, FormatErrorF("q4_0 element %d decoded to %.9g instead of %.9g", i,
                                                   static_cast<double>(out[i]), static_cast<double>(expect)),
                                t0);
                }
            }
        }
        {
            std::vector<float> src(64);
            for (int i = 0; i < 64; i++) src[i] = static_cast<float>(i - 32) * 0.031f;
            std::vector<uint8_t> q(static_cast<size_t>(quant::TotalBytes(8, 64)));
            quant::QuantizeRowQ8_0(src.data(), q.data(), 64);
            std::vector<float> back(64);
            quant::DequantizeRow(8, q.data(), back.data(), 64);
            double worst = 0.0;
            for (int i = 0; i < 64; i++) worst = std::max(worst, static_cast<double>(std::fabs(back[i] - src[i])));
            if (worst > 0.02) {
                return Fail(name, FormatErrorF("q8_0 requantization error %.6f is too large", worst), t0);
            }
            if (verbose) Console::OutF("      q8_0 worst absolute error %.6f\n", worst);
        }
        {
            struct KatVector {
                uint32_t type;
                uint32_t bits[4];
            };
            static const KatVector vectors[] = {
                {2, {0x3D45D000u, 0x80000000u, 0xBD684000u, 0xBC63C000u}},
                {3, {0x3D0D7800u, 0xBF037D80u, 0x3E2BC880u, 0x3E3DCAE0u}},
                {6, {0xBD202000u, 0x3DC0D400u, 0xBEBF4000u, 0x3D9B0000u}},
                {7, {0xBF397D40u, 0x3D9CF300u, 0x3E853580u, 0xBCFD3000u}},
                {8, {0xBDE6D600u, 0xC09A6700u, 0x405CDC40u, 0x3F156A00u}},
                {10, {0xBE68BE00u, 0xBF235700u, 0x3CB07000u, 0x3C307000u}},
                {11, {0x3F6F1400u, 0x3F411A00u, 0xBE185800u, 0xBE891C00u}},
                {12, {0x3E822400u, 0x3F125300u, 0x3E359740u, 0x3C8B1400u}},
                {13, {0x4152CE4Au, 0x401D923Au, 0xC0197460u, 0xC0757530u}},
                {14, {0x3ED7A180u, 0x400B6AA0u, 0xC061A000u, 0x40964B00u}},
                {20, {0x3F376380u, 0xBD3BA000u, 0xBF357200u, 0xBE0E5800u}},
            };
            for (const KatVector& kat : vectors) {
                std::vector<uint8_t> raw = quant::EncodeReferenceBlock(kat.type, 0xABCDEFull, 512);
                std::vector<float> row(512, 0.0f);
                if (!quant::DequantizeRowChecked(kat.type, raw.data(), raw.size(), row.data(), 512)) {
                    return Fail(name, FormatErrorF("type %u rejected its known answer vector buffer", kat.type), t0);
                }
                for (int i = 0; i < 4; i++) {
                    uint32_t bits = 0;
                    memcpy(&bits, &row[static_cast<size_t>(i) * 128], sizeof(bits));
                    if (bits != kat.bits[i]) {
                        return Fail(name, FormatErrorF("type %u element %d decoded to 0x%08X while the reference "
                                                       "decoder produces 0x%08X",
                                                       kat.type, i * 128, bits, kat.bits[i]),
                                    t0);
                    }
                }
                kat_checked++;
            }
        }
        std::vector<std::string> names = quant::SupportedNames();
        if (names.size() < 8) return Fail(name, "the supported format list looks incomplete", t0);
        return Pass(name, FormatErrorF("%zu storage formats encode, dequantize, and reject truncation; %zu formats "
                                       "reproduce known answer vectors captured from the reference llama.cpp "
                                       "decoder bit for bit; q4_0 matches a hand computed block; q8_0 "
                                       "requantization error is bounded",
                                       checked, kat_checked),
                    t0);
    } catch (const AiError& e) {
        return Fail(name, e.Message(), t0);
    } catch (const std::exception& e) {
        return Fail(name, e.what(), t0);
    }
}

struct SyntheticWeightProvider : public WeightProvider {
    WeightLayout layout;
    std::unordered_map<uint32_t, std::vector<float>> vectors;
    uint64_t rows = 0;

    const TensorSlot* Slot(uint32_t id) const override { return layout.FindBySlot(id); }
    size_t SlotCount() const override { return layout.slots.size(); }
    void ReadRow(uint32_t id, uint64_t row, float* out) override {
        const TensorSlot* s = Slot(id);
        if (!s) ThrowErrorF(ErrClass::kRuntime, "slot %u missing", id);
        uint64_t h = static_cast<uint64_t>(id) * 1000003ull + row * 9176ull + 7ull;
        for (uint64_t i = 0; i < s->row_elems; i++) {
            h = h * 6364136223846793005ull + 1442695040888963407ull;
            uint32_t v = static_cast<uint32_t>((h >> 33) & 0xFFFFu);
            out[i] = (static_cast<float>(v) - 32768.0f) / 32768.0f * 0.125f;
        }
        rows++;
    }
    const float* Vector(uint32_t id) override {
        auto it = vectors.find(id);
        if (it != vectors.end()) return it->second.data();
        const TensorSlot* s = Slot(id);
        if (!s) ThrowErrorF(ErrClass::kRuntime, "slot %u missing", id);
        std::vector<float> v(static_cast<size_t>(s->row_elems), 1.0f);
        return vectors.emplace(id, std::move(v)).first->second.data();
    }
    void ReadRaw(uint32_t, uint64_t, void* dst, size_t n) override { memset(dst, 0, n); }
    void ReadRowRaw(uint32_t id, uint64_t, uint8_t* dst) override {
        const TensorSlot* s = Slot(id);
        memset(dst, 0, s ? static_cast<size_t>(s->row_bytes) : 0);
    }
    void SlotDigest(uint32_t, uint8_t out[32]) override { memset(out, 0x5A, 32); }
    uint64_t BytesDecrypted() const override { return 0; }
    uint64_t RowsServed() const override { return rows; }
};

static WeightLayout SyntheticLayout(const ModelSpec& spec) {
    WeightLayout l;
    l.storage_type = 1;
    uint64_t off = 0;
    for (const auto& req : spec.required_tensors) {
        TensorSlot s;
        s.slot_id = static_cast<uint32_t>(l.slots.size());
        s.name = req.name;
        s.role = req.role;
        s.layer = req.layer;
        bool vector_like = req.expect_dims.size() == 1;
        s.type_id = vector_like ? 0u : 2u;
        uint64_t n = 1;
        for (size_t i = 0; i < req.expect_dims.size(); i++) {
            s.dims[i] = req.expect_dims[i];
            n *= req.expect_dims[i];
        }
        s.n_dims = static_cast<uint32_t>(req.expect_dims.size());
        s.n_elems = n;
        s.row_elems = req.expect_dims[0];
        s.n_rows = s.n_dims > 1 ? req.expect_dims[1] : 1;
        s.block_size = quant::BlockSize(s.type_id);
        s.type_size = quant::TypeSize(s.type_id);
        s.row_bytes = quant::RowBytes(s.type_id, s.row_elems);
        s.total_bytes = quant::TotalBytes(s.type_id, s.n_elems);
        s.dst_offset = off;
        s.dst_size = s.total_bytes;
        off += s.total_bytes;
        s.present = true;
        l.index.emplace(s.name, s.slot_id);
        l.slots.push_back(std::move(s));
    }
    l.total_plain_bytes = off;
    return l;
}

SelfTestResult SelfTest::BytecodeVerifier(bool verbose) {
    const std::string name = "bytecode-verifier";
    auto t0 = std::chrono::steady_clock::now();
    try {
        ModelSpec spec = TinyModelFactory::SpecFor(2, 128, 256, 4, 2, 80, "llama");
        WeightLayout layout = SyntheticLayout(spec);
        ModelGraph graph = ModelGraph::BuildForArch(spec, layout);
        std::string err;
        if (!graph.Validate(err)) return Fail(name, "the reference graph failed validation: " + err, t0);
        VmProgram prog = BytecodeCompiler::Compile(graph, spec, layout, 64, true, err);
        if (!err.empty() || prog.code.empty()) {
            return Fail(name, "compilation failed: " + err, t0);
        }
        if (!BytecodeVerifier::Verify(prog, err)) return Fail(name, "a fresh program failed verification: " + err, t0);
        std::vector<uint8_t> blob = prog.Serialize();
        VmProgram back = VmProgram::FromBlob(std::span<const uint8_t>(blob.data(), blob.size()));
        if (!back.Verify(err)) return Fail(name, "the serialized program failed verification: " + err, t0);
        if (back.code.size() != prog.code.size() || back.header.instr_count != prog.header.instr_count) {
            return Fail(name, "serialization did not round trip", t0);
        }
        uint8_t d1[32], d2[32];
        prog.ComputeDigest(d1);
        back.ComputeDigest(d2);
        if (memcmp(d1, d2, 32) != 0) return Fail(name, "the program digest is not stable", t0);

        size_t mutations_caught = 0;
        size_t mutations = 0;
        auto check = [&](const char* label, VmProgram p) {
            std::string e;
            p.ComputeDigest(p.header.program_digest);
            bool ok = BytecodeVerifier::Verify(p, e);
            mutations++;
            if (!ok) {
                mutations_caught++;
                if (verbose) Console::OutF("      rejected %-28s : %s\n", label, e.c_str());
            } else {
                throw AiError(ErrClass::kInternal, std::string("the verifier accepted a program with ") + label);
            }
        };
        {
            VmProgram p = back;
            p.code.clear();
            check("no instructions", p);
        }
        {
            VmProgram p = back;
            bool found = false;
            for (auto& in : p.code) {
                if (in.op == static_cast<uint16_t>(VmOp::kHalt)) {
                    in.op = static_cast<uint16_t>(VmOp::kNop);
                    found = true;
                    break;
                }
            }
            if (!found) return Fail(name, "the program has no halt instruction", t0);
            check("missing halt", p);
        }
        {
            VmProgram p = back;
            p.code[0].op = 4095;
            check("unknown opcode", p);
        }
        {
            VmProgram p = back;
            p.header.reg_count = 0;
            p.regs.clear();
            check("empty register table", p);
        }
        {
            VmProgram p = back;
            bool found = false;
            for (auto& in : p.code) {
                if (in.op == static_cast<uint16_t>(VmOp::kMulMatVec)) {
                    in.slot = static_cast<uint16_t>(p.slots.size());
                    found = true;
                    break;
                }
            }
            if (!found) return Fail(name, "the program has no matrix vector instruction", t0);
            check("weight slot out of range", p);
        }
        {
            VmProgram p = back;
            bool found = false;
            for (auto& in : p.code) {
                if (in.op == static_cast<uint16_t>(VmOp::kRmsNorm)) {
                    in.dst = static_cast<uint16_t>(p.regs.size());
                    found = true;
                    break;
                }
            }
            if (!found) return Fail(name, "the program has no rms norm instruction", t0);
            check("register out of range", p);
        }
        {
            VmProgram p = back;
            p.header.program_digest[0] ^= 0xFF;
            std::string e;
            mutations++;
            if (!BytecodeVerifier::Verify(p, e)) {
                mutations_caught++;
                if (verbose) Console::OutF("      rejected %-28s : %s\n", "corrupted digest", e.c_str());
            } else {
                return Fail(name, "the verifier accepted a corrupted program digest", t0);
            }
        }
        {
            std::vector<uint8_t> bad = blob;
            if (bad.size() > 40) bad[bad.size() - 5] ^= 0x3C;
            bool threw = false;
            try {
                VmProgram p = VmProgram::FromBlob(std::span<const uint8_t>(bad.data(), bad.size()));
                std::string e;
                threw = !p.Verify(e);
            } catch (const AiError&) {
                threw = true;
            }
            mutations++;
            if (threw) mutations_caught++;
        }
        return Pass(name, FormatErrorF("%u instructions, %u registers, %u weight slots; %zu of %zu mutations "
                                       "rejected",
                                       prog.header.instr_count, prog.header.reg_count, prog.header.slot_count,
                                       mutations_caught, mutations),
                    t0);
    } catch (const AiError& e) {
        return Fail(name, e.Message(), t0);
    } catch (const std::exception& e) {
        return Fail(name, e.what(), t0);
    }
}

SelfTestResult SelfTest::VmMicroProgram(bool verbose) {
    const std::string name = "vm-execution";
    auto t0 = std::chrono::steady_clock::now();
    try {
        ModelSpec spec = TinyModelFactory::SpecFor(2, 128, 256, 4, 2, 80, "llama");
        WeightLayout layout = SyntheticLayout(spec);
        ModelGraph graph = ModelGraph::BuildForArch(spec, layout);
        std::string err;
        VmProgram prog = BytecodeCompiler::Compile(graph, spec, layout, 32, false, err);
        if (!err.empty()) return Fail(name, "compilation failed: " + err, t0);
        SyntheticWeightProvider provider;
        provider.layout = layout;
        VirtualMachine::Limits limits;
        VirtualMachine vm(prog, provider, limits);
        vm.Configure(16, 1);
        if (!vm.Prepare(err)) return Fail(name, "prepare failed: " + err, t0);
        if (vm.LogitsSize() != spec.n_vocab) {
            return Fail(name, FormatErrorF("logits width %u instead of %u", vm.LogitsSize(), spec.n_vocab), t0);
        }
        std::vector<float> first(spec.n_vocab);
        for (int32_t pos = 0; pos < 4; pos++) {
            const float* lg = vm.Forward(3 + pos, pos, nullptr);
            if (!lg) return Fail(name, "the virtual machine produced no logits", t0);
            for (uint32_t i = 0; i < spec.n_vocab; i++) {
                if (!std::isfinite(lg[i])) {
                    return Fail(name, FormatErrorF("logit %u at position %d is not finite", i, pos), t0);
                }
            }
            if (pos == 0) memcpy(first.data(), lg, sizeof(float) * spec.n_vocab);
        }
        VirtualMachine vm2(prog, provider, limits);
        vm2.Configure(16, 1);
        if (!vm2.Prepare(err)) return Fail(name, "second prepare failed: " + err, t0);
        const float* lg2 = vm2.Forward(3, 0, nullptr);
        for (uint32_t i = 0; i < spec.n_vocab; i++) {
            if (first[i] != lg2[i]) {
                return Fail(name, FormatErrorF("a replay produced logit %u = %.9g instead of %.9g", i,
                                               static_cast<double>(lg2[i]), static_cast<double>(first[i])),
                            t0);
            }
        }
        bool caught = false;
        try {
            vm2.Forward(1, 4096, nullptr);
        } catch (const AiError& e) {
            caught = e.Code() == ExitCode::kRuntimeError;
        }
        if (!caught) return Fail(name, "a position beyond the compiled context was accepted", t0);
        uint64_t expected = prog.header.instr_count;
        if (vm.InstructionsExecuted() < expected) {
            return Fail(name, "the virtual machine executed fewer instructions than the program holds", t0);
        }
        if (provider.RowsServed() == 0) return Fail(name, "no weight rows were served", t0);
        (void)verbose;
        return Pass(name, FormatErrorF("executed %u instructions per token across 4 positions, %llu weight rows "
                                       "served, bitwise reproducible, out of range position rejected",
                                       prog.header.instr_count,
                                       static_cast<unsigned long long>(provider.RowsServed())),
                    t0);
    } catch (const AiError& e) {
        return Fail(name, e.Message(), t0);
    } catch (const std::exception& e) {
        return Fail(name, e.what(), t0);
    }
}

}
namespace aip {

SelfTestResult SelfTest::ContainerRoundTrip(bool verbose) {
    const std::string name = "container-round-trip";
    auto t0 = std::chrono::steady_clock::now();
    TempFiles tf;
    try {
        std::vector<uint8_t> blob = TinyModelFactory::BuildGguf(2, 128, 256, 4, 2, 80, 2, 0xC0FFEEull, "llama");
        std::string src = tf.Add("src", ".gguf");
        WriteFileAll(src, std::span<const uint8_t>(blob.data(), blob.size()));
        const char* password = "self-test-passphrase";

        ProtectOptions full = TinyProtectOptions(src, tf.Add("full", ".aip"));
        ProtectReport rep = ContainerWriter::Protect(full, password, nullptr);
        if (rep.tensors != 21) return Fail(name, FormatErrorF("%llu tensors instead of 21",
                                                             static_cast<unsigned long long>(rep.tensors)), t0);
        if (rep.weights_plain_bytes != rep.manifest.weights_plain_bytes || rep.weights_plain_bytes == 0) {
            return Fail(name, "the weight stream size was not recorded", t0);
        }
        if (rep.chunks == 0) return Fail(name, "no encrypted chunks were written", t0);
        if (!rep.transform.enabled) {
            return Fail(name, "the transform was not applied to a model that qualifies for it", t0);
        }
        if (rep.output_bytes >= rep.source_bytes + 65536) {
            return Fail(name, "the container is unexpectedly larger than the source model", t0);
        }

        RunOptions ro = TinyRunOptions(full.output);
        std::vector<int32_t> prompt = {1, 20, 21, 22};
        std::vector<int32_t> gen_a;
        ProtectedRuntime::GenerationStats stats_a;
        {
            std::unique_ptr<ContainerHandle> h = ProtectedRuntime::Open(full.output, password, ro);
            if (!h) return Fail(name, "the container could not be reopened", t0);
            if (!h->vm_enabled) return Fail(name, "the container should carry bytecode", t0);
            if (!h->rmp_enabled) return Fail(name, "the container should carry a protection record", t0);
            if (ContainerReader::FindSection(h->sections, SectionPurpose::kVocab) == nullptr) {
                return Fail(name, "the container carries no vocabulary section", t0);
            }
            if (h->manifest.vocab.tokens.size() != 80 || h->manifest.vocab.model != "llama") {
                return Fail(name, FormatErrorF("the vocabulary section held %zu tokens of model '%s'",
                                               h->manifest.vocab.tokens.size(), h->manifest.vocab.model.c_str()),
                            t0);
            }
            if ((h->header.flags & kFlagWeightTransform) == 0) {
                return Fail(name, "the transform flag was not recorded in the header", t0);
            }
            ProtectedRuntime::Generate(*h, prompt, ro, gen_a, stats_a);
        }
        if (gen_a.size() != ro.n_predict) {
            return Fail(name, FormatErrorF("generated %zu tokens instead of %u", gen_a.size(), ro.n_predict), t0);
        }
        for (int32_t id : gen_a) {
            if (id < 0 || static_cast<uint32_t>(id) >= 80) {
                return Fail(name, FormatErrorF("generated token %d is outside the vocabulary", id), t0);
            }
        }
        {
            std::unique_ptr<ContainerHandle> h = ProtectedRuntime::Open(full.output, password, ro);
            std::vector<int32_t> gen_b;
            ProtectedRuntime::GenerationStats stats_b;
            ProtectedRuntime::Generate(*h, prompt, ro, gen_b, stats_b);
            if (gen_a != gen_b) return Fail(name, "the same container produced different tokens on a replay", t0);
        }

        ProtectOptions novm = TinyProtectOptions(src, tf.Add("novm", ".aip"));
        novm.vm = false;
        ProtectReport rep_novm = ContainerWriter::Protect(novm, password, nullptr);
        if (rep_novm.instr_count != 0) return Fail(name, "--no-vm still stored bytecode", t0);
        std::vector<int32_t> gen_novm;
        ProtectedRuntime::GenerationStats stats_novm;
        {
            std::unique_ptr<ContainerHandle> h = ProtectedRuntime::Open(novm.output, password, ro);
            if (h->vm_enabled) return Fail(name, "--no-vm was not honoured by the runtime", t0);
            if ((h->header.flags & kFlagVirtualized) != 0) {
                return Fail(name, "--no-vm still set the virtualized header flag", t0);
            }
            ProtectedRuntime::Generate(*h, prompt, ro, gen_novm, stats_novm);
        }
        if (gen_novm != gen_a) {
            return Fail(name, "the recompiled graph produced different tokens from the stored bytecode", t0);
        }

        ProtectOptions nortransform = TinyProtectOptions(src, tf.Add("plain", ".aip"));
        nortransform.transform = false;
        ProtectReport rep_plain = ContainerWriter::Protect(nortransform, password, nullptr);
        if (rep_plain.transform.enabled) {
            return Fail(name, "--no-transform still applied a weight transform", t0);
        }
        std::vector<int32_t> gen_plain;
        ProtectedRuntime::GenerationStats stats_plain;
        {
            std::unique_ptr<ContainerHandle> h = ProtectedRuntime::Open(nortransform.output, password, ro);
            if ((h->header.flags & kFlagWeightTransform) != 0) {
                return Fail(name, "--no-transform still set the header flag", t0);
            }
            ProtectedRuntime::Generate(*h, prompt, ro, gen_plain, stats_plain);
        }
        if (gen_plain != gen_a) {
            return Fail(name, "the weight representation transform changed the generated tokens", t0);
        }

        ProtectOptions norrm = TinyProtectOptions(src, tf.Add("norrhmp", ".aip"));
        norrm.rmp = false;
        ProtectReport rep_norrm = ContainerWriter::Protect(norrm, password, nullptr);
        {
            std::unique_ptr<ContainerHandle> h = ProtectedRuntime::Open(norrm.output, password, ro);
            if (h->rmp_enabled) return Fail(name, "--no-rmp still enabled runtime protection", t0);
            if ((h->header.flags & kFlagRmpEnabled) != 0) {
                return Fail(name, "--no-rmp still set the header flag", t0);
            }
            if (ContainerReader::FindSection(h->sections, SectionPurpose::kRmp) != nullptr) {
                return Fail(name, "--no-rmp still wrote a protection record", t0);
            }
            if (rep_norrm.manifest.rmp.policy.enabled) {
                return Fail(name, "--no-rmp was not recorded in the manifest", t0);
            }
        }

        ProtectOptions novocab = TinyProtectOptions(src, tf.Add("novocab", ".aip"));
        novocab.keep_vocab = false;
        ContainerWriter::Protect(novocab, password, nullptr);
        {
            std::unique_ptr<ContainerHandle> h = ProtectedRuntime::Open(novocab.output, password, ro);
            if (ContainerReader::FindSection(h->sections, SectionPurpose::kVocab) != nullptr) {
                return Fail(name, "--no-vocab still wrote a vocabulary section", t0);
            }
            if (h->manifest.vocab.Valid()) return Fail(name, "--no-vocab still carried a vocabulary", t0);
        }

        {
            bool threw = false;
            ExitCode code = ExitCode::kOk;
            try {
                std::unique_ptr<ContainerHandle> h = ProtectedRuntime::Open(full.output, "wrong-passphrase", ro);
                (void)h;
            } catch (const AiError& e) {
                threw = true;
                code = e.Code();
                if (verbose) Console::OutF("      wrong password: %s\n", e.Message().c_str());
            }
            if (!threw) return Fail(name, "a wrong password opened the container", t0);
            if (code != ExitCode::kAuthError) {
                return Fail(name, FormatErrorF("a wrong password produced exit code %d instead of 8",
                                               static_cast<int>(code)),
                            t0);
            }
        }
        {
            ProtectOptions again = TinyProtectOptions(src, full.output);
            bool threw = false;
            ExitCode code = ExitCode::kOk;
            try {
                ContainerWriter::Protect(again, password, nullptr);
            } catch (const AiError& e) {
                threw = true;
                code = e.Code();
            }
            if (!threw || code != ExitCode::kOutputFileError) {
                return Fail(name, "overwriting an existing container without --force was not rejected with "
                                  "exit code 4",
                            t0);
            }
            ProtectOptions same = TinyProtectOptions(src, src);
            threw = false;
            code = ExitCode::kOk;
            try {
                ContainerWriter::Protect(same, password, nullptr);
            } catch (const AiError& e) {
                threw = true;
                code = e.Code();
            }
            if (!threw || code != ExitCode::kUsageError) {
                return Fail(name, "protecting a model onto itself was not rejected with exit code 2", t0);
            }
            ProtectOptions gguf_out = TinyProtectOptions(src, tf.Add("bad", ".gguf"));
            threw = false;
            code = ExitCode::kOk;
            try {
                ContainerWriter::Protect(gguf_out, password, nullptr);
            } catch (const AiError& e) {
                threw = true;
                code = e.Code();
            }
            if (!threw || code != ExitCode::kUsageError) {
                return Fail(name, "writing a container to a .gguf path was not rejected", t0);
            }
        }
        {
            FileReader fr;
            std::string err;
            if (!fr.Open(full.output, err)) return Fail(name, "cannot reopen the container: " + err, t0);
            uint8_t magic[4];
            if (!fr.ReadAt(0, magic, 4)) return Fail(name, "cannot read the container magic", t0);
            if (memcmp(magic, "GGUF", 4) == 0) {
                return Fail(name, "the container starts with the GGUF magic", t0);
            }
            if (magic[0] != (kContainerMagicA & 0xFF)) {
                return Fail(name, "the container does not carry the AIProtect magic", t0);
            }
            std::vector<uint8_t> all = ReadFileAll(full.output);
            size_t hits = 0;
            for (size_t i = 0; i + 4 <= all.size(); i++) {
                if (all[i] == 'G' && all[i + 1] == 'G' && all[i + 2] == 'U' && all[i + 3] == 'F') hits++;
            }
            if (hits > 0 && verbose) {
                Console::OutF("      note: %zu incidental GGUF magic occurrences inside ciphertext\n", hits);
            }
            for (const auto& needle : {"llama", "token_embd", "attn_q", "blk.0"}) {
                size_t n = strlen(needle);
                for (size_t i = kHeaderSize; i + n <= all.size(); i++) {
                    if (memcmp(all.data() + i, needle, n) == 0) {
                        return Fail(name, std::string("the plaintext string '") + needle +
                                              "' survives inside the container body",
                                    t0);
                    }
                }
            }
        }
        return Pass(name, FormatErrorF("protected a %s model into %s, replayed it bitwise identically, matched "
                                       "the --no-vm and --no-transform variants token for token, rejected a wrong "
                                       "password with exit code 8, and found no plaintext weight or metadata strings",
                                       HumanBytes(rep.source_bytes).c_str(), HumanBytes(rep.output_bytes).c_str()),
                    t0);
    } catch (const AiError& e) {
        return Fail(name, e.Message(), t0);
    } catch (const std::exception& e) {
        return Fail(name, e.what(), t0);
    }
}

SelfTestResult SelfTest::TamperDetection(bool verbose) {
    const std::string name = "tamper-detection";
    auto t0 = std::chrono::steady_clock::now();
    TempFiles tf;
    try {
        std::vector<uint8_t> blob = TinyModelFactory::BuildGguf(1, 128, 256, 4, 2, 80, 2, 0xBEEFull, "llama");
        std::string src = tf.Add("src", ".gguf");
        WriteFileAll(src, std::span<const uint8_t>(blob.data(), blob.size()));
        const char* password = "self-test-passphrase";
        ProtectOptions po = TinyProtectOptions(src, tf.Add("c", ".aip"));
        ContainerWriter::Protect(po, password, nullptr);
        RunOptions ro = TinyRunOptions(po.output);
        std::vector<int32_t> prompt = {1, 20, 21};

        std::vector<uint8_t> original = ReadFileAll(po.output);
        FileReader probe;
        std::string err;
        if (!probe.Open(po.output, err)) return Fail(name, "cannot reopen the container: " + err, t0);
        ContainerReader::OpenResult opened = ContainerReader::OpenHeader(po.output, probe, err);
        if (!opened.header_ok) return Fail(name, "the fresh container header is invalid: " + err, t0);
        const SectionEntry* mse = ContainerReader::FindSection(opened.sections, SectionPurpose::kManifest);
        const SectionEntry* wse = ContainerReader::FindSection(opened.sections, SectionPurpose::kWeights);
        const SectionEntry* rse = ContainerReader::FindSection(opened.sections, SectionPurpose::kRmp);
        if (!mse || !wse || !rse) return Fail(name, "the fresh container is missing a section", t0);

        struct Mutation {
            const char* label;
            uint64_t offset;
            uint8_t mask;
            ExitCode expect;
        };
        std::vector<Mutation> mutations = {
            {"header flags", 16, 0x04, ExitCode::kAuthError},
            {"weights ciphertext", wse->data_offset + wse->stored_size / 2, 0xA5, ExitCode::kAuthError},
            {"weights auth tag", wse->data_offset + 20, 0x5A, ExitCode::kAuthError},
            {"manifest ciphertext", mse->data_offset + 40, 0x33, ExitCode::kAuthError},
            {"rmp ciphertext", rse->data_offset + 40, 0x77, ExitCode::kAuthError},
            {"section table digest", kHeaderSize + 96, 0x11, ExitCode::kAuthError},
        };
        size_t caught = 0;
        for (const auto& m : mutations) {
            if (m.offset >= original.size()) {
                return Fail(name, std::string("mutation '") + m.label + "' points past the end of the file", t0);
            }
            std::vector<uint8_t> mutated = original;
            mutated[static_cast<size_t>(m.offset)] ^= m.mask;
            std::string path = tf.Add("mut", ".aip");
            WriteFileAll(path, std::span<const uint8_t>(mutated.data(), mutated.size()));
            bool threw = false;
            ExitCode code = ExitCode::kOk;
            std::string message;
            try {
                std::unique_ptr<ContainerHandle> h = ProtectedRuntime::Open(path, password, ro);
                std::vector<int32_t> gen;
                ProtectedRuntime::GenerationStats st;
                ProtectedRuntime::Generate(*h, prompt, ro, gen, st);
            } catch (const AiError& e) {
                threw = true;
                code = e.Code();
                message = e.Message();
            }
            if (!threw) {
                return Fail(name, std::string("the '") + m.label + "' mutation was not detected", t0);
            }
            if (code != m.expect) {
                return Fail(name, FormatErrorF("the '%s' mutation produced exit code %d instead of %d (%s)", m.label,
                                               static_cast<int>(code), static_cast<int>(m.expect), message.c_str()),
                            t0);
            }
            caught++;
            if (verbose) Console::OutF("      detected %-22s : exit %d, %s\n", m.label, static_cast<int>(code),
                                       message.c_str());
            AtomicFileWriter::RemoveFile(path);
            tf.paths.pop_back();
        }

        {
            std::vector<uint8_t> truncated(original.begin(), original.begin() + static_cast<long>(original.size() - 4096));
            std::string path = tf.Add("trunc", ".aip");
            WriteFileAll(path, std::span<const uint8_t>(truncated.data(), truncated.size()));
            bool threw = false;
            std::string message;
            try {
                std::unique_ptr<ContainerHandle> h = ProtectedRuntime::Open(path, password, ro);
                std::vector<int32_t> gen;
                ProtectedRuntime::GenerationStats st;
                ProtectedRuntime::Generate(*h, prompt, ro, gen, st);
            } catch (const AiError& e) {
                threw = true;
                message = e.Message();
            }
            if (!threw) return Fail(name, "a truncated container still ran", t0);
            if (verbose) Console::OutF("      detected %-22s : %s\n", "truncated tail", message.c_str());
            caught++;
        }
        return Pass(name, FormatErrorF("%zu distinct tampering and truncation attacks were detected and refused",
                                       caught),
                    t0);
    } catch (const AiError& e) {
        return Fail(name, e.Message(), t0);
    } catch (const std::exception& e) {
        return Fail(name, e.what(), t0);
    }
}

SelfTestResult SelfTest::TransformEquivalence(bool verbose) {
    const std::string name = "transform-equivalence";
    auto t0 = std::chrono::steady_clock::now();
    TempFiles tf;
    try {
        std::vector<uint8_t> blob = TinyModelFactory::BuildGguf(2, 128, 256, 4, 2, 80, 2, 0xABCFull, "llama");
        std::string src = tf.Add("src", ".gguf");
        WriteFileAll(src, std::span<const uint8_t>(blob.data(), blob.size()));
        FileReader fr;
        std::string err;
        if (!fr.Open(src, err)) return Fail(name, "cannot reopen the fixture: " + err, t0);
        GgufInfo g = GgufReader::Parse(src, fr, true);
        ModelSpec spec = ModelSpec::FromGguf(g);
        spec.Validate();
        spec.BuildRequirements();
        std::vector<const GgufTensorInfo*> sources;
        std::vector<std::string> warnings;
        WeightLayout layout = BuildLayoutFromGguf(spec, g, sources, warnings);
        TransformPlan plan = WeightTransformEngine::Plan(spec, layout, true);
        if (!plan.enabled) {
            return Fail(name, "no axis was enabled: " + plan.residual.reject_reason + " | " + plan.ffn.reject_reason +
                                  " | " + plan.head.reject_reason,
                        t0);
        }
        if (!plan.residual.enabled || !plan.ffn.enabled || !plan.head.enabled || !plan.vocab.enabled) {
            return Fail(name, "this fixture should enable every axis", t0);
        }
        for (auto& s : layout.slots) {
            s.transform_mask = static_cast<uint32_t>(WeightTransformEngine::TransformMaskFor(s, plan));
        }
        size_t masked = 0;
        for (const auto& s : layout.slots) {
            if (s.transform_mask != 0) masked++;
        }
        if (masked != layout.slots.size()) {
            return Fail(name, FormatErrorF("%zu of %zu tensors carry a transform mask", masked, layout.slots.size()),
                        t0);
        }
        GgufReaderAccess acc(fr, g);
        if (!WeightTransformEngine::VerifyEquivalence(spec, layout, plan, acc, err)) {
            return Fail(name, "the reversibility check failed: " + err, t0);
        }

        size_t broken = 0;
        size_t attempts = 0;
        auto expect_rejection = [&](const char* label, TransformPlan bad) {
            for (auto& s : layout.slots) {
                s.transform_mask = static_cast<uint32_t>(WeightTransformEngine::TransformMaskFor(s, bad));
            }
            std::string e;
            attempts++;
            if (!WeightTransformEngine::VerifyEquivalence(spec, layout, bad, acc, e)) {
                broken++;
                if (verbose) Console::OutF("      rejected %-24s : %s\n", label, e.c_str());
            }
        };
        {
            TransformPlan bad = plan;
            std::swap(bad.residual.perm[0], bad.residual.perm[1]);
            bad.residual.perm[1] = bad.residual.perm[0];
            expect_rejection("non bijective residual", bad);
        }
        {
            TransformPlan bad = plan;
            bad.residual.signs[0] = 0;
            expect_rejection("zero sign", bad);
        }
        {
            TransformPlan bad = plan;
            uint32_t n = bad.vocab.length;
            bad.vocab.perm[0] = n - 1;
            bad.vocab.perm[n - 1] = n - 1;
            expect_rejection("non bijective vocabulary", bad);
        }
        {
            TransformPlan bad = plan;
            bad.head.kv_perm[0] = bad.head.kv_perm[0];
            bad.head.kv_perm.push_back(0);
            expect_rejection("malformed head permutation", bad);
        }
        {
            TransformPlan bad = plan;
            bad.ffn.granularity = 1;
            expect_rejection("misaligned feed forward block", bad);
        }
        for (auto& s : layout.slots) {
            s.transform_mask = static_cast<uint32_t>(WeightTransformEngine::TransformMaskFor(s, plan));
        }

        ProtectOptions with = TinyProtectOptions(src, tf.Add("with", ".aip"));
        ProtectOptions without = TinyProtectOptions(src, tf.Add("without", ".aip"));
        without.transform = false;
        const char* password = "self-test-passphrase";
        ContainerWriter::Protect(with, password, nullptr);
        ContainerWriter::Protect(without, password, nullptr);
        RunOptions ro = TinyRunOptions(with.output);
        ro.n_predict = 12;
        std::vector<int32_t> prompt = {1, 20, 21, 22, 23};
        std::vector<int32_t> ga, gb;
        ProtectedRuntime::GenerationStats sa, sb;
        {
            std::unique_ptr<ContainerHandle> h = ProtectedRuntime::Open(with.output, password, ro);
            ProtectedRuntime::Generate(*h, prompt, ro, ga, sa);
        }
        {
            std::unique_ptr<ContainerHandle> h = ProtectedRuntime::Open(without.output, password, ro);
            ProtectedRuntime::Generate(*h, prompt, ro, gb, sb);
        }
        if (ga != gb) {
            std::string a, b;
            for (int32_t v : ga) a += std::to_string(v) + " ";
            for (int32_t v : gb) b += std::to_string(v) + " ";
            return Fail(name, "the transformed container generated [" + a + "] but the untransformed one generated [" +
                                  b + "]",
                        t0);
        }
        std::vector<int32_t> gc;
        {
            std::vector<uint8_t> blob2 = TinyModelFactory::BuildGguf(2, 256, 512, 4, 2, 80, 10, 0x1234ull, "llama");
            std::string src2 = tf.Add("src2", ".gguf");
            WriteFileAll(src2, std::span<const uint8_t>(blob2.data(), blob2.size()));
            FileReader fr2;
            std::string err2;
            if (!fr2.Open(src2, err2)) return Fail(name, "cannot reopen the second fixture: " + err2, t0);
            GgufInfo g2 = GgufReader::Parse(src2, fr2, true);
            ModelSpec spec2 = ModelSpec::FromGguf(g2);
            spec2.Validate();
            spec2.BuildRequirements();
            std::vector<const GgufTensorInfo*> sources2;
            std::vector<std::string> warnings2;
            WeightLayout layout2 = BuildLayoutFromGguf(spec2, g2, sources2, warnings2);
            TransformPlan plan2 = WeightTransformEngine::Plan(spec2, layout2, true);
            if (plan2.residual.enabled) {
                return Fail(name, "the coarse grained fixture should refuse the residual axis", t0);
            }
            if (plan2.head.enabled) {
                return Fail(name, "the coarse grained fixture should refuse the head axis", t0);
            }
            if (!plan2.ffn.enabled) {
                return Fail(name, "the coarse grained fixture lost the feed forward axis: " + plan2.ffn.reject_reason,
                            t0);
            }
            if (!plan2.vocab.enabled) {
                return Fail(name, "the coarse grained fixture lost the vocabulary axis: " + plan2.vocab.reject_reason,
                            t0);
            }
            if (plan2.key_space_bits < 10) {
                return Fail(name, FormatErrorF("the coarse grained fixture reports only %llu bits of key space",
                                               static_cast<unsigned long long>(plan2.key_space_bits)),
                            t0);
            }
            for (auto& s2 : layout2.slots) {
                s2.transform_mask = static_cast<uint32_t>(WeightTransformEngine::TransformMaskFor(s2, plan2));
            }
            GgufReaderAccess acc2(fr2, g2);
            if (!WeightTransformEngine::VerifyEquivalence(spec2, layout2, plan2, acc2, err2)) {
                return Fail(name, "the second fixture reversibility check failed: " + err2, t0);
            }
            ProtectOptions w2 = TinyProtectOptions(src2, tf.Add("with2", ".aip"));
            ProtectOptions u2 = TinyProtectOptions(src2, tf.Add("without2", ".aip"));
            u2.transform = false;
            ContainerWriter::Protect(w2, password, nullptr);
            ContainerWriter::Protect(u2, password, nullptr);
            RunOptions ro2 = TinyRunOptions(w2.output);
            ro2.n_predict = 10;
            std::vector<int32_t> gd;
            ProtectedRuntime::GenerationStats sc, sd;
            {
                std::unique_ptr<ContainerHandle> h = ProtectedRuntime::Open(w2.output, password, ro2);
                ProtectedRuntime::Generate(*h, prompt, ro2, gc, sc);
            }
            {
                std::unique_ptr<ContainerHandle> h = ProtectedRuntime::Open(u2.output, password, ro2);
                ProtectedRuntime::Generate(*h, prompt, ro2, gd, sd);
            }
            if (gc != gd) {
                std::string a, b;
                for (int32_t v : gc) a += std::to_string(v) + " ";
                for (int32_t v : gd) b += std::to_string(v) + " ";
                return Fail(name, "the partially transformed container generated [" + a +
                                      "] but its untransformed twin generated [" + b + "]",
                            t0);
            }
            if (verbose) {
                Console::OutF("      coarse fixture: residual and head axes refused, %llu bits of key space from "
                              "the remaining axes\n",
                              static_cast<unsigned long long>(plan2.key_space_bits));
            }
        }
        (void)sources;
        (void)warnings;
        return Pass(name, FormatErrorF("all four axes enabled, every stored row verified reversible elementwise and "
                                       "by matrix vector product, %zu of %zu sabotaged plans rejected, %u tokens "
                                       "match the untransformed container, and a coarse grained fixture that can "
                                       "only permute the feed forward and vocabulary axes reproduces %u more",
                                       broken, attempts, static_cast<unsigned>(ga.size()),
                                       static_cast<unsigned>(gc.size())),
                    t0);
    } catch (const AiError& e) {
        return Fail(name, e.Message(), t0);
    } catch (const std::exception& e) {
        return Fail(name, e.what(), t0);
    }
}

SelfTestResult SelfTest::RmpBehaviour(bool verbose) {
    const std::string name = "runtime-protection";
    auto t0 = std::chrono::steady_clock::now();
    try {
        if (std::string(platform::Name()).empty()) return Fail(name, "no platform name", t0);
        RmpPolicy pol;
        pol.enabled = true;
        pol.anti_debug = true;
        pol.periodic_integrity = true;
        pol.verify_blocks = true;
        pol.env_scan = true;
        pol.probe_interval_tokens = 4;
        pol.max_violations = 1;
        RmpMonitor mon(pol);
        uint8_t key[32];
        uint8_t cid[16];
        random::Bytes(key, sizeof(key));
        random::Bytes(cid, sizeof(cid));
        mon.Bind(std::span<const uint8_t>(cid, 16), std::span<const uint8_t>(key, 32));
        std::vector<uint8_t> region_a(4096, 0x21);
        std::vector<uint8_t> region_b(2048, 0x77);
        mon.RegisterRegion("region-a", std::span<const uint8_t>(region_a.data(), region_a.size()));
        mon.RegisterRegion("region-b", std::span<const uint8_t>(region_b.data(), region_b.size()));
        mon.Seal();
        std::vector<RmpFinding> findings;
        if (!mon.VerifyRegions(findings)) return Fail(name, "a sealed region failed immediately", t0);
        if (!findings.empty()) return Fail(name, "verification produced findings on clean data", t0);
        region_a[1234] ^= 0xFF;
        findings.clear();
        if (mon.VerifyRegions(findings)) return Fail(name, "a modified region was not detected", t0);
        if (findings.empty() || !findings.front().fatal) {
            return Fail(name, "the region finding was not reported as fatal", t0);
        }
        if (findings.front().detail.find("region-a") == std::string::npos) {
            return Fail(name, "the finding does not name the modified region", t0);
        }
        region_a[1234] ^= 0xFF;
        findings.clear();
        if (!mon.VerifyRegions(findings)) return Fail(name, "restoring the region did not clear the finding", t0);

        uint8_t digest[32];
        KeyedHash::Plain(std::span<const uint8_t>(region_b.data(), region_b.size()), digest);
        mon.RecordBlockDigest("chunk/0", std::span<const uint8_t, 32>(digest, 32));
        if (!mon.VerifyBlockDigest("chunk/0", std::span<const uint8_t, 32>(digest, 32))) {
            return Fail(name, "a matching block digest was rejected", t0);
        }
        uint8_t bad[32];
        memcpy(bad, digest, 32);
        bad[5] ^= 0x01;
        if (mon.VerifyBlockDigest("chunk/0", std::span<const uint8_t, 32>(bad, 32))) {
            return Fail(name, "a rolled back block was accepted", t0);
        }
        if (mon.ChecksPerformed() < 4) return Fail(name, "checks were not counted", t0);

        findings.clear();
        mon.OnToken(0, findings);
        mon.OnToken(1, findings);
        mon.OnToken(8, findings);
        if (mon.ChecksPerformed() < 5) return Fail(name, "periodic probes did not run", t0);

        RmpReport report = mon.ScanEnvironment();
        if (report.platform != platform::Name()) return Fail(name, "the report carries the wrong platform", t0);
        if (verbose) {
            Console::OutF("      anti-debug implementation: %s\n",
                          platform::AntiDebugAvailable() ? "present" : "absent");
            Console::OutF("      environment scan: %s\n",
                          report.AnyViolation() ? report.Summary().c_str() : "clean");
            for (const auto& f : report.findings) {
                Console::OutF("        [%s] %s: %s\n", f.fatal ? "fatal" : "warning", f.source.c_str(),
                              f.detail.c_str());
            }
        }

        RmpPolicy off;
        off.enabled = false;
        RmpMonitor disabled(off);
        disabled.Bind(std::span<const uint8_t>(cid, 16), std::span<const uint8_t>(key, 32));
        disabled.RegisterRegion("region-a", std::span<const uint8_t>(region_a.data(), region_a.size()));
        disabled.Seal();
        region_a[0] ^= 0xFF;
        std::vector<RmpFinding> none;
        if (!disabled.VerifyRegions(none)) {
            return Fail(name, "a disabled monitor still enforced region integrity", t0);
        }
        if (disabled.ChecksPerformed() != 0) {
            return Fail(name, "a disabled monitor still counted checks", t0);
        }
        region_a[0] ^= 0xFF;
        mon.SecureErase();
        disabled.SecureErase();
        sodium_memzero(key, sizeof(key));
        return Pass(name, FormatErrorF("region digests, block rollback detection, periodic probes, and the "
                                       "disabled path all behave correctly on %s (%llu checks)",
                                       platform::Name(), static_cast<unsigned long long>(mon.ChecksPerformed())),
                    t0);
    } catch (const AiError& e) {
        return Fail(name, e.Message(), t0);
    } catch (const std::exception& e) {
        return Fail(name, e.what(), t0);
    }
}

SelfTestResult SelfTest::CliParsing(bool verbose) {
    const std::string name = "cli-parsing";
    auto t0 = std::chrono::steady_clock::now();
    try {
        size_t cases = 0;
        auto expect = [&](std::vector<std::string> args, CliOptions::Command want, bool want_errors,
                          const char* label) {
            CliOptions o = Cli::Parse(args);
            cases++;
            bool has_errors = !o.errors.empty();
            if (o.command != want || has_errors != want_errors) {
                throw AiError(ErrClass::kInternal,
                              FormatErrorF("parsing '%s' produced command %d with %zu errors, expected command %d "
                                           "with errors=%s",
                                           label, static_cast<int>(o.command), o.errors.size(), static_cast<int>(want),
                                           want_errors ? "yes" : "no"));
            }
            if (verbose && has_errors) {
                Console::OutF("      %-34s : %s\n", label, o.errors.front().c_str());
            }
            return o;
        };
        CliOptions a = expect({"model.gguf", "-output", "model_p.aip"}, CliOptions::Command::kProtect, false,
                              "short form protect");
        if (a.protect.input != "model.gguf" || a.protect.output != "model_p.aip") {
            return Fail(name, "the short form did not capture input and output", t0);
        }
        if (!a.protect.vm || !a.protect.rmp || !a.protect.transform) {
            return Fail(name, "protection features are off by default", t0);
        }
        CliOptions b = expect({"protect", "in.gguf", "--output", "out.aip"}, CliOptions::Command::kProtect, false,
                              "long form protect");
        if (b.protect.input != "in.gguf" || b.protect.output != "out.aip") {
            return Fail(name, "the long form did not capture input and output", t0);
        }
        CliOptions c = expect({"protect", "in.gguf", "-o", "out.aip", "--no-vm", "--no-rmp", "--no-transform",
                               "--force", "--quiet", "--chunk-kb", "64", "--kdf-ops", "2", "--kdf-mem", "131072",
                               "--max-ctx", "4096"},
                              CliOptions::Command::kProtect, false, "protect with every switch");
        if (c.protect.vm || c.protect.rmp || c.protect.transform || !c.protect.force || !c.protect.quiet ||
            c.protect.chunk_kb != 64 || c.protect.kdf_opslimit != 2 || c.protect.kdf_memlimit_kib != 131072 ||
            c.protect.max_ctx != 4096) {
            return Fail(name, "a protect switch was not applied", t0);
        }
        CliOptions d = expect({"run", "model.aip", "--prompt", "hello world", "-n", "16", "--ctx", "256", "-t", "2",
                               "--temp", "0.8", "--top-k", "40", "--top-p", "0.95", "--min-p", "0.05",
                               "--repeat-penalty", "1.1", "--repeat-last-n", "32", "--seed", "7", "--cache-mb", "32"},
                              CliOptions::Command::kRun, false, "run with sampling options");
        if (d.run.input != "model.aip" || d.run.prompt != "hello world" || d.run.n_predict != 16 ||
            d.run.n_ctx != 256 || d.run.threads != 2 || d.run.cache_mb != 32) {
            return Fail(name, "a run switch was not applied", t0);
        }
        if (std::fabs(d.run.sampler.temperature - 0.8f) > 1e-6f || d.run.sampler.top_k != 40 ||
            std::fabs(d.run.sampler.top_p - 0.95f) > 1e-6f || std::fabs(d.run.sampler.min_p - 0.05f) > 1e-6f ||
            std::fabs(d.run.sampler.repeat_penalty - 1.1f) > 1e-6f || d.run.sampler.repeat_last_n != 32 ||
            d.run.sampler.seed != 7) {
            return Fail(name, "a sampler switch was not applied", t0);
        }
        CliOptions e = expect({"run", "model.aip", "--tokens", "1, 2,3 , 47"}, CliOptions::Command::kRun, false,
                              "run with explicit tokens");
        if (e.run.tokens.size() != 4 || e.run.tokens[0] != 1 || e.run.tokens[3] != 47) {
            return Fail(name, "the token list was not parsed", t0);
        }
        expect({"inspect", "model.aip"}, CliOptions::Command::kInspect, false, "inspect");
        expect({"model.aip"}, CliOptions::Command::kInspect, false, "bare .aip path");
        expect({"--self-test"}, CliOptions::Command::kSelfTest, false, "self test flag");
        expect({"self-test", "--filter", "crypto"}, CliOptions::Command::kSelfTest, false, "self test filter");
        expect({"version"}, CliOptions::Command::kVersion, false, "version command");
        expect({"--help"}, CliOptions::Command::kHelp, false, "help flag");
        expect({}, CliOptions::Command::kHelp, false, "no arguments");
        expect({"--bogus"}, CliOptions::Command::kNone, true, "unknown option");
        expect({"protect"}, CliOptions::Command::kNone, true, "protect without a path");
        expect({"protect", "a", "b"}, CliOptions::Command::kNone, true, "extra positional argument");
        expect({"run", "m.aip", "--top-k"}, CliOptions::Command::kNone, true, "option missing its value");
        expect({"run", "m.aip", "--temp", "abc"}, CliOptions::Command::kNone, true, "non numeric temperature");
        expect({"run", "m.aip", "--top-p", "2"}, CliOptions::Command::kNone, true, "top-p out of range");
        expect({"protect", "a.gguf", "-o", "b.gguf"}, CliOptions::Command::kProtect, false, "output extension is "
                                                                                            "checked later");
        expect({"run", "m.aip", "--tokens", "1,x"}, CliOptions::Command::kNone, true, "malformed token list");
        expect({"run", "m.aip", "--threads", "0"}, CliOptions::Command::kNone, true, "zero threads");
        expect({"protect", "a.gguf", "-o", "b.aip", "--chunk-kb", "7"}, CliOptions::Command::kProtect, false,
               "chunk size is checked later");
        std::string help = Cli::HelpText();
        for (const char* needle : {"--no-vm", "--no-rmp", "--self-test", "--output", "exit codes", "--password-stdin"}) {
            if (help.find(needle) == std::string::npos) {
                return Fail(name, std::string("the help text does not mention ") + needle, t0);
            }
        }
        std::string ver = Cli::VersionText();
        if (ver.find("AIProtect") == std::string::npos || ver.find(platform::Name()) == std::string::npos) {
            return Fail(name, "the version text is incomplete", t0);
        }
        return Pass(name, FormatErrorF("%zu command lines parsed, including %zu that must be rejected; help and "
                                       "version text verified",
                                       cases, static_cast<size_t>(10)),
                    t0);
    } catch (const AiError& e) {
        return Fail(name, e.Message(), t0);
    } catch (const std::exception& e) {
        return Fail(name, e.what(), t0);
    }
}

SelfTestResult SelfTest::TokenizerRoundTrip(bool verbose) {
    const std::string name = "tokenizer-round-trip";
    auto t0 = std::chrono::steady_clock::now();
    TempFiles tf;
    try {
        std::vector<uint8_t> blob = TinyModelFactory::BuildGguf(1, 128, 256, 4, 2, 80, 2, 0x77ull, "llama");
        std::string src = tf.Add("src", ".gguf");
        WriteFileAll(src, std::span<const uint8_t>(blob.data(), blob.size()));
        FileReader fr;
        std::string err;
        if (!fr.Open(src, err)) return Fail(name, "cannot reopen the fixture: " + err, t0);
        GgufInfo g = GgufReader::Parse(src, fr, true);
        VocabData v = VocabData::FromGguf(g);
        if (!v.Valid()) return Fail(name, "the fixture carries no vocabulary", t0);
        Tokenizer tok;
        tok.Load(v);
        if (!tok.Ready() || tok.Size() != v.tokens.size()) {
            return Fail(name, "the tokenizer did not load the vocabulary", t0);
        }
        if (tok.Eos() != 2) return Fail(name, "the end of text id is wrong", t0);
        const char* samples[] = {"hello", "a b c", "Zebra 42!", "hi there friend"};
        size_t round_trips = 0;
        for (const char* text : samples) {
            std::vector<int32_t> ids = tok.Encode(text, false);
            if (ids.empty()) return Fail(name, std::string("'") + text + "' produced no tokens", t0);
            for (int32_t id : ids) {
                if (id < 0 || static_cast<size_t>(id) >= v.tokens.size()) {
                    return Fail(name, FormatErrorF("'%s' produced out of range id %d", text, id), t0);
                }
            }
            std::string back = tok.Decode(ids);
            std::string trimmed = back;
            while (!trimmed.empty() && (trimmed.front() == ' ' || trimmed.front() == '\n')) trimmed.erase(trimmed.begin());
            if (trimmed != text) {
                return Fail(name, FormatErrorF("'%s' decoded back to '%s'", text, back.c_str()), t0);
            }
            round_trips++;
            if (verbose) Console::OutF("      '%s' -> %zu tokens -> '%s'\n", text, ids.size(), back.c_str());
        }
        std::vector<int32_t> with_bos = tok.Encode("hi", true);
        if (with_bos.empty() || with_bos.front() != tok.Bos()) {
            return Fail(name, "add_bos did not prepend the beginning of text token", t0);
        }

        VocabData bpe;
        bpe.model = "gpt2";
        bpe.pre = "qwen2";
        bpe.bos = 0;
        bpe.eos = 1;
        bpe.tokens = {"<|endoftext|>", "<|im_end|>", "h", "e", "l", "o", "he", "lo", "hel", "hello", "<0x20>"};
        bpe.scores.assign(bpe.tokens.size(), -1.0f);
        bpe.types.assign(bpe.tokens.size(), 1);
        bpe.types[0] = 3;
        bpe.types[1] = 3;
        bpe.types[10] = 6;
        bpe.merges = {"h e", "l o", "he l", "hel lo"};
        Tokenizer btok;
        btok.Load(bpe);
        if (!btok.Ready()) return Fail(name, "the bpe tokenizer did not load", t0);
        std::vector<int32_t> bids = btok.Encode("hello", false);
        if (bids.size() != 1 || bids[0] != 9) {
            std::string got;
            for (int32_t i : bids) got += std::to_string(i) + " ";
            return Fail(name, "bpe did not merge 'hello' into id 9, got " + got, t0);
        }
        std::vector<int32_t> partial = btok.Encode("helol", false);
        if (partial.empty()) return Fail(name, "bpe could not encode a partially mergeable word", t0);
        std::string back = btok.Decode(partial);
        if (back != "helol") return Fail(name, "bpe decode produced '" + back + "'", t0);
        std::vector<int32_t> eos = btok.Encode("<|im_end|>", false);
        if (eos.size() != 1 || eos[0] != 1) return Fail(name, "a special token was not matched", t0);
        return Pass(name, FormatErrorF("%zu sentence fragment round trips on a sentencepiece vocabulary plus merge "
                                       "ranking, byte fallback, and special token matching on a bpe vocabulary",
                                       round_trips),
                    t0);
    } catch (const AiError& e) {
        return Fail(name, e.Message(), t0);
    } catch (const std::exception& e) {
        return Fail(name, e.what(), t0);
    }
}

std::vector<SelfTestResult> SelfTest::All(bool verbose) {
    std::vector<SelfTestResult> out;
    out.push_back(CryptoRoundTrip(verbose));
    out.push_back(KdfAndKeys(verbose));
    out.push_back(DequantReference(verbose));
    out.push_back(GgufSynthetic(verbose));
    out.push_back(GgufMalformed(verbose));
    out.push_back(TokenizerRoundTrip(verbose));
    out.push_back(BytecodeVerifier(verbose));
    out.push_back(VmMicroProgram(verbose));
    out.push_back(TransformEquivalence(verbose));
    out.push_back(ContainerRoundTrip(verbose));
    out.push_back(TamperDetection(verbose));
    out.push_back(RmpBehaviour(verbose));
    out.push_back(CliParsing(verbose));
    return out;
}

int SelfTest::Run(bool verbose, const std::string& filter) {
    Console::Out(ProductBanner());
    Console::OutF("libsodium %s, platform %s, self test filter '%s'\n\n", SodiumVersion().c_str(), platform::Name(),
                  filter.empty() ? "none" : filter.c_str());
    struct Entry {
        const char* name;
        SelfTestResult (*fn)(bool);
    };
    static const Entry entries[] = {
        {"crypto-round-trip", &SelfTest::CryptoRoundTrip},
        {"kdf-and-keyring", &SelfTest::KdfAndKeys},
        {"dequant-reference", &SelfTest::DequantReference},
        {"gguf-synthetic", &SelfTest::GgufSynthetic},
        {"gguf-malformed", &SelfTest::GgufMalformed},
        {"tokenizer-round-trip", &SelfTest::TokenizerRoundTrip},
        {"bytecode-verifier", &SelfTest::BytecodeVerifier},
        {"vm-execution", &SelfTest::VmMicroProgram},
        {"transform-equivalence", &SelfTest::TransformEquivalence},
        {"container-round-trip", &SelfTest::ContainerRoundTrip},
        {"tamper-detection", &SelfTest::TamperDetection},
        {"runtime-protection", &SelfTest::RmpBehaviour},
        {"cli-parsing", &SelfTest::CliParsing},
    };
    size_t ran = 0, passed = 0;
    for (const auto& e : entries) {
        if (!filter.empty() && std::string(e.name).find(filter) == std::string::npos) continue;
        SelfTestResult r = e.fn(verbose);
        ran++;
        if (r.passed) passed++;
        Console::OutF("[%s] %-24s %7.3f s  %s\n", r.passed ? " ok " : "FAIL", r.name.c_str(), r.seconds,
                      r.detail.c_str());
    }
    if (ran == 0) {
        Console::OutF("no self test matches the filter '%s'\n", filter.c_str());
        return static_cast<int>(ExitCode::kUsageError);
    }
    Console::OutF("\n%zu of %zu self tests passed\n", passed, ran);
    return (passed == ran) ? static_cast<int>(ExitCode::kOk) : static_cast<int>(ExitCode::kSelfTestFailed);
}

}
